<?php

namespace RtclStore\Controllers\Ajax;

use Rtcl\Controllers\Hooks\Filters;
use Rtcl\Helpers\Functions as RtclFunctions;
use RtclStore\Helpers\Functions;
use RtclStore\Helpers\StoreManager;

class Admin {

    public static function init() {
        add_action( 'wp_ajax_rtcl_admin_ajax_store_banner_upload', [ __CLASS__, 'rtcl_admin_ajax_store_banner_upload' ] );
        add_action( 'wp_ajax_rtcl_admin_ajax_store_banner_delete', [ __CLASS__, 'rtcl_admin_ajax_store_banner_delete' ] );
        add_action( 'wp_ajax_rtcl_admin_ajax_store_logo_upload', [ __CLASS__, 'rtcl_admin_ajax_store_logo_upload' ] );
        add_action( 'wp_ajax_rtcl_admin_ajax_store_logo_delete', [ __CLASS__, 'rtcl_admin_ajax_store_logo_delete' ] );
        // Store Managers meta box.
        add_action( 'wp_ajax_rtcl_admin_store_search_manager_candidates', [ __CLASS__, 'search_manager_candidates' ] );
        add_action( 'wp_ajax_rtcl_admin_store_add_manager', [ __CLASS__, 'add_manager' ] );
        add_action( 'wp_ajax_rtcl_admin_store_remove_manager', [ __CLASS__, 'remove_manager' ] );
    }

    /**
     * Store from the request, if the current user may edit it. Ends the request otherwise.
     *
     * @return \RtclStore\Models\Store
     */
    private static function get_manager_request_store() {
        if ( !RtclFunctions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        $store_id = isset( $_POST['store_id'] ) ? absint( $_POST['store_id'] ) : 0;
        $post     = $store_id ? get_post( $store_id ) : null;
        if ( !$post || rtclStore()->post_type !== $post->post_type || !current_user_can( 'edit_post', $store_id ) ) {
            wp_send_json_error( __( "You are not allowed to manage this store.", "classified-listing-store" ) );
        }
        $store = rtclStore()->factory->get_store( $store_id );
        if ( !$store ) {
            wp_send_json_error( __( "No store found.", "classified-listing-store" ) );
        }

        return $store;
    }

    public static function search_manager_candidates() {
        $store = self::get_manager_request_store();
        $term  = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

        // Users who can list users already see full contact details in wp-admin.
        wp_send_json_success( [ 'users' => StoreManager::search_candidates( $store, $term, !current_user_can( 'list_users' ) ) ] );
    }

    /**
     * Invite a user (sends the invitation email) or, for administrators, add them directly.
     */
    public static function add_manager() {
        $store  = self::get_manager_request_store();
        $direct = !empty( $_POST['direct'] );
        if ( $direct && !StoreManager::can_add_directly() ) {
            wp_send_json_error( __( "Only administrators can add a manager without an invitation.", "classified-listing-store" ) );
        }
        if ( !$store->owner_id() ) {
            wp_send_json_error( __( "Assign a store owner before adding managers.", "classified-listing-store" ) );
        }
        $user = !empty( $_POST['user_id'] ) ? get_user_by( 'id', absint( $_POST['user_id'] ) ) : false;
        if ( !$user && !empty( $_POST['email'] ) && is_email( wp_unslash( $_POST['email'] ) ) ) {
            $user = get_user_by( 'email', sanitize_email( wp_unslash( $_POST['email'] ) ) );
        }
        if ( !$user ) {
            wp_send_json_error( __( "User not found.", "classified-listing-store" ) );
        }
        $label = StoreManager::display_name( $user );
        if ( $error = StoreManager::get_add_error( $store, $user, $label, $direct ) ) {
            wp_send_json_error( $error );
        }

        if ( $direct ) {
            if ( !$store->add_manager( $user ) ) {
                wp_send_json_error( __( "Internal server error", "classified-listing-store" ) );
            }
            do_action( 'rtcl_store_manager_created', $store->get_id(), $user->ID );
            $message = sprintf( __( "%s is now a manager of this store.", "classified-listing-store" ), $label );
        } else {
            if ( !$store->add_to_manager_invitation_list( $user ) ) {
                wp_send_json_error( __( "Internal server error", "classified-listing-store" ) );
            }
            $message = sprintf( __( "Manager Invitation is sent to this (%s) user.", "classified-listing-store" ), $label );
        }

        wp_send_json_success( [
            'user_id' => $user->ID,
            'html'    => StoreManager::get_item_html( $store, $user, !$direct, 'admin' ),
            'message' => $message,
        ] );
    }

    public static function remove_manager() {
        $store   = self::get_manager_request_store();
        $user_id = isset( $_POST['manager_user_id'] ) ? absint( $_POST['manager_user_id'] ) : 0;
        if ( !$user_id || ( !in_array( $user_id, array_map( 'absint', $store->get_manager_ids() ), true )
                            && !in_array( $user_id, array_map( 'absint', array_keys( $store->get_manager_invitation_list() ) ), true ) ) ) {
            wp_send_json_error( __( "Manager not exist.", "classified-listing-store" ) );
        }
        wp_send_json_success( [
            'manager_user_id' => absint( $store->remove_manager( $user_id ) ),
            'message'         => __( "Successfully removed.", "classified-listing-store" ),
        ] );
    }

    public static function rtcl_admin_ajax_store_logo_delete() {
        $error = true;
        $message = null;
        $store = get_post( isset( $_POST['store_id'] ) ? absint( $_POST['store_id'] ) : 0 );
        if ( is_object( $store ) && rtclStore()->post_type == $store->post_type ) {
            $logo_id = absint( get_post_meta( $store->ID, 'logo_id', true ) );
            if ( $logo_id && wp_delete_attachment( $logo_id ) ) {
                delete_post_meta( $store->ID, 'logo_id' );
                $error = false;
                $message = esc_html__( "Successfully deleted", "classified-listing-store" );
            } else {
                $message = __( "File could not be deleted.", "classified-listing-store" );
            }
        } else {
            $message = __( "No store found to remove logo", "classified-listing-store" );
        }

        wp_send_json( [
            'error'   => $error,
            'message' => $message
        ] );
    }

    public static function rtcl_admin_ajax_store_banner_delete() {
        $error = false;
        $message = null;
        $store = get_post( isset( $_POST['store_id'] ) ? absint( $_POST['store_id'] ) : 0 );
        if ( is_object( $store ) && rtclStore()->post_type == $store->post_type ) {
            $banner_id = absint( get_post_meta( $store->ID, 'banner_id', true ) );
            if ( $banner_id && wp_delete_attachment( $banner_id ) ) {
                delete_post_meta( $store->ID, 'banner_id' );
                $error = false;
                $message = esc_html__( "Successfully deleted", "classified-listing-store" );
            } else {
                $message = __( "File could not be deleted.", "classified-listing-store" );
            }
        } else {
            $message = __( "No store found to remove banner", "classified-listing-store" );
        }

        wp_send_json( [
            'error'   => $error,
            'message' => $message
        ] );
    }

    public static function rtcl_admin_ajax_store_banner_upload() {
        if ( !function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }

        $msg = $data = null;
        $error = true;
        $store = get_post( isset( $_POST['store_id'] ) ? absint( $_POST['store_id'] ) : 0 );
        if ( is_object( $store ) && rtclStore()->post_type == $store->post_type ) {
            if ( isset( $_FILES['banner'] ) ) {
                Filters::beforeUpload();
                $status = wp_handle_upload( $_FILES['banner'], [
                    'test_form' => false
                ] );
                Filters::afterUpload();
                if ( $status && !isset( $status['error'] ) ) {
                    // $filename should be the path to a file in the upload directory.
                    $filename = $status['file'];

                    // The ID of the post this attachment is for.
                    $store_id = $store->ID;

                    // Check the type of tile. We'll use this as the 'post_mime_type'.
                    $filetype = wp_check_filetype( basename( $filename ), null );

                    // Get the path to the upload directory.
                    $wp_upload_dir = wp_upload_dir();

                    // Prepare an array of post data for the attachment.
                    $attachment = [
                        'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ),
                        'post_mime_type' => $filetype['type'],
                        'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                        'post_content'   => '',
                        'post_status'    => 'inherit'
                    ];

                    // Insert the attachment.
                    $attach_id = wp_insert_attachment( $attachment, $filename, $store_id );
                    if ( !is_wp_error( $attach_id ) ) {
                        if ( $existing_banner = get_post_meta( $store_id, 'banner_id', true ) ) {
                            wp_delete_attachment( $existing_banner );
                        }
                        update_post_meta( $store_id, 'banner_id', $attach_id );
                        wp_update_attachment_metadata( $attach_id, RtclFunctions::generate_attachment_metadata( $attach_id, $filename, Functions::get_store_banner_sizes() ) );
                        $src = wp_get_attachment_image_src( $attach_id, 'rtcl-store-banner' );
                        $data = [
                            'banner_id' => $attach_id,
                            'src'       => $src[0]
                        ];
                        $error = false;
                        $msg = esc_html__( "Successfully updated.", "classified-listing-store" );
                    }
                } else {
                    $msg = $status['error'];
                }
            } else {
                $msg = esc_html__( "Banner image should be selected", "classified-listing-store" );
            }
        } else {
            $msg = __( "No store found to upload banner", "classified-listing-store" );
        }


        wp_send_json( [
            'message' => $msg,
            'error'   => $error,
            'data'    => $data
        ] );

    }

    public static function rtcl_admin_ajax_store_logo_upload() {
        if ( !function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }
        $msg = $data = null;
        $error = true;
        $store = get_post( isset( $_POST['store_id'] ) ? absint( $_POST['store_id'] ) : 0 );
        if ( is_object( $store ) && rtclStore()->post_type == $store->post_type ) {
            if ( isset( $_FILES['logo'] ) ) {
                $status = wp_handle_upload( $_FILES['logo'], [
                    'test_form' => false
                ] );
                if ( $status && !isset( $status['error'] ) ) {
                    // $filename should be the path to a file in the upload directory.
                    $filename = $status['file'];

                    // The ID of the post this attachment is for.
                    $store_id = $store->ID;
                    // Check the type of tile. We'll use this as the 'post_mime_type'.
                    $filetype = wp_check_filetype( basename( $filename ), null );

                    // Get the path to the upload directory.
                    $wp_upload_dir = wp_upload_dir();

                    // Prepare an array of post data for the attachment.
                    $attachment = [
                        'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ),
                        'post_mime_type' => $filetype['type'],
                        'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                        'post_content'   => '',
                        'post_status'    => 'inherit'
                    ];

                    // Insert the attachment.
                    $attach_id = wp_insert_attachment( $attachment, $filename, $store_id );
                    if ( !is_wp_error( $attach_id ) ) {
                        if ( $existing_logo = get_post_meta( $store_id, 'logo_id', true ) ) {
                            wp_delete_attachment( $existing_logo );
                        }
                        update_post_meta( $store_id, 'logo_id', $attach_id );
                        wp_update_attachment_metadata( $attach_id, RtclFunctions::generate_attachment_metadata( $attach_id, $filename, Functions::get_store_Logo_sizes() ) );
                        wp_update_attachment_metadata( $attach_id, wp_generate_attachment_metadata( $attach_id, $filename ) );
                        set_post_thumbnail( $store_id, $attach_id );
                        $src = wp_get_attachment_image_src( $attach_id, 'rtcl-store-logo' );
                        $data = [
                            'logo_id' => $attach_id,
                            'src'     => $src[0]
                        ];
                        $error = false;
                        $msg = esc_html__( "Successfully updated.", "classified-listing-store" );
                    }
                } else {
                    $msg = $status['error'];
                }
            } else {
                $msg = esc_html__( "Logo image should be selected", "classified-listing-store" );
            }
        } else {
            $msg = __( "No store found to upload logo", "classified-listing-store" );
        }


        wp_send_json( [
            'message' => $msg,
            'error'   => $error,
            'data'    => $data
        ] );

    }
}