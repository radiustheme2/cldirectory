<?php

namespace RtclStore\Controllers\Ajax;

use Exception;
use Rtcl\Controllers\Hooks\Filters;
use Rtcl\Helpers\Functions;
use Rtcl\Helpers\Link;
use Rtcl\Helpers\Text;
use Rtcl\Models\Listing;
use Rtcl\Resources\Options;
use Rtcl\Services\FormBuilder\FBHelper;
use RtclStore\Helpers\Functions as RtclFunctions;
use RtclStore\Helpers\Functions as StoreFunctions;
use RtclStore\Helpers\StoreManager;
use WP_Error;

class FrontEnd {

    public static function init() {
        add_action( 'wp_ajax_rtcl_update_store_data', [ __CLASS__, 'rtcl_update_store_data' ] );
        add_action( 'wp_ajax_rtcl_ajax_store_banner_upload', [ __CLASS__, 'rtcl_ajax_store_banner_upload' ] );
        add_action( 'wp_ajax_rtcl_ajax_store_banner_delete', [ __CLASS__, 'rtcl_ajax_store_banner_delete' ] );
        add_action( 'wp_ajax_rtcl_ajax_store_logo_upload', [ __CLASS__, 'rtcl_ajax_store_logo_upload' ] );
        add_action( 'wp_ajax_rtcl_ajax_store_logo_delete', [ __CLASS__, 'rtcl_ajax_store_logo_delete' ] );
        add_action( 'wp_ajax_rtcl_ajax_store_send_manager_invitation_by_email', [
            __CLASS__,
            'rtcl_ajax_store_send_manager_invitation_by_email'
        ] );
        add_action( 'wp_ajax_rtcl_ajax_store_search_manager_candidates', [
            __CLASS__,
            'rtcl_ajax_store_search_manager_candidates'
        ] );
        add_action( 'wp_ajax_rtcl_ajax_store_remove_manager_by_user_id', [
            __CLASS__,
            'rtcl_ajax_store_remove_manager_by_user_id'
        ] );
        add_action( 'wp_ajax_rtcl_ajax_store_self_rm_store_manager', [
            __CLASS__,
            'rtcl_ajax_store_self_rm_store_manager'
        ] );

        add_action( 'wp_ajax_rtcl_send_mail_to_store_owner', [ __CLASS__, 'rtcl_send_mail_to_store_owner' ] );
        add_action( 'wp_ajax_nopriv_rtcl_send_mail_to_store_owner', [ __CLASS__, 'rtcl_send_mail_to_store_owner' ] );

        add_action( 'wp_ajax_rtcl_store_ajax_membership_promotion', [ __CLASS__, 'membership_promotion_action' ] );

        // Store Category
        add_action( 'wp_ajax_rtcl_store_get_child_category', [ __CLASS__, 'get_store_child_category' ] );

    }

    /**
     * @param Listing $listing
     * @param         $listingCatId
     * @param         $membership
     *
     * @return array|WP_Error
     */
    private static function renewListingToPublish( Listing $listing, $listingCatId, $membership = false ) {
//		$post_arg         = [
//			'ID'          => $listing->get_id(),
//			'post_status' => 'publish'
//		];
//		$updatedListingId = wp_update_post( $post_arg );
//		if ( is_wp_error( $updatedListingId ) && $updatedListingId->has_errors() ) {
//			return $updatedListingId;
//		}
//		Functions::add_default_expiry_date( $listing->get_id() );
        if ( $membership ) {
            $membership->update_post_count();
        } else {
            try {
                $data = [
                    'post_id'    => $listing->get_id(),
                    'user_id'    => $listing->get_owner_id(),
                    'cat_id'     => $listingCatId,
                    'status'     => 'renew',
                    'created_at' => current_time( 'mysql' )
                ];
                StoreFunctions::update_posting_log( $data );
            } catch ( Exception $exception ) {
                return new WP_Error( 'rtcl_renew_listing_error', __( 'Error while updating listing log', 'classified-listing-store' ) );
            }
        }

        if ( get_post_meta( $listing->get_id(), 'never_expires', true ) ) {
            $expire_at = esc_html__( 'Never Expires', 'classified-listing-store' );
        } else if ( $expiry_date = get_post_meta( $listing->get_id(), 'expiry_date', true ) ) {
            $expire_at = date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
                strtotime( $expiry_date ) );
        } else {
            $expire_at = 'N/A';
        }

        return [
            'expire_at' => $expire_at,
            'status'    => 'publish',
            'message'   => esc_html__( "Your listing is renewed!!", "classified-listing-store" )
        ];
    }

    public static function membership_promotion_action() {
        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( esc_html__( "Authentication error!!", "classified-listing-store" ) );
        }
        $membership = rtclStore()->factory->get_membership();

        $promotion_data = apply_filters( 'rtcl_membership_promotion_process_data', [
            'promotions' => Functions::clean( $_POST['_rtcl_membership_promotions'] ),
            'listing_id' => Functions::clean( $_POST['listing_id'] )
        ], $membership );
        $errors = new WP_Error();
        do_action( 'rtcl_membership_promotion_process_data', $promotion_data, $membership, $_REQUEST, $errors );
        $errors = apply_filters( 'rtcl_membership_promotion_validation_errors', $errors, $promotion_data, $membership, $_REQUEST );
        $response = [];
        if ( $membership ) {
            $response = $membership->apply_promotion( $promotion_data, $errors );
        } else {
            $errors->add( 'rtcl_membership_promotion_no_membership', __( "You have no membership.", "classified-listing-store" ) );
        }
        if ( is_wp_error( $errors ) && $errors->has_errors() ) {
            wp_send_json_error( apply_filters( 'rtcl_membership_promotion_error_data', $errors->get_error_message(), $errors ) );
        } else {
            if ( !empty( $response['success'] ) ) {
                wp_send_json_success( apply_filters( 'rtcl_membership_promotion_success_data', [
                    'redirect_url' => Link::get_my_account_page_link( 'listings' ),
                    'message'      => esc_html__( "Your promotion Successful applied.", "classified-listing-store" )
                ] ) );
            }
        }
    }


    public static function rtcl_send_mail_to_store_owner() {
        $store_id = (int)$_POST["store_id"];
        $name = isset( $_POST["name"] ) ? sanitize_text_field( $_POST["name"] ) : '';
        $email = isset( $_POST["email"] ) ? sanitize_email( $_POST["email"] ) : '';
        $phone = isset( $_POST['phone'] ) ? sanitize_text_field( $_POST['phone'] ) : '';
        $message = isset( $_POST["message"] ) ? stripslashes( wp_kses( nl2br( $_POST["message"] ), [
            'a'      => [
                'href'  => true,
                'title' => true,
            ],
            'br'     => [],
            'ul'     => [],
            'ol'     => [],
            'li'     => [],
            'strong' => []
        ] ) ) : '';
        $data = wp_parse_args( [
            'store_id' => $store_id,
            'name'     => $name,
            'email'    => $email,
            'phone'    => $phone,
            'message'  => $message
        ], $_POST );

        $error = new WP_Error();

        if ( !apply_filters( 'rtcl_listing_form_remove_nonce', false ) && !Functions::verify_nonce() ) {
            $error->add( 'rtcl_session_error', __( "Your session have been expired.", "classified-listing-store" ) );
        }
        if ( !Functions::is_human( 'store_contact' ) ) {
            $error->add( 'rtcl_recaptcha_error', esc_html__( 'Invalid Captcha: Please try again.', 'classified-listing-store' ) );
        }
        $store = rtclStore()->factory->get_store( $store_id );
        if ( !$store ) {
            $error->add( 'rtcl_notfound_error', __( "Store is not selected.", "classified-listing-store" ) );
        }
        $data['store'] = $store;
        do_action( 'rtcl_store_contact_form_validation', $error, $data );

        if ( is_wp_error( $error ) && !empty( $error->errors ) ) {
            wp_send_json_error( [
                'error' => apply_filters( 'rtcl_store_contact_form_error', $error->get_error_message(), $error )
            ] );
        }

        if ( !rtcl()->mailer()->emails['Store_Contact_Email_To_Owner']->trigger( $store_id, $data ) ) {
            wp_send_json_error( [ 'error' => __( "An error to send mail!", "classified-listing-store" ) ] );
        }

        wp_send_json_success( [ 'message' => __( "Your e-mail has been sent!", "classified-listing-store" ) ] );

    }

    public static function rtcl_ajax_store_remove_manager_by_user_id() {
        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        if ( !$store = RtclFunctions::get_current_user_store() ) {
            wp_send_json_error( __( "No store found.", "classified-listing-store" ) );
        }
        if ( empty( $_POST['manager_user_id'] ) || !( $manager_user_id = absint( $_POST['manager_user_id'] ) ) ) {
            wp_send_json_error( __( "Manager id not found.", "classified-listing-store" ) );
        }
        if ( !$user = get_user_by( 'id', $manager_user_id ) ) {
            wp_send_json_error( __( "Manager not found to remove.", "classified-listing-store" ) );
        }
        if ( !in_array( $user->ID, $store->get_manager_ids(), true ) && !in_array( $user->ID, array_keys( $store->get_manager_invitation_list() ) ) ) {
            wp_send_json_error( __( "Manager not exist.", "classified-listing-store" ) );
        }
        wp_send_json_success( [
            'manager_user_id' => $store->remove_manager( $user ),
            'message'         => __( "Successfully removed.", "classified-listing-store" )
        ] );
    }

    public static function rtcl_ajax_store_self_rm_store_manager() {
        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        $current_user_id = get_current_user_id();
        if ( !$store = RtclFunctions::get_manager_store( $current_user_id ) ) {
            wp_send_json_error( __( "No store found.", "classified-listing-store" ) );
        }

        if ( !in_array( $current_user_id, $store->get_manager_ids(), true ) ) {
            wp_send_json_error( __( "Manager not exist.", "classified-listing-store" ) );
        }
        wp_send_json_success( [
            'manager_user_id' => $store->remove_manager( $current_user_id ),
            'message'         => __( "Successfully removed.", "classified-listing-store" )
        ] );
    }

    public static function rtcl_ajax_store_send_manager_invitation_by_email() {
        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        if ( !$store = RtclFunctions::get_current_user_store() ) {
            wp_send_json_error( __( "No store found.", "classified-listing-store" ) );
        }
        // A user picked from the search suggestions is sent by ID; typing an email still works.
        if ( !empty( $_POST['user_id'] ) && absint( $_POST['user_id'] ) ) {
            if ( !$user = get_user_by( 'id', absint( $_POST['user_id'] ) ) ) {
                wp_send_json_error( __( "User not found.", "classified-listing-store" ) );
            }
            $label = StoreManager::display_name( $user );
        } else {
            if ( empty( $_POST['email'] ) || !is_email( wp_unslash( $_POST['email'] ) ) ) {
                wp_send_json_error( __( "Email is not a valid email", "classified-listing-store" ) );
            }
            $email = sanitize_email( wp_unslash( $_POST['email'] ) );
            if ( !$user = get_user_by( 'email', $email ) ) {
                wp_send_json_error( sprintf( __( "User not found using this (%s) email", "classified-listing-store" ), $email ) );
            }
            $label = $email;
        }
        if ( $error = StoreManager::get_add_error( $store, $user, $label ) ) {
            wp_send_json_error( $error );
        }
        if ( !$store->add_to_manager_invitation_list( $user ) ) {
            wp_send_json_error( __( "Internal server error", "classified-listing-store" ) );
        }
        wp_send_json_success( [
            'html'    => StoreManager::get_item_html( $store, $user, true ),
            'message' => sprintf( __( "Manager Invitation is sent to this (%s) user.", "classified-listing-store" ), $label )
        ] );
    }

    /**
     * Search registered users to invite as store manager, by name, username, email or phone.
     * Contact details in the results are partly hidden (see StoreFunctions::mask_email()).
     */
    public static function rtcl_ajax_store_search_manager_candidates() {
        if ( !Functions::verify_nonce() ) {
            wp_send_json_error( __( "Session not valid", "classified-listing-store" ) );
        }
        if ( !StoreFunctions::is_enable_store_manager() || !$store = RtclFunctions::get_current_user_store() ) {
            wp_send_json_error( __( "No store found.", "classified-listing-store" ) );
        }
        $term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

        wp_send_json_success( [ 'users' => StoreManager::search_candidates( $store, $term ) ] );
    }

    public static function rtcl_ajax_store_logo_delete() {
        $error = true;
        $message = null;
        if ( $store = RtclFunctions::get_current_user_store() ) {
            $logo_id = absint( get_post_meta( $store->get_id(), 'logo_id', true ) );
            if ( $logo_id && wp_delete_attachment( $logo_id ) ) {
                delete_post_meta( $store->get_id(), 'logo_id' );
                $error = false;
                $message = esc_html__( "Successfully deleted", "classified-listing-store" );
            } else {
                $message = __( "File could not be deleted.", "classified-listing-store" );
            }
        } else {
            $message = __( "No store found to remove logo", "classified-listing-store" );
        }

        wp_send_json( [
            'error'   => $error,
            'message' => $message
        ] );
    }

    public static function rtcl_ajax_store_banner_delete() {
        $error = true;
        $message = null;
        if ( $store = RtclFunctions::get_current_user_store() ) {
            $banner_id = absint( get_post_meta( $store->get_id(), 'banner_id', true ) );
            if ( $banner_id && wp_delete_attachment( $banner_id ) ) {
                delete_post_meta( $store->get_id(), 'banner_id' );
                $error = false;
                $message = esc_html__( "Successfully deleted", "classified-listing-store" );
            } else {
                $message = __( "File could not be deleted.", "classified-listing-store" );
            }
        } else {
            $message = __( "No store found to remove banner", "classified-listing-store" );
        }

        wp_send_json( [
            'error'   => $error,
            'message' => $message
        ] );
    }

    public static function rtcl_ajax_store_banner_upload() {
        if ( !function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }
        $msg = $data = null;
        $error = true;
        if ( isset( $_FILES['banner'] ) ) {
            Filters::beforeUpload();
            $status = wp_handle_upload( $_FILES['banner'], [
                'test_form' => false
            ] );
            Filters::afterUpload();
            if ( $status && !isset( $status['error'] ) ) {
                // $filename should be the path to a file in the upload directory.
                $filename = $status['file'];

                // The ID of the post this attachment is for.
                $store_id = 0;
                if ( $store = RtclFunctions::get_current_user_store() ) {
                    $store_id = $store->get_id();
                }
                // Check the type of tile. We'll use this as the 'post_mime_type'.
                $filetype = wp_check_filetype( basename( $filename ) );

                // Get the path to the upload directory.
                $wp_upload_dir = wp_upload_dir();

                // Prepare an array of post data for the attachment.
                $attachment = [
                    'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ),
                    'post_mime_type' => $filetype['type'],
                    'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                ];
                $store_owner_id = wp_get_current_user()->ID;

                $new_store_status = Functions::get_option_item( 'rtcl_membership_settings', 'new_store_status', 'publish' );

                // Create a post if does not exist
                if ( $store_id < 1 ) {

                    add_filter( "post_type_link", "__return_empty_string" );

                    $store_id = wp_insert_post( apply_filters( "rtcl_insert_post", [
                        'post_title'      => '',
                        'post_content'    => '',
                        'post_status'     => $new_store_status,
                        'post_author'     => 1,
                        'post_type'       => rtclStore()->post_type,
                        'comments_status' => 'closed',
                        'meta_input'      => [
                            'store_owner_id' => $store_owner_id
                        ]
                    ] ) );

                    remove_filter( "post_type_link", "__return_empty_string" );
                } else {
                    wp_update_post(
                        [
                            'ID'          => $store_id,
                            'post_status' => $new_store_status,
                        ]
                    );
                }

                // Insert the attachment.
                $attach_id = wp_insert_attachment( $attachment, $filename, $store_id );
                if ( !is_wp_error( $attach_id ) ) {
                    if ( $existing_banner = get_post_meta( $store_id, 'banner_id', true ) ) {
                        wp_delete_attachment( $existing_banner );
                    }
                    update_post_meta( $store_id, 'banner_id', $attach_id );
                    wp_update_attachment_metadata( $attach_id, Functions::generate_attachment_metadata( $attach_id, $filename, StoreFunctions::get_store_banner_sizes() ) );
                    $src = wp_get_attachment_image_src( $attach_id, 'rtcl-store-banner' );
                    $data = [
                        'banner_id' => $attach_id,
                        'src'       => $src[0]
                    ];
                    $error = false;
                    $msg = esc_html__( "Successfully updated.", "classified-listing-store" );
                    do_action( 'rtcl_store_meta_data_saved', $store_owner_id, get_post( $store_id ), $_REQUEST );
                }
            } else {
                $msg = $status['error'];
            }
        } else {
            $msg = esc_html__( "Banner image should be selected", "classified-listing-store" );
        }

        wp_send_json( [
            'message' => $msg,
            'error'   => $error,
            'data'    => $data
        ] );

    }

    public static function get_store_child_category() {
        Functions::clear_notices();
        $success = false;
        $message = [];
        $cat_id = isset( $_POST['term_id'] ) ? absint( $_POST['term_id'] ) : 0;
        $child_cats = null;
        if ( $cat_id ) {
            $success = true;
            $childCats = RtclFunctions::get_store_category( $cat_id );
            if ( !empty( $childCats ) ) {
                $child_cats .= sprintf( "<option value=''>%s</option>", esc_html( Text::get_select_category_text() ) );
                foreach ( $childCats as $child_cat ) {
                    $child_cats .= "<option value='{$child_cat->term_id}'>{$child_cat->name}</option>";
                }
            }
        } else {
            Functions::add_notice( __( "Category not selected.", "classified-listing-store" ), 'error' );
        }
        if ( Functions::notice_count( 'error' ) ) {
            $message = Functions::get_notices( 'error' );
        }
        Functions::clear_notices();
        $response = [
            'message'    => $message,
            'success'    => $success,
            'child_cats' => $child_cats,
            'cat_id'     => $cat_id
        ];
        wp_send_json( $response );
    }

    public static function rtcl_ajax_store_logo_upload() {
        if ( !function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }
        $msg = $data = null;
        $error = true;
        if ( isset( $_FILES['logo'] ) ) {
            Filters::beforeUpload();
            $status = wp_handle_upload( $_FILES['logo'], [
                'test_form' => false
            ] );
            Filters::afterUpload();
            if ( $status && !isset( $status['error'] ) ) {
                // $filename should be the path to a file in the upload directory.
                $filename = $status['file'];

                // The ID of the post this attachment is for.
                $store_id = 0;
                if ( $store = RtclFunctions::get_current_user_store() ) {
                    $store_id = $store->get_id();
                }
                // Check the type of tile. We'll use this as the 'post_mime_type'.
                $filetype = wp_check_filetype( basename( $filename ), null );

                // Get the path to the upload directory.
                $wp_upload_dir = wp_upload_dir();

                // Prepare an array of post data for the attachment.
                $attachment = [
                    'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ),
                    'post_mime_type' => $filetype['type'],
                    'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                ];

                $store_owner_id = wp_get_current_user()->ID;

                $new_store_status = Functions::get_option_item( 'rtcl_membership_settings', 'new_store_status', 'publish' );

                // Create post if does not exist
                if ( $store_id < 1 ) {

                    add_filter( "post_type_link", "__return_empty_string" );

                    $store_id = wp_insert_post( apply_filters( "rtcl_insert_post", [
                        'post_title'      => '',
                        'post_content'    => '',
                        'post_status'     => $new_store_status,
                        'post_author'     => 1,
                        'post_type'       => rtclStore()->post_type,
                        'comments_status' => 'closed',
                        'meta_input'      => [
                            'store_owner_id' => wp_get_current_user()->ID
                        ]
                    ] ) );

                    remove_filter( "post_type_link", "__return_empty_string" );
                } else {
                    wp_update_post(
                        [
                            'ID'          => $store_id,
                            'post_status' => $new_store_status,
                        ]
                    );
                }

                // Insert the attachment.
                $attach_id = wp_insert_attachment( $attachment, $filename, $store_id );
                if ( !is_wp_error( $attach_id ) ) {
                    if ( $existing_logo = get_post_meta( $store_id, 'logo_id', true ) ) {
                        wp_delete_attachment( $existing_logo );
                    }
                    update_post_meta( $store_id, 'logo_id', $attach_id );
                    wp_update_attachment_metadata( $attach_id, Functions::generate_attachment_metadata( $attach_id, $filename, StoreFunctions::get_store_Logo_sizes() ) );
	                set_post_thumbnail( $store_id, $attach_id );
					$src = wp_get_attachment_image_src( $attach_id, 'rtcl-store-logo' );
                    $data = [
                        'logo_id' => $attach_id,
                        'src'     => $src[0]
                    ];
                    $error = false;
                    $msg = esc_html__( "Successfully updated.", "classified-listing-store" );
                    do_action( 'rtcl_store_meta_data_saved', $store_owner_id, get_post( $store_id ), $_REQUEST );
                }
            } else {
                $msg = $status['error'];
            }
        } else {
            $msg = esc_html__( "Banner image should be selected", "classified-listing-store" );
        }

        wp_send_json( [
            'message' => $msg,
            'error'   => $error,
            'data'    => $data
        ] );

    }

    public static function rtcl_update_store_data() {
        $error = true;
        $data = [];
        $msg = $getStore = null;
        if ( Functions::verify_nonce() ) {
            $data = $_POST;
            $title = isset( $data['name'] ) ? esc_html( $data['name'] ) : null;
            $slug = isset( $data['id'] ) ? esc_attr( $data['id'] ) : null;
            $content = isset( $data['details'] ) ? esc_textarea( $data['details'] ) : " ";
            $category = isset( $data['store-category'] ) ? absint( $data['store-category'] ) : 0;

            $new_store_status = Functions::get_option_item( 'rtcl_membership_settings', 'new_store_status', 'publish' );

            if ( $title && ( ( isset( $data['id'] ) && $slug ) || ( !isset( $data['id'] ) && !$slug ) ) ) {
                $store_arg = [
                    'post_title'   => $title,
                    'post_name'    => $slug,
                    'post_status'  => $new_store_status,
                    'post_content' => $content
                ];

                $meta = [];
                if ( isset( $data['meta'] ) && !empty( $data['meta'] ) ) {
                    foreach ( $data['meta'] as $mKey => $mValue ) {
                        if ( 'address' == $mKey ) {
                            $meta[$mKey] = sanitize_textarea_field( $mValue );
                        } else if ( 'website' == $mKey ) {
                            $meta[$mKey] = esc_url_raw( $mValue );
                        } else if ( 'email' == $mKey ) {
                            $meta[$mKey] = sanitize_email( $mValue );
                        } else if ( 'social_media' == $mKey ) {
                            $mValue = array_filter( $mValue );
                            $meta[$mKey] = !empty( $mValue ) ? array_map( 'esc_url_raw', $mValue ) : '';
                        } else if ( 'oh_type' == $mKey ) {
                            $meta[$mKey] = in_array( $mValue, [
                                'selected',
                                'always'
                            ] ) ? esc_attr( $mValue ) : 'selected';
                        } else {
                            $meta[$mKey] = Functions::clean( $mValue );
                        }
                    }
                }

                // Server-side validation mirroring the Account Details form:
                // email format, international phone/WhatsApp format, and per-platform
                // social URLs. Uses the raw posted values so the checks match what the
                // user actually typed (the visible phone widget submits the combined
                // "+<dial> <local>" value into meta[phone]/meta[whatsapp]).
                $validation_errors = [];
                $raw_meta          = isset( $data['meta'] ) && is_array( $data['meta'] ) ? wp_unslash( $data['meta'] ) : [];

                if ( ! empty( $raw_meta['email'] ) && ! is_email( trim( $raw_meta['email'] ) ) ) {
                    $validation_errors[] = esc_html__( 'Please enter a valid store email address.', 'classified-listing-store' );
                }

                $phone_fields = [
                    'phone'    => esc_html__( 'Please enter a valid store phone number.', 'classified-listing-store' ),
                    'whatsapp' => esc_html__( 'Please enter a valid store WhatsApp number.', 'classified-listing-store' ),
                ];
                foreach ( $phone_fields as $pf_key => $pf_msg ) {
                    if ( empty( $raw_meta[ $pf_key ] ) ) {
                        continue;
                    }
                    $pf_val    = trim( (string) $raw_meta[ $pf_key ] );
                    $pf_digits = preg_replace( '/[^0-9]/', '', $pf_val );
                    if ( ! preg_match( '/^\+?[0-9\s\-().]+$/', $pf_val ) || strlen( $pf_digits ) < 6 || strlen( $pf_digits ) > 15 ) {
                        $validation_errors[] = $pf_msg;
                    }
                }

                if ( ! empty( $raw_meta['social_media'] ) && is_array( $raw_meta['social_media'] ) ) {
                    $social_labels = Options::get_social_profiles_list();
                    foreach ( $raw_meta['social_media'] as $sm_key => $sm_url ) {
                        $sm_url = trim( (string) $sm_url );
                        if ( '' === $sm_url ) {
                            continue;
                        }
                        $sm_key = sanitize_key( $sm_key );
                        if ( filter_var( $sm_url, FILTER_VALIDATE_URL ) === false || ! FBHelper::social_url_matches_platform( $sm_url, $sm_key ) ) {
                            $sm_label = isset( $social_labels[ $sm_key ] ) ? $social_labels[ $sm_key ] : $sm_key;
                            /* translators: %s: social platform name, e.g. Facebook */
                            $validation_errors[] = sprintf( esc_html__( 'Please enter a valid %s URL', 'classified-listing-store' ), $sm_label );
                        }
                    }
                }

                if ( ! empty( $validation_errors ) ) {
                    wp_send_json( [
                        'error'   => true,
                        'message' => implode( '<br>', $validation_errors ),
                        'data'    => $data,
                    ] );
                }

                $meta = apply_filters( 'rtcl_store_mata_data_before_update', $meta, $data, $_REQUEST );
                $store_owner_id = get_current_user_id();
                if ( $store = RtclFunctions::get_current_user_store() ) {
                    $store_id = $store->get_id();
                    $error = false;
                    $store_arg['ID'] = $store_id;
                    wp_update_post( $store_arg );
                    wp_set_post_terms( $store_id, $category, rtclStore()->category );
                    if ( !empty( $meta ) ) {
                        foreach ( $meta as $mKey => $mValue ) {
                            update_post_meta( $store_id, sanitize_key( $mKey ), $mValue );
                        }
                    }
                    $store_owner_id = absint( get_post_meta( $store->get_id(), 'store_owner_id', true ) );
                    $msg = apply_filters( 'rtcl_store_update_message', __( "Your store is successfully updated.", 'classified-listing-store' ) );
                    do_action( 'rtcl_store_meta_data_saved', $store_owner_id, $store, $_REQUEST );
                } else {
                    $meta['store_owner_id'] = get_current_user_id();
                    $store_arg['meta_input'] = $meta;
                    $store_arg['post_status'] = $new_store_status;
                    $store_arg['post_type'] = rtclStore()->post_type;
                    $store_arg['post_author'] = 1;
                    $store_id = wp_insert_post( $store_arg );
                    if ( !is_wp_error( $store_id ) ) {
                        wp_set_post_terms( $store_id, $category, rtclStore()->category );
                        $error = false;
                        $msg = apply_filters( 'rtcl_store_update_message', __( "Your store is successfully updated.", 'classified-listing-store' ) );
                        do_action( 'rtcl_store_meta_data_saved', $store_owner_id, get_post( $store_id ), $_REQUEST );
                    } else {
                        $msg = $store_id->get_error_message();
                    }

                }

            } else {
                $msg = esc_html__( "Please Select required field.", 'classified-listing-store' );
            }

        } else {
            $msg = "error";
        }

        wp_send_json( [
            'error'    => $error,
            'message'  => $msg,
            'response' => $getStore,
            'data'     => $data,
        ] );
    }

}