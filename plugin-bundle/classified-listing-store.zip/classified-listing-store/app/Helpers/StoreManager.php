<?php

namespace RtclStore\Helpers;

use Rtcl\Helpers\Functions as RtclFunctions;
use RtclStore\Helpers\Functions as StoreFunctions;
use RtclStore\Models\Store;
use WP_User;

/**
 * Shared store-manager logic for My Account > Store > Managers and the
 * "Store Managers" meta box on the store edit screen.
 */
class StoreManager {

	/**
	 * @param WP_User $user
	 *
	 * @return string
	 */
	public static function display_name( $user ) {
		$name = trim( implode( ' ', [ $user->first_name, $user->last_name ] ) );

		return $name ? $name : $user->display_name;
	}

	/**
	 * Only administrators may add a manager without sending an invitation.
	 *
	 * @return bool
	 */
	public static function can_add_directly() {
		$user    = wp_get_current_user();
		$allowed = $user->exists() && ( in_array( 'administrator', (array) $user->roles, true ) || is_super_admin( $user->ID ) );

		return (bool) apply_filters( 'rtcl_store_can_add_manager_directly', $allowed, $user );
	}

	/**
	 * Why this user cannot be invited to / added to the store, or '' when they can.
	 *
	 * @param Store   $store
	 * @param WP_User $user
	 * @param string  $label Name or email shown in the message.
	 * @param bool    $direct Direct add allows converting a pending invitation.
	 *
	 * @return string
	 */
	public static function get_add_error( $store, $user, $label, $direct = false ) {
		if ( $user->ID === $store->owner_id() ) {
			return __( 'This user is the owner of this store.', 'classified-listing-store' );
		}
		if ( in_array( $user->ID, array_map( 'absint', $store->get_manager_ids() ), true ) ) {
			return sprintf( __( 'This (%s) user is already a manager of this store.', 'classified-listing-store' ), $label );
		}
		if ( absint( get_user_meta( $user->ID, '_rtcl_store_id', true ) ) ) {
			return sprintf( __( "This (%s) user already is a manager of a store.", "classified-listing-store" ), $label );
		}
		if ( ! $direct && in_array( $user->ID, array_map( 'absint', array_keys( $store->get_manager_invitation_list() ) ), true ) ) {
			return sprintf( __( "Invitation already send to this (%s) user.", "classified-listing-store" ), $label );
		}

		return '';
	}

	/**
	 * Search registered users by name, username, email or phone number.
	 *
	 * @param Store  $store
	 * @param string $term
	 * @param bool   $mask Partly hide email/phone (store owners); admins see full details.
	 *
	 * @return array[]
	 */
	public static function search_candidates( $store, $term, $mask = true ) {
		$term       = trim( (string) $term );
		$min_length = absint( apply_filters( 'rtcl_store_manager_search_min_length', 2 ) );
		if ( ( function_exists( 'mb_strlen' ) ? mb_strlen( $term ) : strlen( $term ) ) < $min_length ) {
			return [];
		}
		$limit   = max( 1, absint( apply_filters( 'rtcl_store_manager_search_limit', 8 ) ) );
		$exclude = [ $store->owner_id() ];

		// Username, email, nicename and display name.
		$user_ids = get_users( [
			'search'         => '*' . $term . '*',
			'search_columns' => [ 'user_login', 'user_email', 'user_nicename', 'display_name' ],
			'exclude'        => $exclude,
			'number'         => $limit,
			'fields'         => 'ID',
		] );

		// First and last name live in user meta.
		if ( count( $user_ids ) < $limit ) {
			$meta_user_ids = get_users( [
				'meta_query' => [
					'relation' => 'OR',
					[ 'key' => 'first_name', 'value' => $term, 'compare' => 'LIKE' ],
					[ 'key' => 'last_name', 'value' => $term, 'compare' => 'LIKE' ],
				],
				'exclude'    => array_merge( $exclude, array_map( 'absint', $user_ids ) ),
				'number'     => $limit - count( $user_ids ),
				'fields'     => 'ID',
			] );
			$user_ids      = array_merge( $user_ids, $meta_user_ids );
		}

		// Phone numbers are stored in several formats (01712…, +880 1712…), so compare digits only.
		$digits = preg_replace( '/\D/', '', $term );
		if ( count( $user_ids ) < $limit && strlen( $digits ) >= 4 && preg_match( '/^[\d\s+\-().]+$/', $term ) ) {
			global $wpdb;
			// Local "0" prefix vs. international format (e.g. 0171… vs +880 171…).
			$digits      = strlen( ltrim( $digits, '0' ) ) >= 4 ? ltrim( $digits, '0' ) : $digits;
			$phone_value = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(meta_value, ' ', ''), '-', ''), '+', ''), '(', ''), ')', ''), '.', '')";
			$phone_ids   = $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key = '_rtcl_phone' AND {$phone_value} LIKE %s LIMIT %d",
				'%' . $wpdb->esc_like( $digits ) . '%',
				$limit * 2
			) );
			$phone_ids   = array_diff( array_map( 'absint', $phone_ids ), $exclude, array_map( 'absint', $user_ids ) );
			$user_ids    = array_merge( $user_ids, $phone_ids );
		}

		$user_ids    = array_slice( array_unique( array_map( 'absint', $user_ids ) ), 0, $limit );
		$manager_ids = array_map( 'absint', $store->get_manager_ids() );
		$invited_ids = array_map( 'absint', array_keys( $store->get_manager_invitation_list() ) );
		$is_email    = is_email( $term );
		$users       = [];

		foreach ( $user_ids as $user_id ) {
			if ( ! $user = get_user_by( 'id', $user_id ) ) {
				continue;
			}
			if ( in_array( $user_id, $manager_ids, true ) ) {
				$status       = 'manager';
				$status_label = __( 'Already a manager', 'classified-listing-store' );
			} elseif ( in_array( $user_id, $invited_ids, true ) ) {
				$status       = 'pending';
				$status_label = __( 'Invitation pending', 'classified-listing-store' );
			} elseif ( absint( get_user_meta( $user_id, '_rtcl_store_id', true ) ) ) {
				$status       = 'unavailable';
				$status_label = __( 'Manages another store', 'classified-listing-store' );
			} else {
				$status       = 'available';
				$status_label = '';
			}
			$pp_id  = absint( get_user_meta( $user_id, '_rtcl_pp_id', true ) );
			$avatar = $pp_id ? wp_get_attachment_image_url( $pp_id, 'thumbnail' ) : '';
			$phone  = get_user_meta( $user_id, '_rtcl_phone', true );
			if ( $mask ) {
				// The owner already knows an email they typed in full, so show it as is.
				$email = $is_email && 0 === strcasecmp( $term, $user->user_email ) ? $user->user_email : StoreFunctions::mask_email( $user->user_email );
				$phone = StoreFunctions::mask_phone( $phone );
			} else {
				$email = $user->user_email;
				$phone = method_exists( RtclFunctions::class, 'phone_number_has_local_part' ) && ! RtclFunctions::phone_number_has_local_part( $phone ) ? '' : (string) $phone;
			}

			$users[] = apply_filters( 'rtcl_store_manager_search_user_data', [
				'id'           => $user_id,
				'name'         => self::display_name( $user ),
				'username'     => $user->user_login,
				'email'        => $email,
				'phone'        => $phone,
				'avatar'       => $avatar ? $avatar : get_avatar_url( $user_id, [ 'size' => 80 ] ),
				'status'       => $status,
				'status_label' => $status_label,
				'can_invite'   => 'available' === $status,
				// A pending invitee can still be added directly by an administrator.
				'can_add'      => in_array( $status, [ 'available', 'pending' ], true ),
			], $user, $store );
		}

		return $users;
	}

	/**
	 * HTML of one row in the managers list.
	 *
	 * @param Store   $store
	 * @param WP_User $user
	 * @param bool    $is_pending
	 * @param string  $context 'account' (My Account) or 'admin' (store edit screen).
	 *
	 * @return string
	 */
	public static function get_item_html( $store, $user, $is_pending, $context = 'account' ) {
		return RtclFunctions::get_template_html( 'myaccount/store-manager-item', [
			'store'      => $store,
			'user'       => $user,
			'is_pending' => $is_pending,
			'context'    => $context,
		], '', rtclStore()->get_plugin_template_path() );
	}

	/**
	 * Strings and settings for the Invite Manager popup script.
	 *
	 * @param string $context 'account' or 'admin'.
	 *
	 * @return array
	 */
	public static function get_js_options( $context = 'account' ) {
		$can_direct = 'admin' === $context && self::can_add_directly();

		return apply_filters( 'rtcl_store_manager_js_options', [
			"context"           => $context,
			"can_direct"        => $can_direct,
			"email_placeholder" => esc_html__( "Email address", "classified-listing-store" ),
			"add_button_text"   => esc_html__( "Add", "classified-listing-store" ),
			"min_length"        => absint( apply_filters( 'rtcl_store_manager_search_min_length', 2 ) ),
			"title"             => $can_direct ? esc_html__( "Add a store manager", "classified-listing-store" ) : esc_html__( "Invite a store manager", "classified-listing-store" ),
			"subtitle"          => $can_direct ? esc_html__( "Find a registered user, then add them or send an invitation.", "classified-listing-store" ) : esc_html__( "Find a registered user and send them an invitation.", "classified-listing-store" ),
			"search_label"      => esc_html__( "Search user", "classified-listing-store" ),
			"search_hint"       => esc_html__( "Search by name, username, email or phone number", "classified-listing-store" ),
			"searching"         => esc_html__( "Searching…", "classified-listing-store" ),
			"type_more"         => esc_html__( "Keep typing to see suggestions", "classified-listing-store" ),
			"no_results"        => esc_html__( "No users found", "classified-listing-store" ),
			"no_results_hint"   => esc_html__( "The person needs an account on this site before you can invite them.", "classified-listing-store" ),
			"change"            => esc_html__( "Change", "classified-listing-store" ),
			"selected_label"    => esc_html__( "Selected user", "classified-listing-store" ),
			"note"              => $can_direct
				? esc_html__( "Add as Manager gives access right away. Send Invitation emails them to accept first.", "classified-listing-store" )
				: esc_html__( "They will get an email invitation and become a manager after accepting it.", "classified-listing-store" ),
			"cancel"            => esc_html__( "Cancel", "classified-listing-store" ),
			"send"              => esc_html__( "Send Invitation", "classified-listing-store" ),
			"add_direct"        => esc_html__( "Add as Manager", "classified-listing-store" ),
			"select_first"      => esc_html__( "Please select a user from the suggestions.", "classified-listing-store" ),
		], $context );
	}
}
