<?php
/**
 * Store managers panel: My Account > Store > Managers tab and the
 * "Store Managers" meta box on the store edit screen.
 *
 * @author     RadiusTheme
 * @package    classified-listing-store/templates
 * @version    3.2.3.1
 *
 * @var Store  $store
 * @var string $context 'account' (My Account) or 'admin' (store edit screen).
 */

use Rtcl\Helpers\Functions;
use RtclStore\Helpers\StoreManager;
use RtclStore\Models\Store;

defined( 'ABSPATH' ) || exit;

if ( empty( $store ) ) {
	return;
}

$context         = isset( $context ) && 'admin' === $context ? 'admin' : 'account';
$can_direct      = 'admin' === $context && StoreManager::can_add_directly();
$manager_ids     = $store->get_manager_ids();
$invitations     = $store->get_manager_invitation_list();
$invitations_ids = ! empty( $invitations ) ? array_keys( $invitations ) : [];
$manager_users   = [];
foreach ( array_unique( array_merge( $manager_ids, $invitations_ids ) ) as $manager_id ) {
	if ( $manager_user = get_user_by( 'id', $manager_id ) ) {
		$manager_users[] = $manager_user;
	}
}
$button_text = $can_direct ? __( 'Add Manager', 'classified-listing-store' ) : __( 'Invite Manager', 'classified-listing-store' );
$plus_icon   = '<svg width="14" height="14" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M5.525 0.975C5.525 0.436522 5.96152 0 6.5 0C7.03848 0 7.475 0.436522 7.475 0.975V12.025C7.475 12.5635 7.03848 13 6.5 13C5.96152 13 5.525 12.5635 5.525 12.025V0.975Z" fill="currentColor"/><path d="M12.025 5.525C12.5635 5.525 13 5.96152 13 6.5C13 7.03848 12.5635 7.475 12.025 7.475L0.975 7.475C0.436522 7.475 -2.35376e-08 7.03848 0 6.5C2.35376e-08 5.96152 0.436522 5.525 0.975 5.525L12.025 5.525Z" fill="currentColor"/></svg>';
?>
<div id="rtcl-store-managers-content"
	 class="rtcl-store-content rtcl-store-managers-<?php echo esc_attr( $context ); ?><?php echo empty( $manager_users ) ? ' is-empty' : ''; ?>"
	 data-context="<?php echo esc_attr( $context ); ?>"
	 data-store_id="<?php echo absint( $store->get_id() ); ?>">
	<div class="rtcl-store-managers-header">
		<div class="rtcl-store-managers-heading">
			<h3 class="rtcl-store-managers-title">
				<?php esc_html_e( 'Store Managers', 'classified-listing-store' ); ?>
				<span class="rtcl-store-managers-count"><?php echo absint( count( $manager_users ) ); ?></span>
			</h3>
			<p class="rtcl-store-managers-desc"><?php esc_html_e( 'Managers can add and manage listings on behalf of your store.', 'classified-listing-store' ); ?></p>
		</div>
		<div class="rtcl-store-manager-action">
			<button type="button" class="rtcl-store-invite-manager rtcl-btn rtcl-btn-primary">
				<?php echo $plus_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo esc_html( $button_text ); ?>
			</button>
		</div>
	</div>
	<div class="rtcl-store-managers-empty">
		<div class="rtcl-store-managers-empty-icon">
			<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
		</div>
		<h4 class="rtcl-store-managers-empty-title"><?php esc_html_e( 'No managers yet', 'classified-listing-store' ); ?></h4>
		<p class="rtcl-store-managers-empty-text">
			<?php
			if ( $can_direct ) {
				esc_html_e( 'Add team members who can post and manage this store\'s listings. As an administrator you can add them right away or send an email invitation.', 'classified-listing-store' );
			} else {
				esc_html_e( 'Invite team members to help you post and manage your store listings. They will get an email invitation to join.', 'classified-listing-store' );
			}
			?>
		</p>
		<button type="button" class="rtcl-store-invite-manager rtcl-btn rtcl-btn-primary">
			<?php echo $plus_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php echo $can_direct ? esc_html__( 'Add your first manager', 'classified-listing-store' ) : esc_html__( 'Invite your first manager', 'classified-listing-store' ); ?>
		</button>
	</div>
	<div id="rtcl-store-managers">
		<?php
		foreach ( $manager_users as $manager_user ) {
			Functions::get_template( 'myaccount/store-manager-item', [
				'store'      => $store,
				'user'       => $manager_user,
				'is_pending' => in_array( $manager_user->ID, $invitations_ids ),
				'context'    => $context,
			], '', rtclStore()->get_plugin_template_path() );
		}
		?>
	</div>
</div>
