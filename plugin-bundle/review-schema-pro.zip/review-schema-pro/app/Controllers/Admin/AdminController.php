<?php

namespace Rtrsp\Controllers\Admin;

use Rtrsp\Traits\SingletonTrait;

class AdminController {
	/**
	 * Initialize the class.
	 */
	use SingletonTrait;

	/**
	 * Initialize the class.
	 */
	public function init() {
		RtrsLicensing::init();
		// E-Commerce settings fields (moved from free 3.1.4; free keeps the tab).
		\Rtrsp\Modules\Schema\Admin\EcommerceSettings::getInstance();
		// Archive Page settings fields (moved from free 3.1.4; free keeps the sub-tab).
		\Rtrsp\Modules\Schema\Admin\ArchiveSettings::getInstance();
	}
}
