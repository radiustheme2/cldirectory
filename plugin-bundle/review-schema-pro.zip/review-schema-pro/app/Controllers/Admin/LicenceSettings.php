<?php
/**
 * Licensing tab of the SchemaEngine AI settings app (Pro).
 *
 * Moved from the free plugin (3.1.4): the tab, its fields, the masking of the
 * stored key and keep-on-save. The key and status stay in the free option
 * `rtrs_tools_settings`, so activated licences keep working unchanged.
 * Activation, deactivation and the updater live in RtrsLicensing.
 *
 * @package Rtrsp\Controllers\Admin
 */

namespace Rtrsp\Controllers\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class LicenceSettings
 */
class LicenceSettings {

	/**
	 * Option holding the licence key and status.
	 */
	const OPTION = 'rtrs_tools_settings';

	/**
	 * Settings tab key (option name without prefix and suffix).
	 */
	const TAB = 'tools';

	/**
	 * Free version that no longer ships the Licensing tab itself.
	 */
	const MIN_FREE_VERSION = '3.1.4';

	/**
	 * Register hooks. An older free plugin still renders the tab, so stay out.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! defined( 'RTRS_VERSION' ) || version_compare( RTRS_VERSION, self::MIN_FREE_VERSION, '<' ) ) {
			return;
		}
		add_filter( 'rtrs_register_settings_tabs', [ __CLASS__, 'register_tab' ] );
		add_filter( 'rtrs_settings_all_option_fields', [ __CLASS__, 'register_fields' ] );
		add_filter( 'rtrs_settings_redacted_options', [ __CLASS__, 'redact_key' ] );
		add_filter( 'rtrs_settings_api_sanitized_fields_' . self::OPTION, [ __CLASS__, 'sanitize_on_save' ] );
		add_filter( 'rtrs_settings_app_params', [ __CLASS__, 'app_params' ] );
	}

	/**
	 * Add the Licensing tab, before Migration like the free plugin did.
	 *
	 * @param array $tabs Settings tabs.
	 * @return array
	 */
	public static function register_tab( $tabs ) {
		if ( ! is_array( $tabs ) || isset( $tabs[ self::TAB ] ) ) {
			return $tabs;
		}
		$tab = [
			self::TAB => [
				'iconHtml' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"/><circle cx="16.5" cy="7.5" r=".5" fill="currentColor"/></svg>',
				'label'    => esc_html__( 'Licensing', 'review-schema-pro' ),
			],
		];
		$position = array_search( 'migration', array_keys( $tabs ), true );
		if ( false === $position ) {
			return $tabs + $tab;
		}

		return array_slice( $tabs, 0, $position, true ) + $tab + array_slice( $tabs, $position, null, true );
	}

	/**
	 * Fields of the Licensing tab.
	 *
	 * Keeps the free `rtrs_tools_settings_options` filter so RtrsLicensing
	 * (and any third party) can still adjust the fields.
	 *
	 * @param array $fields Settings fields keyed by tab.
	 * @return array
	 */
	public static function register_fields( $fields ) {
		if ( ! is_array( $fields ) ) {
			return $fields;
		}
		$options = [
			'site_section' => [
				'title' => esc_html__( 'Licensing', 'review-schema-pro' ),
				'type'  => 'title',
			],
			'license_key'  => [
				'title' => esc_html__( 'Main plugin license key', 'review-schema-pro' ),
				'type'  => 'text',
				'class' => 'regular-text',
			],
		];

		$fields[ self::TAB ] = apply_filters( 'rtrs_tools_settings_options', $options );

		return $fields;
	}

	/**
	 * Send a masked placeholder instead of the stored key to the browser.
	 *
	 * The key is a paid credential and the server reads it from the option,
	 * so the settings page never needs its value.
	 *
	 * @param array $options Settings keyed by option name.
	 * @return array
	 */
	public static function redact_key( $options ) {
		if ( isset( $options[ self::OPTION ]['license_key'] )
			&& is_string( $options[ self::OPTION ]['license_key'] )
			&& '' !== $options[ self::OPTION ]['license_key'] ) {
			$options[ self::OPTION ]['license_key'] = self::mask( $options[ self::OPTION ]['license_key'] );
		}

		return $options;
	}

	/**
	 * Sanitize the Licensing tab on save and keep what the form cannot change.
	 *
	 * A mask-shaped key means "unchanged" (also a stale mask from a page loaded
	 * before the key changed elsewhere), so the stored key is kept. An empty
	 * value clears it; anything else replaces it. The licence status and expiry
	 * are written only by activation, never taken from the form, and are dropped
	 * when the key changes or is cleared (the new key needs activating).
	 *
	 * Runs inside the free settings save, which already checked
	 * manage_options and the settings nonce.
	 *
	 * @param mixed $settings Submitted Licensing settings.
	 * @return array
	 */
	public static function sanitize_on_save( $settings ) {
		$settings = is_array( $settings ) ? $settings : [];
		$stored   = get_option( self::OPTION, [] );
		$stored   = is_array( $stored ) ? $stored : [];
		$managed  = [ 'license_key', 'license_status', 'expires' ];
		$clean    = [];

		// Keep other fields an extension may add to this tab, sanitized. Names are
		// normalised first, so `License_Status` cannot slip past the managed list.
		foreach ( $settings as $field => $value ) {
			$field = sanitize_key( (string) $field );
			if ( '' === $field || in_array( $field, $managed, true ) ) {
				continue;
			}
			$clean[ $field ] = map_deep( $value, 'sanitize_text_field' );
		}

		$stored_key = isset( $stored['license_key'] ) ? (string) $stored['license_key'] : '';
		$key        = isset( $settings['license_key'] ) && is_string( $settings['license_key'] ) ? trim( sanitize_text_field( $settings['license_key'] ) ) : '';
		if ( 1 === preg_match( '/^\*{8}/', $key ) ) {
			$key = $stored_key;
		}
		$clean['license_key'] = $key;

		// Status and expiry come only from activation, and only while the key is unchanged.
		if ( '' !== $key && $key === $stored_key ) {
			foreach ( [ 'license_status', 'expires' ] as $server_key ) {
				if ( isset( $stored[ $server_key ] ) ) {
					$clean[ $server_key ] = $stored[ $server_key ];
				}
			}
		}

		return $clean;
	}

	/**
	 * Tell the settings app whether the stored licence is active.
	 *
	 * @param array $params Localized settings app data.
	 * @return array
	 */
	public static function app_params( $params ) {
		if ( is_array( $params ) ) {
			$params['hasValidLicence'] = self::is_active();
		}

		return $params;
	}

	/**
	 * Whether the stored licence status is valid.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$settings = get_option( self::OPTION, [] );

		return is_array( $settings ) && ! empty( $settings['license_status'] ) && 'valid' === $settings['license_status'];
	}

	/**
	 * Masked placeholder: 8 asterisks plus the key's last four characters.
	 *
	 * @param string $key Stored licence key.
	 * @return string
	 */
	private static function mask( $key ) {
		$key  = (string) $key;
		$tail = strlen( $key ) > 4 ? substr( $key, -4 ) : '';

		return str_repeat( '*', 8 ) . $tail;
	}
}
