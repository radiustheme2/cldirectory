<?php
/**
 * Pro Product Extractor - WooCommerce/EDD product data extraction and schema filling (Pro feature).
 *
 * Builds the WooCommerce/EDD product data (moved from the free ContentExtractor)
 * and post-processes offers (moved from the free SchemaExtractor).
 *
 * Hooks into the free plugin's `rtrs_ai_extract_wc_product_data`,
 * `rtrs_ai_extract_edd_product_data`, `rtrs_ai_fill_product_schema`,
 * and `rtrs_ai_type_template` filters.
 *
 * @package Rtrsp\AI
 * @since   1.0.0
 */

namespace Rtrsp\AI;

use Rtrs\AI\AIInit;
use Rtrsp\Helpers\FnsPro;

defined( 'ABSPATH' ) || exit;

class ProProductExtractor {

	/**
	 * Extract WooCommerce product data (Pro feature).
	 *
	 * @param null     $default Default null from free plugin.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return array|null Product data or null.
	 */
	public static function extract_wc_product_data( $default, $post ) {
		// Password-protected: no product/course data reaches the AI or saved schema.
		if ( FnsPro::is_schema_protected( $post ) ) {
			return $default;
		}

		return self::build_woocommerce_product_data( $post );
	}

	/**
	 * Extract EDD product data (Pro feature).
	 *
	 * @param null     $default Default null from free plugin.
	 * @param \WP_Post $post    Post object.
	 *
	 * @return array|null Product data or null.
	 */
	public static function extract_edd_product_data( $default, $post ) {
		// Password-protected: no product/course data reaches the AI or saved schema.
		if ( FnsPro::is_schema_protected( $post ) ) {
			return $default;
		}

		return self::build_edd_product_data( $post );
	}

	/**
	 * Get Product AI prompt template.
	 *
	 * @param string $template    Existing template (empty for pro-gated types).
	 * @param string $type        Schema type name.
	 * @param string $entity_type Entity type (Organization/Person).
	 *
	 * @return string Template string.
	 */
	public static function get_product_template( $template, $type, $entity_type ) {
		if ( 'Product' !== $type ) {
			return $template;
		}

		$entity_frag = ( 'Person' === $entity_type ) ? 'person' : 'organization';

		return <<<TPL
Required fields for Product:
- name, description, image
- brand (if available)
- sku (if available)
- aggregateRating (if reviews exist)

offers MUST be an array. Use the correct offer type based on the product:

Variable product (price range) → AggregateOffer:
- @type: AggregateOffer
- price, priceCurrency (direct children of offer — required by Google)
- lowPrice, highPrice, offerCount
- priceSpecification: array of UnitPriceSpecification (use priceType "https://schema.org/SalePrice" for sale price)
- priceValidUntil, availability, url
- seller: {"@id": "{site_url}/#{$entity_frag}"} (reference to global entity — do NOT inline Organization)

Simple product → Offer:
- @type: Offer
- price, priceCurrency (direct children of offer — required by Google)
- priceSpecification: array of UnitPriceSpecification
  - Current/sale price entry (with priceType "https://schema.org/SalePrice" if on sale)
  - Regular/list price entry (with priceType "https://schema.org/ListPrice") when product is on sale
- Each UnitPriceSpecification includes: price, priceCurrency, valueAddedTaxIncluded (boolean), validThrough
- priceValidUntil, availability, url
- seller: {"@id": "{site_url}/#{$entity_frag}"} (reference to global entity — do NOT inline Organization)
TPL;
	}

	/**
	 * Fill missing Product schema fields from extracted WC/EDD product data.
	 *
	 * @param array  $schema    The Product schema node.
	 * @param array  $primary   Primary content signals.
	 * @param array  $secondary Secondary content signals.
	 * @param string $permalink Post permalink.
	 * @param string $entity_id Entity @id reference.
	 *
	 * @return array Modified schema.
	 */
	public static function fill_product( $schema, $primary, $secondary, $permalink, $entity_id = '' ) {
		$wc  = $secondary['wc_product'] ?? [];
		$edd = $secondary['edd_product'] ?? [];

		if ( empty( $wc ) && empty( $edd ) ) {
			return $schema;
		}

		if ( empty( $schema['name'] ) && ! empty( $primary['title'] ) ) {
			$schema['name'] = $primary['title'];
		}

		if ( empty( $schema['description'] ) && ! empty( $primary['excerpt'] ) ) {
			$schema['description'] = mb_substr( $primary['excerpt'], 0, 200 );
		}

		if ( empty( $schema['url'] ) && ! empty( $primary['permalink'] ) ) {
			$schema['url'] = $primary['permalink'];
		}

		if ( empty( $schema['image'] ) ) {
			$images = [];

			if ( ! empty( $primary['featured_image']['url'] ) ) {
				$fi       = $primary['featured_image'];
				$images[] = array_filter(
					[
						'@type'  => 'ImageObject',
						'url'    => $fi['url'],
						'width'  => $fi['width'] ?? null,
						'height' => $fi['height'] ?? null,
					]
				);
			}

			if ( ! empty( $wc['gallery'] ) ) {
				foreach ( $wc['gallery'] as $img ) {
					$images[] = array_filter(
						[
							'@type'  => 'ImageObject',
							'url'    => $img['url'],
							'width'  => $img['width'] ?? null,
							'height' => $img['height'] ?? null,
						]
					);
				}
			}

			if ( count( $images ) === 1 ) {
				$schema['image'] = $images[0];
			} elseif ( ! empty( $images ) ) {
				$schema['image'] = $images;
			}
		}

		if ( empty( $schema['sku'] ) ) {
			$sku = $wc['sku'] ?? $edd['sku'] ?? '';
			if ( ! empty( $sku ) ) {
				$schema['sku'] = $sku;
			}
		}

		if ( ! empty( $wc['gtin'] ) ) {
			$gtin = $wc['gtin'];
			$len  = strlen( preg_replace( '/[^0-9]/', '', $gtin ) );

			if ( empty( $schema['gtin13'] ) && $len === 13 ) {
				$schema['gtin13'] = $gtin;
			} elseif ( empty( $schema['gtin8'] ) && $len === 8 ) {
				$schema['gtin8'] = $gtin;
			} elseif ( empty( $schema['gtin14'] ) && $len === 14 ) {
				$schema['gtin14'] = $gtin;
			} elseif ( empty( $schema['gtin'] ) ) {
				$schema['gtin'] = $gtin;
			}
		}

		// Brand - check product-level first, then fall back to global settings.
		if ( empty( $schema['brand'] ) ) {
			$brand_name = $wc['brand'] ?? $edd['brand'] ?? '';

			// Fallback to global ecommerce settings.
			if ( empty( $brand_name ) ) {
				$ecommerce_settings = get_option( 'rtrs_schema_ecommerce_settings', [] );
				$brand_name         = $ecommerce_settings['brand_name'] ?? '';
			}

			if ( ! empty( $brand_name ) ) {
				$schema['brand'] = [
					'@type' => 'Brand',
					'name'  => $brand_name,
				];
			}
		}

		$cats = $wc['categories'] ?? $edd['categories'] ?? [];
		if ( empty( $schema['category'] ) && ! empty( $cats ) ) {
			$schema['category'] = implode( ' > ', $cats );
		}

		if ( ! empty( $wc['attributes'] ) ) {
			$attr_map = [
				'color'    => 'color',
				'colour'   => 'color',
				'size'     => 'size',
				'material' => 'material',
				'pattern'  => 'pattern',
			];

			foreach ( $wc['attributes'] as $name => $value ) {
				$lower = strtolower( $name );

				if ( isset( $attr_map[ $lower ] ) && empty( $schema[ $attr_map[ $lower ] ] ) ) {
					$schema[ $attr_map[ $lower ] ] = $value;
				}
			}
		}

		if ( empty( $schema['weight'] ) && ! empty( $wc['weight'] ) ) {
			$wu_map = [
				'kg'  => 'KGM',
				'g'   => 'GRM',
				'lbs' => 'LBR',
				'oz'  => 'ONZ',
			];
			$parts = explode( ' ', $wc['weight'] );
			$unit  = ( count( $parts ) === 2 && isset( $wu_map[ $parts[1] ] ) ) ? $wu_map[ $parts[1] ] : 'GRM';

			$schema['weight'] = [
				'@type'    => 'QuantitativeValue',
				'value'    => (float) $parts[0],
				'unitCode' => $unit,
			];
		}

		if ( empty( $schema['offers'] ) && ! empty( $wc['pricing'] ) ) {
			$pricing      = $wc['pricing'];
			$currency     = $pricing['currency'] ?? 'USD';
			$tax_included = ! empty( $wc['prices_include_tax'] );
			$product_url  = $primary['permalink'] ?? '';
			$availability = $wc['availability'] ?? '';

			$price_valid_until = '';

			if ( ! empty( $pricing['sale_date_to'] ) ) {
				$price_valid_until = substr( $pricing['sale_date_to'], 0, 10 );
			} else {
				// Default to 1 year from now.
				$price_valid_until = gmdate( 'Y-m-d', strtotime( '+1 year' ) );
			}

			$seller = [ '@id' => $entity_id ];

			if ( ! empty( $pricing['min_price'] ) && ! empty( $pricing['max_price'] )
				&& $pricing['min_price'] !== $pricing['max_price'] ) {

				$offer = [
					'@type'           => 'AggregateOffer',
					'lowPrice'        => $pricing['min_price'],
					'highPrice'       => $pricing['max_price'],
					'offerCount'      => ! empty( $wc['variation_count'] ) ? (int) $wc['variation_count'] : null,
					'price'           => $pricing['min_price'],
					'priceCurrency'   => $currency,
					'priceValidUntil' => $price_valid_until,
					'availability'    => $availability,
					'url'             => $product_url,
					'seller'          => $seller,
				];

				if ( ! empty( $pricing['on_sale'] ) ) {
					$offer['priceSpecification'] = [
						[
							'@type'                 => 'UnitPriceSpecification',
							'priceType'             => 'https://schema.org/SalePrice',
							'price'                 => $pricing['min_price'],
							'priceCurrency'         => $currency,
							'valueAddedTaxIncluded' => $tax_included,
							'validThrough'          => $price_valid_until,
						],
					];
				}

				if ( null === $offer['offerCount'] ) {
					unset( $offer['offerCount'] );
				}

				$schema['offers'] = [ $offer ];
			} else {
				$current_price = $pricing['price'] ?? $pricing['regular_price'] ?? '';

				$offer = [
					'@type'           => 'Offer',
					'price'           => $current_price,
					'priceCurrency'   => $currency,
					'priceValidUntil' => $price_valid_until,
					'availability'    => $availability,
					'url'             => $product_url,
					'seller'          => $seller,
				];

				$price_specs = [];

				if ( '' !== $current_price ) {
					$price_specs[] = [
						'@type'                 => 'UnitPriceSpecification',
						'price'                 => $current_price,
						'priceCurrency'         => $currency,
						'valueAddedTaxIncluded' => $tax_included,
						'validThrough'          => $price_valid_until,
					];
				}

				if ( ! empty( $pricing['on_sale'] ) && ! empty( $pricing['regular_price'] )
					&& $pricing['regular_price'] !== $current_price ) {
					$price_specs[] = [
						'@type'                 => 'UnitPriceSpecification',
						'price'                 => $pricing['regular_price'],
						'priceCurrency'         => $currency,
						'valueAddedTaxIncluded' => $tax_included,
						'validThrough'          => $price_valid_until,
						'priceType'             => 'https://schema.org/ListPrice',
					];
				}

				if ( ! empty( $price_specs ) ) {
					$offer['priceSpecification'] = $price_specs;
				}

				$schema['offers'] = [ $offer ];
			}
		}

		// Build offers from EDD product data (variable pricing = multiple offers, simple = single offer).
		if ( empty( $schema['offers'] ) && ! empty( $edd['pricing'] ) ) {
			$product_url = $primary['permalink'] ?? '';
			$seller      = [ '@id' => $entity_id ];

			// Default to 1 year from now for EDD products.
			$edd_price_valid_until = gmdate( 'Y-m-d', strtotime( '+1 year' ) );

			if ( ! empty( $edd['variations']['items'] ) ) {
				$offers = [];

				foreach ( $edd['variations']['items'] as $item ) {
					$item_price    = $item['price'] ?? '';
					$item_currency = $item['currency'] ?? $edd['pricing']['currency'] ?? 'USD';

					if ( '' !== $item_price && (float) $item_price > 0 ) {
						$offer = [
							'@type'           => 'Offer',
							'price'           => $item_price,
							'priceCurrency'   => $item_currency,
							'priceValidUntil' => $edd_price_valid_until,
							'availability'    => 'https://schema.org/InStock',
							'url'             => $product_url,
							'seller'          => $seller,
						];

						if ( ! empty( $item['name'] ) ) {
							$offer['name'] = $item['name'];
						}

						$offers[] = $offer;
					}
				}

				if ( ! empty( $offers ) ) {
					$schema['offers'] = $offers;
				}
			} else {
				$price    = $edd['pricing']['price'] ?? '';
				$currency = $edd['pricing']['currency'] ?? 'USD';

				if ( '' !== $price && (float) $price > 0 ) {
					$schema['offers'] = [
						[
							'@type'           => 'Offer',
							'price'           => $price,
							'priceCurrency'   => $currency,
							'priceValidUntil' => $edd_price_valid_until,
							'availability'    => 'https://schema.org/InStock',
							'url'             => $product_url,
							'seller'          => $seller,
						],
					];
				}
			}
		}

		if ( empty( $schema['aggregateRating'] ) && ! empty( $wc['reviews'] ) ) {
			$reviews = $wc['reviews'];

			if ( ! empty( $reviews['review_count'] ) && $reviews['review_count'] > 0 && ! empty( $reviews['average_rating'] ) ) {
				$rating = [
					'@type'       => 'AggregateRating',
					'ratingValue' => (float) FnsPro::rating_value( $reviews['average_rating'] ),
					'bestRating'  => 5,
					'worstRating' => 1,
				];

				if ( ! empty( $reviews['review_count'] ) ) {
					$rating['reviewCount'] = (int) $reviews['review_count'];
				}

				if ( ! empty( $reviews['rating_counts'] ) && is_array( $reviews['rating_counts'] ) ) {
					$rating['ratingCount'] = (int) array_sum( $reviews['rating_counts'] );
				} elseif ( ! empty( $reviews['review_count'] ) ) {
					$rating['ratingCount'] = (int) $reviews['review_count'];
				}

				$schema['aggregateRating'] = $rating;
			}
		}

		if ( empty( $schema['review'] ) && ! empty( $wc['reviews']['items'] ) ) {
			$review_schemas = [];
			// Limit to top 2 best-rated reviews to keep schema lightweight.
			$items = $wc['reviews']['items'];
			usort(
				$items,
				function ( $a, $b ) {
					return ( (float) ( $b['rating'] ?? 0 ) ) <=> ( (float) ( $a['rating'] ?? 0 ) );
				}
			);
			$items = array_slice( $items, 0, 2 );

			foreach ( $items as $rev ) {
				$review_obj = [
					'@type'         => 'Review',
					'author'        => [
						'@type' => 'Person',
						'name'  => $rev['author'] ?? 'Anonymous',
					],
					'datePublished' => $rev['date'] ?? '',
				];

				if ( ! empty( $rev['rating'] ) ) {
					$review_obj['reviewRating'] = [
						'@type'       => 'Rating',
						'ratingValue' => (float) FnsPro::rating_value( $rev['rating'] ),
						'bestRating'  => 5,
						'worstRating' => 1,
					];
				}

				if ( ! empty( $rev['text'] ) ) {
					$review_obj['reviewBody'] = $rev['text'];
				}

				$review_schemas[] = array_filter( $review_obj );
			}

			if ( ! empty( $review_schemas ) ) {
				$schema['review'] = $review_schemas;
			}
		}

		return $schema;
	}

	/**
	 * Remove a redundant ListPrice/SalePrice pair from every generated node's offers.
	 *
	 * Moved from the free SchemaExtractor (only Pro's product extractors and
	 * templates produce priceSpecification). Hooked to rtrs_ai_generated_schemas
	 * at priority 5, before the Product/SoftwareApplication merge.
	 *
	 * @param array $schemas Generated schema nodes.
	 * @return array
	 */
	public static function deduplicate_offer_price_specifications( $schemas ) {
		if ( ! is_array( $schemas ) ) {
			return $schemas;
		}
		foreach ( $schemas as &$schema ) {
			if ( is_array( $schema ) && ! empty( $schema['offers'] ) && is_array( $schema['offers'] ) ) {
				self::deduplicate_price_specifications( $schema['offers'] );
			}
		}
		unset( $schema );

		return $schemas;
	}

	/**
	 * Remove duplicate priceSpecification entries from offers.
	 *
	 * When ListPrice and SalePrice have the same price value (product not on sale),
	 * keep only one entry without priceType to avoid redundant data.
	 *
	 * @param array $offers Offers array (by reference).
	 */
	private static function deduplicate_price_specifications( &$offers ) {
		// Single offer object.
		if ( isset( $offers['@type'] ) ) {
			self::deduplicate_single_offer_specs( $offers );

			// AggregateOffer with nested offers.
			if ( ! empty( $offers['offers'] ) && is_array( $offers['offers'] ) ) {
				foreach ( $offers['offers'] as &$nested ) {
					if ( is_array( $nested ) ) {
						self::deduplicate_single_offer_specs( $nested );
					}
				}
				unset( $nested );
			}

			return;
		}

		// Array of offers.
		if ( isset( $offers[0] ) ) {
			foreach ( $offers as &$offer ) {
				if ( is_array( $offer ) ) {
					self::deduplicate_price_specifications( $offer );
				}
			}
			unset( $offer );
		}
	}

	/**
	 * Deduplicate priceSpecification on a single offer.
	 *
	 * @param array $offer Single offer (by reference).
	 */
	private static function deduplicate_single_offer_specs( &$offer ) {
		if ( empty( $offer['priceSpecification'] ) || ! is_array( $offer['priceSpecification'] ) ) {
			return;
		}

		$specs = $offer['priceSpecification'];
		if ( count( $specs ) < 2 ) {
			return;
		}

		// Collect prices by priceType.
		$list_price = null;
		$sale_price = null;

		foreach ( $specs as $spec ) {
			$type = $spec['priceType'] ?? '';
			if ( 'https://schema.org/ListPrice' === $type ) {
				$list_price = (string) ( $spec['price'] ?? '' );
			} elseif ( 'https://schema.org/SalePrice' === $type ) {
				$sale_price = (string) ( $spec['price'] ?? '' );
			}
		}

		// If both exist with same price, keep only one entry (the current price).
		if ( null !== $list_price && null !== $sale_price && $list_price === $sale_price ) {
			$offer['priceSpecification'] = [
				array_filter(
					[
						'@type'                 => 'UnitPriceSpecification',
						'price'                 => $list_price,
						'priceCurrency'         => $specs[0]['priceCurrency'] ?? null,
						'valueAddedTaxIncluded' => $specs[0]['valueAddedTaxIncluded'] ?? null,
					]
				),
			];
		}
	}

	/**
	 * Merge Product and SoftwareApplication into a single combined schema node.
	 *
	 * When both Product and SoftwareApplication are present in the schemas array,
	 * they are merged into one node with @type: ["Product", "SoftwareApplication"].
	 * Product schema is used as the base; SoftwareApplication-specific properties
	 * (applicationCategory, operatingSystem, author) are copied over.
	 *
	 * Hooked to: rtrs_ai_generated_schemas (runs after all individual schema processing).
	 *
	 * @param array $schemas      Array of schema objects.
	 * @param array $full_payload Full content payload.
	 *
	 * @return array Modified schemas array.
	 */
	public static function merge_product_software_application( $schemas, $full_payload ) {
		$product_index  = null;
		$software_index = null;

		foreach ( $schemas as $index => $schema ) {
			$type = $schema['@type'] ?? '';

			if ( 'Product' === $type || 'ProductGroup' === $type ) {
				$product_index = $index;
			} elseif ( 'SoftwareApplication' === $type ) {
				$software_index = $index;
			}
		}

		// Only merge when both types are present.
		if ( null === $product_index || null === $software_index ) {
			return $schemas;
		}

		$product  = $schemas[ $product_index ];
		$software = $schemas[ $software_index ];

		$is_product_group = 'ProductGroup' === ( $product['@type'] ?? '' );

		// If ProductGroup, convert hasVariant into AggregateOffer with nested offers.
		if ( $is_product_group && ! empty( $product['hasVariant'] ) ) {
			$product = self::convert_product_group_to_aggregate_offer( $product );
		}

		// Combine @type as array — always use "Product" (not ProductGroup).
		$product['@type'] = [ 'Product', 'SoftwareApplication' ];

		// Fix @id if it was changed to #productgroup.
		if ( ! empty( $product['@id'] ) ) {
			$product['@id'] = str_replace( '#productgroup', '#product', $product['@id'] );
		}

		// Remove ProductGroup-specific properties.
		unset( $product['productGroupID'], $product['variesBy'], $product['hasVariant'] );

		// Copy SoftwareApplication-specific properties if not already set on Product.
		$software_props = [ 'applicationCategory', 'operatingSystem', 'author' ];

		foreach ( $software_props as $prop ) {
			if ( ! empty( $software[ $prop ] ) && empty( $product[ $prop ] ) ) {
				$product[ $prop ] = $software[ $prop ];
			}
		}

		// Sanitize AggregateOffer: move shared properties to parent level,
		// ensure nested offers is a clean sequential array.
		self::sanitize_aggregate_offer( $product );

		// Strip priceSpecification from offers — not valid for SoftwareApplication.
		self::strip_price_specification( $product );

		// Replace the Product entry with the merged schema and remove SoftwareApplication.
		$schemas[ $product_index ] = $product;
		unset( $schemas[ $software_index ] );

		return array_values( $schemas );
	}

	/**
	 * Normalize offers for SoftwareApplication schemas.
	 *
	 * When a SoftwareApplication (standalone or combined with Product) has multiple
	 * individual Offer objects, converts them into a single AggregateOffer with nested
	 * offers. Also sanitizes corrupted AggregateOffer structures and strips
	 * priceSpecification (not valid for SoftwareApplication).
	 *
	 * Runs at priority 11 (after merge_product_software_application at priority 10).
	 *
	 * @param array $schemas      Array of schema objects.
	 * @param array $full_payload Full content payload.
	 *
	 * @return array Modified schemas array.
	 */
	public static function normalize_software_application_offers( $schemas, $full_payload ) {
		$software_types = [ 'SoftwareApplication', 'WebApplication', 'MobileApplication' ];

		foreach ( $schemas as &$schema ) {
			$type = $schema['@type'] ?? '';

			// Check if SoftwareApplication (or variant) is in the @type.
			$is_software = false;
			if ( is_array( $type ) ) {
				$is_software = ! empty( array_intersect( $type, $software_types ) );
			} else {
				$is_software = in_array( $type, $software_types, true );
			}

			if ( ! $is_software || empty( $schema['offers'] ) || ! is_array( $schema['offers'] ) ) {
				continue;
			}

			// Convert multiple Offer objects to AggregateOffer with nested offers.
			self::convert_multiple_offers_to_aggregate( $schema );

			// Fill flat AggregateOffer with nested variation offers from WC/SureCart data.
			self::fill_aggregate_variation_offers( $schema, $full_payload );

			// Sanitize AggregateOffer nested offers structure.
			self::sanitize_aggregate_offer( $schema );

			// Strip priceSpecification — not valid for SoftwareApplication.
			self::strip_price_specification( $schema );
		}
		unset( $schema );

		return $schemas;
	}

	/**
	 * Convert a ProductGroup schema with hasVariant into a Product with AggregateOffer.
	 *
	 * Instead of ProductGroup + hasVariant (each variant being a separate Product),
	 * this creates a single Product with an AggregateOffer containing nested Offer
	 * objects for each variation. Used when combining Product + SoftwareApplication.
	 *
	 * @param array $schema ProductGroup schema with hasVariant.
	 *
	 * @return array Modified schema with AggregateOffer containing nested offers.
	 */
	private static function convert_product_group_to_aggregate_offer( $schema ) {
		$variants = $schema['hasVariant'] ?? [];

		if ( empty( $variants ) ) {
			return $schema;
		}

		// Collect individual offers from each variant.
		$nested_offers     = [];
		$prices            = [];
		$currency          = 'USD';
		$availability      = '';
		$seller            = [];
		$price_valid_until = '';
		$shipping_refs     = [];
		$return_policy     = [];

		foreach ( $variants as $variant ) {
			$variant_offer = $variant['offers'] ?? null;

			if ( empty( $variant_offer ) ) {
				continue;
			}

			// Extract pricing info for AggregateOffer calculations.
			$price = $variant_offer['price'] ?? '';
			if ( '' !== $price && is_numeric( $price ) ) {
				$prices[] = (float) $price;
			}

			if ( ! empty( $variant_offer['priceCurrency'] ) ) {
				$currency = $variant_offer['priceCurrency'];
			}

			// Capture shared properties from the first variant (for AggregateOffer level).
			if ( empty( $availability ) && ! empty( $variant_offer['availability'] ) ) {
				$availability = $variant_offer['availability'];
			}
			if ( empty( $seller ) && ! empty( $variant_offer['seller'] ) ) {
				$seller = $variant_offer['seller'];
			}
			if ( empty( $price_valid_until ) && ! empty( $variant_offer['priceValidUntil'] ) ) {
				$price_valid_until = $variant_offer['priceValidUntil'];
			}
			if ( empty( $shipping_refs ) && ! empty( $variant_offer['shippingDetails'] ) ) {
				$shipping_refs = $variant_offer['shippingDetails'];
			}
			if ( empty( $return_policy ) && ! empty( $variant_offer['hasMerchantReturnPolicy'] ) ) {
				$return_policy = $variant_offer['hasMerchantReturnPolicy'];
			}

			// Build the nested Offer (only variant-specific props, no shared props).
			$offer = [
				'@type'         => 'Offer',
				'price'         => $variant_offer['price'] ?? '',
				'priceCurrency' => $variant_offer['priceCurrency'] ?? $currency,
				'availability'  => $variant_offer['availability'] ?? $availability,
				'url'           => $variant_offer['url'] ?? '',
			];

			if ( ! empty( $variant['name'] ) ) {
				$offer['name'] = $variant['name'];
			}

			if ( ! empty( $variant['sku'] ) ) {
				$offer['sku'] = $variant['sku'];
			}

			$nested_offers[] = $offer;
		}

		// Build AggregateOffer with shared properties at parent level.
		$aggregate_offer = [
			'@type'         => 'AggregateOffer',
			'priceCurrency' => $currency,
		];

		if ( ! empty( $prices ) ) {
			$aggregate_offer['lowPrice']  = min( $prices );
			$aggregate_offer['highPrice'] = max( $prices );
		}

		$aggregate_offer['offerCount'] = count( $nested_offers );

		if ( ! empty( $availability ) ) {
			$aggregate_offer['availability'] = $availability;
		}

		if ( ! empty( $seller ) ) {
			$aggregate_offer['seller'] = $seller;
		}

		if ( ! empty( $price_valid_until ) ) {
			$aggregate_offer['priceValidUntil'] = $price_valid_until;
		}

		if ( ! empty( $shipping_refs ) ) {
			$aggregate_offer['shippingDetails'] = $shipping_refs;
		}

		if ( ! empty( $return_policy ) ) {
			$aggregate_offer['hasMerchantReturnPolicy'] = $return_policy;
		}

		$aggregate_offer['offers'] = $nested_offers;

		$schema['offers'] = $aggregate_offer;

		return $schema;
	}

	/**
	 * Convert multiple Offer objects into a single AggregateOffer with nested offers.
	 *
	 * When $schema['offers'] is an array of 2+ individual Offer objects (e.g., from
	 * EDD variable pricing or AI generation), wraps them in an AggregateOffer with
	 * lowPrice/highPrice/offerCount and shared properties at the parent level.
	 *
	 * @param array &$schema Schema to modify (by reference).
	 */
	private static function convert_multiple_offers_to_aggregate( &$schema ) {
		$offers = $schema['offers'];

		// Skip if already an AggregateOffer (single object with @type).
		if ( isset( $offers['@type'] ) ) {
			return;
		}

		// Skip if less than 2 offers.
		if ( count( $offers ) < 2 ) {
			return;
		}

		// Verify first element is an Offer.
		if ( empty( $offers[0]['@type'] ) || 'Offer' !== $offers[0]['@type'] ) {
			return;
		}

		// Properties to extract from individual offers to AggregateOffer level.
		$shared_props = [ 'seller', 'priceValidUntil', 'hasMerchantReturnPolicy', 'shippingDetails' ];

		$nested_offers = [];
		$prices        = [];
		$currency      = 'USD';
		$shared        = [];

		foreach ( $offers as $offer ) {
			if ( ! is_array( $offer ) || ( $offer['@type'] ?? '' ) !== 'Offer' ) {
				continue;
			}

			$price = $offer['price'] ?? '';
			if ( '' !== $price && is_numeric( $price ) ) {
				$prices[] = (float) $price;
			}

			if ( ! empty( $offer['priceCurrency'] ) ) {
				$currency = $offer['priceCurrency'];
			}

			// Capture shared properties from first offer.
			foreach ( $shared_props as $prop ) {
				if ( ! isset( $shared[ $prop ] ) && ! empty( $offer[ $prop ] ) ) {
					$shared[ $prop ] = $offer[ $prop ];
				}
			}

			if ( ! isset( $shared['availability'] ) && ! empty( $offer['availability'] ) ) {
				$shared['availability'] = $offer['availability'];
			}

			// Build clean nested offer without shared properties.
			$clean = [
				'@type'         => 'Offer',
				'price'         => $offer['price'] ?? '',
				'priceCurrency' => $offer['priceCurrency'] ?? $currency,
				'availability'  => $offer['availability'] ?? '',
				'url'           => $offer['url'] ?? '',
			];

			if ( ! empty( $offer['name'] ) ) {
				$clean['name'] = $offer['name'];
			}

			if ( ! empty( $offer['sku'] ) ) {
				$clean['sku'] = $offer['sku'];
			}

			$nested_offers[] = $clean;
		}

		if ( count( $nested_offers ) < 2 ) {
			return;
		}

		// Build AggregateOffer.
		$aggregate = [
			'@type'         => 'AggregateOffer',
			'priceCurrency' => $currency,
		];

		if ( ! empty( $prices ) ) {
			$aggregate['lowPrice']  = min( $prices );
			$aggregate['highPrice'] = max( $prices );
		}

		$aggregate['offerCount'] = count( $nested_offers );

		if ( ! empty( $shared['availability'] ) ) {
			$aggregate['availability'] = $shared['availability'];
		}

		foreach ( $shared_props as $prop ) {
			if ( ! empty( $shared[ $prop ] ) ) {
				$aggregate[ $prop ] = $shared[ $prop ];
			}
		}

		$aggregate['offers'] = $nested_offers;

		$schema['offers'] = $aggregate;
	}

	/**
	 * Fill a flat AggregateOffer with nested variation offers from WC/SureCart data.
	 *
	 * When the AI generates a flat AggregateOffer (only lowPrice/highPrice/offerCount,
	 * no nested offers) for a SoftwareApplication on a WC/SureCart variable product,
	 * this method builds the nested Offer objects from the variation data in $full_payload
	 * and adds shared properties (seller, availability, shippingDetails, hasMerchantReturnPolicy).
	 *
	 * @param array &$schema      Schema to modify (by reference).
	 * @param array $full_payload Full content payload with secondary ecommerce data.
	 */
	private static function fill_aggregate_variation_offers( &$schema, $full_payload ) {
		if ( empty( $schema['offers'] ) || ! is_array( $schema['offers'] ) ) {
			return;
		}

		$offers = &$schema['offers'];

		// Unwrap: if offers is an array with a single AggregateOffer element, extract it.
		if ( ! isset( $offers['@type'] ) && count( $offers ) === 1 && isset( $offers[0]['@type'] ) && 'AggregateOffer' === $offers[0]['@type'] ) {
			$schema['offers'] = $offers[0];
			$offers           = &$schema['offers'];
		}

		// Only process flat AggregateOffer (no nested offers yet).
		if ( ( $offers['@type'] ?? '' ) !== 'AggregateOffer' ) {
			return;
		}

		if ( ! empty( $offers['offers'] ) && is_array( $offers['offers'] ) ) {
			// Already has nested offers — nothing to fill.
			return;
		}

		// Get variation items from WC or SureCart.
		$secondary  = $full_payload['secondary'] ?? [];
		$variations = $secondary['wc_product']['variations'] ?? $secondary['surecart_product']['variations'] ?? null;

		if ( empty( $variations['items'] ) ) {
			return;
		}

		$primary     = $full_payload['primary'] ?? [];
		$product_url = $primary['permalink'] ?? '';
		$parent_name = $primary['title'] ?? '';

		// Get entity @id for seller reference.
		$entity_data = AIInit::getEntityData();
		$entity_id   = $entity_data['entity_id'] ?? '';

		if ( empty( $entity_id ) ) {
			$site_url  = rtrim( $full_payload['contextual']['site_url'] ?? home_url( '/' ), '/' );
			$entity_id = $site_url . '/#organization';
		}

		$seller = [ '@id' => $entity_id ];

		// Determine currency from existing AggregateOffer or variation data.
		$currency = $offers['priceCurrency'] ?? 'USD';

		// Build nested Offer objects from variation items.
		$nested_offers = [];
		$prices        = [];

		foreach ( $variations['items'] as $item ) {
			$price = $item['price'] ?? $item['regular_price'] ?? '';

			if ( '' === $price || ! is_numeric( $price ) ) {
				continue;
			}

			$prices[] = (float) $price;

			$offer = [
				'@type'         => 'Offer',
				'price'         => $price,
				'priceCurrency' => $item['currency'] ?? $currency,
				'url'           => $product_url,
			];

			if ( ! empty( $item['availability'] ) ) {
				$offer['availability'] = $item['availability'];
			}

			// Build variant name: "Parent - Variation" or just variation name.
			if ( ! empty( $item['name'] ) ) {
				$offer['name'] = $parent_name ? $parent_name . ' - ' . $item['name'] : $item['name'];
			} elseif ( ! empty( $item['attributes'] ) && is_array( $item['attributes'] ) ) {
				$attr_values   = array_values( $item['attributes'] );
				$suffix        = implode( ', ', $attr_values );
				$offer['name'] = $parent_name ? $parent_name . ' - ' . $suffix : $suffix;
			}

			if ( ! empty( $item['sku'] ) ) {
				$offer['sku'] = $item['sku'];
			}

			$nested_offers[] = $offer;
		}

		if ( empty( $nested_offers ) ) {
			return;
		}

		// Update AggregateOffer with accurate data from variations.
		if ( ! empty( $prices ) ) {
			$offers['lowPrice']  = min( $prices );
			$offers['highPrice'] = max( $prices );
		}

		$offers['offerCount'] = count( $nested_offers );

		// Add shared properties at AggregateOffer level.
		if ( empty( $offers['seller'] ) ) {
			$offers['seller'] = $seller;
		}

		if ( empty( $offers['availability'] ) ) {
			// Use first variation's availability as default.
			foreach ( $nested_offers as $offer ) {
				if ( ! empty( $offer['availability'] ) ) {
					$offers['availability'] = $offer['availability'];
					break;
				}
			}
		}

		if ( empty( $offers['priceValidUntil'] ) ) {
			$offers['priceValidUntil'] = gmdate( 'Y-m-d', strtotime( '+1 year' ) );
		}

		// Add shippingDetails @id references from WC shipping zones (or fallback).
		if ( empty( $offers['shippingDetails'] ) ) {
			$shipping_details = FnsPro::get_offer_shipping_details( $currency );

			if ( ! empty( $shipping_details ) ) {
				$shipping_refs = [];

				foreach ( $shipping_details as $sd ) {
					if ( ! empty( $sd['@id'] ) ) {
						$shipping_refs[] = [ '@id' => $sd['@id'] ];
					}
				}

				if ( ! empty( $shipping_refs ) ) {
					$offers['shippingDetails'] = $shipping_refs;
				}
			}
		}

		// Add hasMerchantReturnPolicy @id reference from ecommerce settings.
		if ( empty( $offers['hasMerchantReturnPolicy'] ) ) {
			$return_policy = FnsPro::get_merchant_return_policy();

			if ( ! empty( $return_policy['@id'] ) ) {
				$offers['hasMerchantReturnPolicy'] = [ '@id' => $return_policy['@id'] ];
			}
		}

		// Set nested offers.
		$offers['offers'] = $nested_offers;
	}

	/**
	 * Sanitize AggregateOffer nested offers structure.
	 *
	 * fix_product_offers() can corrupt the nested offers array
	 * when the AI generates $schema['offers'] as a single AggregateOffer object
	 * (not wrapped in an array). The fix iterates over the AggregateOffer's keys,
	 * and when it hits the nested 'offers' sub-array, it adds seller, priceValidUntil,
	 * hasMerchantReturnPolicy as string keys alongside the numeric offer indices.
	 *
	 * This method:
	 * 1. Normalizes offers to a single AggregateOffer object (unwraps array if needed).
	 * 2. Extracts misplaced string-keyed properties from nested offers → moves to AggregateOffer level.
	 * 3. Removes shared properties from individual nested Offer objects.
	 * 4. Re-indexes nested offers as a clean sequential array.
	 *
	 * @param array &$schema Schema to modify (by reference).
	 */
	private static function sanitize_aggregate_offer( &$schema ) {
		if ( empty( $schema['offers'] ) || ! is_array( $schema['offers'] ) ) {
			return;
		}

		$offers = &$schema['offers'];

		// Unwrap: if offers is an array with a single AggregateOffer element, extract it.
		if ( ! isset( $offers['@type'] ) && count( $offers ) === 1 && isset( $offers[0]['@type'] ) && 'AggregateOffer' === $offers[0]['@type'] ) {
			$schema['offers'] = $offers[0];
			$offers           = &$schema['offers'];
		}

		// Only sanitize AggregateOffer with nested offers.
		if ( ( $offers['@type'] ?? '' ) !== 'AggregateOffer' || empty( $offers['offers'] ) || ! is_array( $offers['offers'] ) ) {
			return;
		}

		$nested = $offers['offers'];

		// Properties that belong at AggregateOffer level, not inside nested offers.
		$shared_props = [ 'seller', 'priceValidUntil', 'hasMerchantReturnPolicy', 'shippingDetails' ];

		// Extract misplaced string-keyed properties from nested offers array.
		foreach ( $shared_props as $prop ) {
			if ( array_key_exists( $prop, $nested ) ) {
				// Move to AggregateOffer level if not already set.
				if ( empty( $offers[ $prop ] ) ) {
					$offers[ $prop ] = $nested[ $prop ];
				}
				unset( $nested[ $prop ] );
			}
		}

		// Clean up individual Offer objects: remove shared properties.
		$clean_offers = [];
		foreach ( $nested as $key => $item ) {
			if ( ! is_int( $key ) && ! is_numeric( $key ) ) {
				// Skip any remaining string-keyed non-offer entries.
				continue;
			}
			if ( ! is_array( $item ) || empty( $item['@type'] ) ) {
				continue;
			}

			// Remove shared properties from individual offers.
			foreach ( $shared_props as $prop ) {
				unset( $item[ $prop ] );
			}

			$clean_offers[] = $item;
		}

		$offers['offers'] = $clean_offers;
	}

	/**
	 * Strip priceSpecification from all offers in a schema.
	 *
	 * priceSpecification is not valid for SoftwareApplication,
	 * so it must be removed when combining Product + SoftwareApplication.
	 *
	 * @param array &$schema Schema to modify (by reference).
	 */
	private static function strip_price_specification( &$schema ) {
		if ( empty( $schema['offers'] ) ) {
			return;
		}

		$offers = &$schema['offers'];

		if ( isset( $offers['@type'] ) ) {
			// Single offer object (Offer or AggregateOffer).
			unset( $offers['priceSpecification'] );

			// Also strip from nested offers inside AggregateOffer.
			if ( ! empty( $offers['offers'] ) ) {
				foreach ( $offers['offers'] as &$nested ) {
					unset( $nested['priceSpecification'] );
				}
				unset( $nested );
			}
		} else {
			// Array of offers.
			foreach ( $offers as &$offer ) {
				unset( $offer['priceSpecification'] );

				if ( ! empty( $offer['offers'] ) ) {
					foreach ( $offer['offers'] as &$nested ) {
						unset( $nested['priceSpecification'] );
					}
					unset( $nested );
				}
			}
			unset( $offer );
		}
	}


	private static function build_woocommerce_product_data( $post ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return null;
		}

		$product = wc_get_product( $post->ID );

		if ( ! $product ) {
			return null;
		}

		$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD';

		$pricing = array_filter(
			[
				'currency'      => $currency,
				'price'         => $product->get_price(),
				'regular_price' => $product->get_regular_price(),
				'sale_price'    => $product->get_sale_price(),
				'on_sale'       => $product->is_on_sale(),
			]
		);

		$sale_to = $product->get_date_on_sale_to();

		if ( $sale_to ) {
			$pricing['sale_date_to'] = $sale_to->date( 'c' );
		}

		$variation_count = 0;

		if ( $product->is_type( 'variable' ) && method_exists( $product, 'get_variation_prices' ) ) {
			$prices = $product->get_variation_prices( true );

			if ( ! empty( $prices['price'] ) ) {
				$pricing['min_price'] = min( $prices['price'] );
				$pricing['max_price'] = max( $prices['price'] );
			}

			$variation_count = count( $product->get_children() );
		}

		$stock_status     = $product->get_stock_status();
		$availability_map = [
			'instock'     => 'https://schema.org/InStock',
			'outofstock'  => 'https://schema.org/OutOfStock',
			'onbackorder' => 'https://schema.org/BackOrder',
		];

		$sku = $product->get_sku();
		// Fallback to product ID if SKU is not set.
		if ( empty( $sku ) ) {
			$sku = (string) $product->get_id();
		}
		$gtin = method_exists( $product, 'get_global_unique_id' ) ? $product->get_global_unique_id() : '';

		$brand            = '';
		$brand_taxonomies = [ 'product_brand', 'pwb-brand', 'pa_brand' ];

		foreach ( $brand_taxonomies as $tax ) {
			if ( taxonomy_exists( $tax ) ) {
				$terms = get_the_terms( $post->ID, $tax );

				if ( $terms && ! is_wp_error( $terms ) ) {
					$brand = $terms[0]->name;
					break;
				}
			}
		}

		$attributes = [];

		foreach ( $product->get_attributes() as $attr ) {
			if ( is_object( $attr ) && method_exists( $attr, 'get_name' ) ) {
				$name   = wc_attribute_label( $attr->get_name() );
				$values = $attr->is_taxonomy()
					? wc_get_product_terms( $post->ID, $attr->get_name(), [ 'fields' => 'names' ] )
					: $attr->get_options();

				$attributes[ $name ] = is_array( $values ) ? implode( ', ', $values ) : (string) $values;
			}
		}

		$categories = [];
		$cat_terms  = get_the_terms( $post->ID, 'product_cat' );

		if ( $cat_terms && ! is_wp_error( $cat_terms ) ) {
			foreach ( $cat_terms as $term ) {
				$categories[] = $term->name;
			}
		}

		$reviews = [];

		if ( $product->get_reviews_allowed() ) {
			$reviews = [
				'average_rating' => (float) $product->get_average_rating(),
				'review_count'   => (int) $product->get_review_count(),
				'rating_counts'  => $product->get_rating_counts(),
			];

			$review_comments = get_comments(
				[
					'post_id'  => $post->ID,
					'type'     => 'review',
					'status'   => 'approve',
					'number'   => 2,
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Necessary meta query for plugin feature.
					'meta_key' => 'rating',
					'orderby'  => 'meta_value_num',
					'order'    => 'DESC',
				]
			);

			$review_items = [];

			foreach ( $review_comments as $comment ) {
				$rating = (int) get_comment_meta( $comment->comment_ID, 'rating', true );

				$review_items[] = array_filter(
					[
						'author' => $comment->comment_author,
						'date'   => get_comment_date( 'c', $comment ),
						'rating' => $rating ?: null,
						'text'   => wp_strip_all_tags( $comment->comment_content ),
					]
				);
			}

			if ( ! empty( $review_items ) ) {
				$reviews['items'] = $review_items;
			}
		}

		$gallery = [];

		foreach ( $product->get_gallery_image_ids() as $img_id ) {
			$src = wp_get_attachment_image_src( $img_id, 'full' );

			if ( $src ) {
				$gallery[] = [
					'url'    => $src[0],
					'width'  => $src[1],
					'height' => $src[2],
				];
			}
		}

		$weight     = $product->get_weight();
		$dimensions = array_filter(
			[
				'length' => $product->get_length(),
				'width'  => $product->get_width(),
				'height' => $product->get_height(),
			]
		);

		$weight_unit = function_exists( 'get_option' ) ? get_option( 'woocommerce_weight_unit', 'kg' ) : 'kg';
		$dim_unit    = function_exists( 'get_option' ) ? get_option( 'woocommerce_dimension_unit', 'cm' ) : 'cm';

		$prices_include_tax = 'yes' === get_option( 'woocommerce_prices_include_tax', 'no' );

		return array_filter(
			[
				'product_type'       => $product->get_type(),
				'pricing'            => $pricing,
				'stock_status'       => $stock_status,
				'availability'       => $availability_map[ $stock_status ] ?? '',
				'sku'                => $sku,
				'gtin'               => $gtin,
				'brand'              => $brand,
				'categories'         => $categories,
				'attributes'         => $attributes,
				'reviews'            => $reviews,
				'gallery'            => $gallery,
				'weight'             => $weight ? $weight . ' ' . $weight_unit : '',
				'dimensions'         => ! empty( $dimensions ) ? $dimensions : null,
				'dimension_unit'     => ! empty( $dimensions ) ? $dim_unit : '',
				'is_virtual'         => $product->is_virtual(),
				'is_downloadable'    => $product->is_downloadable(),
				'total_sales'        => (int) $product->get_total_sales(),
				'variation_count'    => $variation_count,
				'variations'         => self::build_wc_variations( $product, $currency, $availability_map ),
				'prices_include_tax' => $prices_include_tax,
			]
		);
	}

	/**
	 * Extract WooCommerce product variation details for ProductGroup schema.
	 *
	 * Only extracts when review-schema-pro is active.
	 *
	 * @since 1.0.0
	 *
	 * @param \WC_Product $product          The parent product.
	 * @param string      $currency         Store currency code.
	 * @param array       $availability_map Stock status to schema.org URL map.
	 *
	 * @return array|null Variation data or null.
	 */
	private static function build_wc_variations( $product, $currency, $availability_map ) {
		if ( ! $product->is_type( 'variable' ) ) {
			return null;
		}

		$children  = $product->get_children();
		$varies_by = [];
		$variants  = [];

		foreach ( $children as $variation_id ) {
			$variation = wc_get_product( $variation_id );

			if ( ! $variation || ! $variation->exists() ) {
				continue;
			}

			$attrs         = $variation->get_variation_attributes();
			$variant_attrs = [];

			foreach ( $attrs as $attr_key => $attr_value ) {
				$taxonomy = str_replace( 'attribute_', '', $attr_key );
				$label    = wc_attribute_label( $taxonomy, $product );

				if ( $attr_value && taxonomy_exists( $taxonomy ) ) {
					$term       = get_term_by( 'slug', $attr_value, $taxonomy );
					$attr_value = $term ? $term->name : $attr_value;
				}

				$variant_attrs[ $label ] = $attr_value ?: __( 'Any', 'review-schema' );

				if ( ! in_array( $label, $varies_by, true ) ) {
					$varies_by[] = $label;
				}
			}

			$stock  = $variation->get_stock_status();
			$img_id = $variation->get_image_id();
			$image  = $img_id ? wp_get_attachment_image_url( $img_id, 'full' ) : '';

			$variants[] = array_filter(
				[
					'variation_id'  => $variation_id,
					'sku'           => $variation->get_sku(),
					'name'          => $variation->get_name(),
					'description'   => $variation->get_description(),
					'attributes'    => $variant_attrs,
					'price'         => $variation->get_price(),
					'regular_price' => $variation->get_regular_price(),
					'sale_price'    => $variation->get_sale_price(),
					'currency'      => $currency,
					'stock_status'  => $stock,
					'availability'  => $availability_map[ $stock ] ?? '',
					'image'         => $image,
				]
			);
		}

		if ( empty( $variants ) ) {
			return null;
		}

		return [
			'varies_by' => $varies_by,
			'items'     => $variants,
		];
	}

	/**
	 * Extract Easy Digital Downloads product data.
	 *
	 * @since 1.0.0
	 *
	 * @return array|null EDD product data or null.
	 */
	private static function build_edd_product_data( $post ) {
		if ( ! function_exists( 'edd_get_download' ) ) {
			return null;
		}

		if ( 'download' !== $post->post_type ) {
			return null;
		}

		$download = edd_get_download( $post->ID );

		if ( ! $download ) {
			return null;
		}

		$currency = function_exists( 'edd_get_currency' )
			? edd_get_currency()
			: ( function_exists( 'edd_get_option' ) ? edd_get_option( 'currency', 'USD' ) : 'USD' );
		$price    = $download->get_price();

		$categories = [];
		$cat_terms  = get_the_terms( $post->ID, 'download_category' );

		if ( $cat_terms && ! is_wp_error( $cat_terms ) ) {
			foreach ( $cat_terms as $term ) {
				$categories[] = $term->name;
			}
		}

		$tags      = [];
		$tag_terms = get_the_terms( $post->ID, 'download_tag' );

		if ( $tag_terms && ! is_wp_error( $tag_terms ) ) {
			foreach ( $tag_terms as $term ) {
				$tags[] = $term->name;
			}
		}

		$sku = $download->get_sku();
		// Fallback to download ID if SKU is not set.
		if ( empty( $sku ) ) {
			$sku = (string) $download->get_ID();
		}

		$data = [
			'product_type' => $download->has_variable_prices() ? 'variable' : 'simple',
			'pricing'      => [
				'currency' => $currency,
				'price'    => $price,
			],
			'sku'          => $sku,
			'categories'   => $categories,
			'tags'         => $tags,
			'sales'        => (int) $download->get_sales(),
			'is_free'      => ! (bool) $price,
			'is_bundled'   => $download->is_bundled_download(),
		];

		/** Include variable pricing details when pro is active. */
		$variations = self::build_edd_variations( $download, $currency );

		if ( $variations ) {
			$data['variations'] = $variations;
		}

		return array_filter( $data );
	}

	/**
	 * Extract EDD variable pricing tiers for product offers schema.
	 *
	 * EDD "variations" are pricing tiers (e.g. Personal, Business, Developer),
	 * not actual product variants — they become multiple Offer objects.
	 *
	 * @since 1.0.0
	 *
	 * @param \EDD_Download $download The EDD download object.
	 * @param string        $currency Store currency code.
	 *
	 * @return array|null Variable pricing data or null.
	 */
	private static function build_edd_variations( $download, $currency ) {
		if ( ! $download->has_variable_prices() ) {
			return null;
		}

		$prices   = $download->get_prices();
		$variants = [];

		if ( empty( $prices ) || ! is_array( $prices ) ) {
			return null;
		}

		foreach ( $prices as $price_id => $price_option ) {
			$name   = $price_option['name'] ?? '';
			$amount = isset( $price_option['amount'] ) ? $price_option['amount'] : 0;

			$variants[] = array_filter(
				[
					'price_id' => $price_id,
					'name'     => $name,
					'price'    => $amount,
					'currency' => $currency,
				]
			);
		}

		if ( empty( $variants ) ) {
			return null;
		}

		return [
			'varies_by' => [ 'price_option' ],
			'items'     => $variants,
		];
	}

	/**
	 * Post-process Product / SoftwareApplication offers to fix common AI output issues.
	 *
	 * Moved from the free SchemaExtractor. Runs last (priority 99) on
	 * `rtrs_ai_fill_product_schema` and `rtrs_ai_fill_software_application_schema`:
	 * - Ensure seller uses @id reference (not inline Organization).
	 * - Ensure price & priceCurrency are direct Offer/AggregateOffer children.
	 * - Add hasMerchantReturnPolicy and shippingDetails @id references.
	 *
	 * @param array  $schema    Product or SoftwareApplication node.
	 * @param array  $primary   Primary signals (unused).
	 * @param array  $secondary Secondary signals (unused).
	 * @param string $permalink Post permalink (unused).
	 * @param string $entity_id Site entity @id (offer seller).
	 *
	 * @return array
	 */
	public static function fix_product_offers( $schema, $primary = [], $secondary = [], $permalink = '', $entity_id = '' ) {
		if ( ! is_array( $schema ) || empty( $schema['offers'] ) || ! is_array( $schema['offers'] ) ) {
			return $schema;
		}

		// Build return policy and shipping @id references.
		$return_policy_ref = [];
		$shipping_refs     = [];

		$return_policy = FnsPro::get_merchant_return_policy();
		if ( ! empty( $return_policy['@id'] ) ) {
			$return_policy_ref = [ '@id' => $return_policy['@id'] ];
		}

		$currency = 'USD';
		if ( function_exists( 'get_woocommerce_currency' ) ) {
			$currency = get_woocommerce_currency();
		} elseif ( class_exists( 'FluentCart\Api\CurrencySettings' ) ) {
			$currency = \FluentCart\Api\CurrencySettings::get( 'currency' ) ?: 'USD';
		}
		$shipping_details = FnsPro::get_offer_shipping_details( $currency );
		if ( ! empty( $shipping_details ) ) {
			foreach ( $shipping_details as $sd ) {
				if ( ! empty( $sd['@id'] ) ) {
					$shipping_refs[] = [ '@id' => $sd['@id'] ];
				}
			}
		}

		// Default priceValidUntil: 1 year from now.
		$default_price_valid_until = gmdate( 'Y-m-d', strtotime( '+1 year' ) );

		foreach ( $schema['offers'] as &$offer ) {
			if ( ! is_array( $offer ) ) {
				continue;
			}

			// Fix seller: replace inline Organization with @id reference.
			if ( ! empty( $offer['seller'] ) && is_array( $offer['seller'] ) && empty( $offer['seller']['@id'] ) ) {
				$offer['seller'] = [ '@id' => $entity_id ];
			}

			if ( empty( $offer['seller'] ) ) {
				$offer['seller'] = [ '@id' => $entity_id ];
			}

			// Add priceValidUntil if missing (default: 1 year from now).
			if ( empty( $offer['priceValidUntil'] ) ) {
				$offer['priceValidUntil'] = $default_price_valid_until;
			}

			// Add return policy @id reference.
			if ( ! empty( $return_policy_ref ) && empty( $offer['hasMerchantReturnPolicy'] ) ) {
				$offer['hasMerchantReturnPolicy'] = $return_policy_ref;
			}

			// Add shipping details @id references.
			if ( ! empty( $shipping_refs ) && empty( $offer['shippingDetails'] ) ) {
				$offer['shippingDetails'] = $shipping_refs;
			}

			$offer_type = $offer['@type'] ?? '';

			// Ensure price & priceCurrency are direct children of Offer.
			if ( 'Offer' === $offer_type ) {
				if ( empty( $offer['price'] ) && ! empty( $offer['priceSpecification'] ) && is_array( $offer['priceSpecification'] ) ) {
					foreach ( $offer['priceSpecification'] as $spec ) {
						if ( ! empty( $spec['price'] ) ) {
							$offer['price'] = $spec['price'];
							if ( ! empty( $spec['priceCurrency'] ) ) {
								$offer['priceCurrency'] = $spec['priceCurrency'];
							}
							break;
						}
					}
				}
			}

			// Ensure price & priceCurrency are direct children of AggregateOffer.
			if ( 'AggregateOffer' === $offer_type ) {
				if ( empty( $offer['price'] ) && ! empty( $offer['lowPrice'] ) ) {
					$offer['price'] = $offer['lowPrice'];
				}
				if ( empty( $offer['priceCurrency'] ) && ! empty( $offer['priceSpecification'] ) && is_array( $offer['priceSpecification'] ) ) {
					foreach ( $offer['priceSpecification'] as $spec ) {
						if ( ! empty( $spec['priceCurrency'] ) ) {
							$offer['priceCurrency'] = $spec['priceCurrency'];
							break;
						}
					}
				}
			}
		}
		unset( $offer );

		return $schema;
	}
}
