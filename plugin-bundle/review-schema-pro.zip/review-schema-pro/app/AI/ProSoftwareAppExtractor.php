<?php
/**
 * Pro SoftwareApplication Extractor - AI schema template and field filling (Pro feature).
 *
 * Owns the SoftwareApplication (and Web/MobileApplication) part of AI schema
 * generation, moved from the free plugin's SchemaExtractor:
 * - `rtrs_ai_type_template`                    — the AI prompt instructions.
 * - `rtrs_ai_fill_software_application_schema` — fills name, description, url,
 *   image, applicationCategory, operatingSystem, offers (EDD/WC) and author.
 * The free extractor still runs its shared offer post-processing afterwards.
 *
 * @package Rtrsp\AI
 * @since   2.1.3
 */

namespace Rtrsp\AI;

use Rtrs\AI\SchemaExtractor;

defined( 'ABSPATH' ) || exit;

/**
 * Class ProSoftwareAppExtractor
 */
class ProSoftwareAppExtractor {

	/**
	 * Schema types handled here.
	 */
	const TYPES = [ 'SoftwareApplication', 'WebApplication', 'MobileApplication' ];

	/**
	 * AI prompt template for SoftwareApplication types.
	 *
	 * Only fills an empty template, so an older free plugin that still ships
	 * its own SoftwareApplication template keeps it unchanged.
	 *
	 * @param string $template    Template so far.
	 * @param string $type        Schema type.
	 * @param string $entity_type Site entity type (unused).
	 *
	 * @return string
	 */
	public static function get_software_app_template( $template, $type, $entity_type = '' ) {
		if ( '' !== (string) $template || ! in_array( $type, self::TYPES, true ) ) {
			return $template;
		}

		return "Required fields for SoftwareApplication:\n"
			. "- name, description\n"
			. "- applicationCategory\n"
			. "- operatingSystem (if available)\n"
			. "- offers (if pricing available)\n"
			. "- aggregateRating (if reviews exist)";
	}

	/**
	 * Fill missing SoftwareApplication fields from extracted EDD/WC product data.
	 *
	 * @param array                $schema    AI-generated SoftwareApplication node.
	 * @param array                $primary   Primary content signals.
	 * @param array                $secondary Secondary signals (edd_product, wc_product, ...).
	 * @param string               $permalink Post permalink.
	 * @param string               $entity_id Site entity @id (offer seller).
	 * @param SchemaExtractor|null $extractor Free extractor, for its shared fallback_author().
	 *
	 * @return array
	 */
	public static function fill_software_application( $schema, $primary, $secondary, $permalink, $entity_id = '', $extractor = null ) {
		if ( ! is_array( $schema ) ) {
			return $schema;
		}
		$primary   = is_array( $primary ) ? $primary : [];
		$secondary = is_array( $secondary ) ? $secondary : [];

		$edd = $secondary['edd_product'] ?? [];
		$wc  = $secondary['wc_product'] ?? [];

		if ( empty( $schema['name'] ) && ! empty( $primary['title'] ) ) {
			$schema['name'] = $primary['title'];
		}

		if ( empty( $schema['description'] ) && ! empty( $primary['excerpt'] ) ) {
			$schema['description'] = mb_substr( $primary['excerpt'], 0, 200 );
		}

		if ( empty( $schema['url'] ) && ! empty( $primary['permalink'] ) ) {
			$schema['url'] = $primary['permalink'];
		}

		if ( empty( $schema['image'] ) && ! empty( $primary['featured_image']['url'] ) ) {
			$fi              = $primary['featured_image'];
			$schema['image'] = array_filter( [
				'@type'  => 'ImageObject',
				'url'    => $fi['url'],
				'width'  => $fi['width'] ?? null,
				'height' => $fi['height'] ?? null,
			] );
		}

		if ( empty( $schema['applicationCategory'] ) ) {
			$cats = $edd['categories'] ?? $wc['categories'] ?? [];
			if ( ! empty( $cats ) ) {
				$schema['applicationCategory'] = implode( ', ', $cats );
			} else {
				$schema['applicationCategory'] = 'BusinessApplication';
			}
		}

		if ( empty( $schema['operatingSystem'] ) ) {
			$schema['operatingSystem'] = 'All';
		}

		// Build offers from EDD or WC product data if AI didn't generate them.
		if ( empty( $schema['offers'] ) ) {
			$seller = [ '@id' => $entity_id ];

			// EDD variable pricing → multiple offers (one per pricing tier).
			if ( ! empty( $edd['variations']['items'] ) ) {
				$offers = [];

				foreach ( $edd['variations']['items'] as $item ) {
					$item_price    = $item['price'] ?? '';
					$item_currency = $item['currency'] ?? $edd['pricing']['currency'] ?? 'USD';

					if ( '' !== $item_price && (float) $item_price > 0 ) {
						$offer = [
							'@type'         => 'Offer',
							'price'         => $item_price,
							'priceCurrency' => $item_currency,
							'availability'  => 'https://schema.org/InStock',
							'url'           => $permalink,
							'seller'        => $seller,
						];

						if ( ! empty( $item['name'] ) ) {
							$offer['name'] = $item['name'];
						}

						$offers[] = $offer;
					}
				}

				if ( ! empty( $offers ) ) {
					$schema['offers'] = $offers;
				}
			} else {
				$price    = $edd['pricing']['price'] ?? $wc['pricing']['price'] ?? '';
				$currency = $edd['pricing']['currency'] ?? $wc['pricing']['currency'] ?? 'USD';

				if ( '' !== $price && (float) $price > 0 ) {
					$schema['offers'] = [
						[
							'@type'         => 'Offer',
							'price'         => $price,
							'priceCurrency' => $currency,
							'availability'  => 'https://schema.org/InStock',
							'url'           => $permalink,
							'seller'        => $seller,
						],
					];
				}
			}
		}

		// Ensure publisher/author references.
		if ( empty( $schema['author'] ) && ! empty( $primary['author']['name'] ) ) {
			$schema['author'] = $extractor instanceof SchemaExtractor
				? $extractor->fallback_author( $primary )
				: array_filter( [ '@type' => 'Person', 'name' => $primary['author']['name'], 'url' => $primary['author']['url'] ?? null ] );
		}

		return $schema;
	}
}
