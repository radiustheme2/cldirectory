<?php
/**
 * Per-page LocalBusiness schema (Pro).
 *
 * Owns the per-post "Local business schema" metabox group, its
 * category-conditional field toggling and the per-page LocalBusiness JSON-LD.
 * The site-wide (global) LocalBusiness / Organization entity stays in the free
 * plugin (Schema::generate_local_business_and_organization_schema()).
 *
 * Plugs into the free plugin's existing extension points:
 * - `rtrs_section_schema_fields`           — adds the metabox field group (saved by the free metabox).
 * - `rtseo_snippet_add_more_schema_output` — builds the node for the `local_business` schema type.
 *
 * Values keep the existing `rtrs_local_business_schema` post meta, so data saved
 * by earlier versions keeps working. With an older free plugin that still ships
 * its own per-page builder, this class steps aside so nothing is output twice.
 *
 * @package Rtrsp\Modules\Schema\Hooks
 */

namespace Rtrsp\Modules\Schema\Hooks;

use Rtrs\Helpers\Functions;
use Rtrs\Modules\Schema\Models\Schema;
use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class LocalBusinessSchema
 */
class LocalBusinessSchema {

	use SingletonTrait;

	/**
	 * Schema type key (rich_snippet_cats()) handled here.
	 */
	const SCHEMA_CAT = 'local_business';

	/**
	 * Metabox field group name, also the post meta key.
	 */
	const META_GROUP = 'rtrs_local_business_schema';

	/**
	 * Script handle for the metabox field toggling.
	 */
	const SCRIPT = 'rtrsp-local-business-meta';

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'rtrs_section_schema_fields', [ $this, 'register_fields' ] );
		add_filter( 'rtseo_snippet_add_more_schema_output', [ $this, 'schema_output' ], 10, 4 );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_meta_script' ], 20 );
	}

	/**
	 * Whether the active free plugin still builds per-page LocalBusiness itself.
	 *
	 * Free releases before the move to Pro output the node and register the
	 * metabox group on their own; Pro must not add a second copy of either.
	 *
	 * @return bool
	 */
	public static function free_builds_it() {
		return method_exists( Schema::class, 'build_local_business_schema' );
	}

	/**
	 * Add the per-page LocalBusiness group to the schema metabox fields.
	 *
	 * @param array $fields Metabox field groups.
	 * @return array
	 */
	public function register_fields( $fields ) {
		if ( ! is_array( $fields ) || self::free_builds_it() ) {
			return $fields;
		}
		foreach ( $fields as $field ) {
			if ( is_array( $field ) && self::META_GROUP === ( $field['name'] ?? '' ) ) {
				return $fields;
			}
		}
		$fields[] = $this->fields();

		return $fields;
	}

	/**
	 * Append the per-page LocalBusiness node(s) for the `local_business` type.
	 *
	 * @param array  $schema_output Nodes built so far for this schema entry.
	 * @param string $schema_cat    Schema type key.
	 * @param array  $meta_data     Saved meta for this entry (schema_id = row key).
	 * @param Schema $schema        Free plugin schema model.
	 * @return array
	 */
	public function schema_output( $schema_output, $schema_cat, $meta_data, $schema ) {
		if ( self::SCHEMA_CAT !== $schema_cat || ! is_array( $meta_data ) || ! $schema instanceof Schema || self::free_builds_it() ) {
			return $schema_output;
		}

		return array_merge( (array) $schema_output, $this->build( $meta_data, new Functions(), $meta_data['schema_id'] ?? 0, $schema ) );
	}

	/**
	 * Load the category-conditional field toggling on post edit screens.
	 *
	 * @return void
	 */
	public function enqueue_meta_script() {
		if ( self::free_builds_it() || ! Functions::is_edit_page() || ! wp_script_is( 'rtrs-admin', 'enqueued' ) ) {
			return;
		}
		wp_enqueue_script( self::SCRIPT, rtrsp()->get_assets_uri( 'js/local-business-meta.js' ), [ 'jquery', 'rtrs-admin' ], RTRSP_VERSION, true );
		wp_localize_script( self::SCRIPT, 'rtrspLocalBusiness', [ 'condTypes' => self::cond_types() ] );
	}

	/**
	 * Category-conditional field groups for the per-page LocalBusiness metabox.
	 *
	 * Keys match the `rtrs-lb-{key}` holder classes in fields() so the metabox
	 * script shows a field for exactly the type list build() gates its output on.
	 *
	 * @return array Group key => list of schema types.
	 */
	public static function cond_types() {
		return [
			'food'    => Functions::getFoodEstablishmentTypes(),
			'lodging' => Functions::getLodgingBusinessTypes(),
			'medical' => Functions::getMedicalTypes(),
		];
	}

	/**
	 * Per-page LocalBusiness metabox field group.
	 *
	 * @return array
	 */
	public function fields() {
		return [
			'type'        => 'group',
			'name'        => self::META_GROUP,
			'id'          => 'rtrs-local_business_schema',
			'holderClass' => 'rtrs-hidden rtrs-schema-field',
			'label'       => esc_html__( 'Local business schema', 'review-schema-pro' ),
			'fields'      => [
				[
					'id'     => 'local_business',
					'type'   => 'auto-fill',
					'is_pro' => true,
					'label'  => esc_html__( 'Auto Fill', 'review-schema-pro' ),
				],
				[
					'name'    => 'status',
					'type'    => 'tab',
					'label'   => esc_html__( 'Status', 'review-schema-pro' ),
					'default' => 'show',
					'options' => [
						'show' => esc_html__( 'Show', 'review-schema-pro' ),
						'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
					],
				],
				[
					'name'     => 'category',
					'label'    => esc_html__( 'Category', 'review-schema-pro' ),
					'type'     => 'schema_type',
					'class'    => 'rtrs-lb-category',
					'required' => true,
					'options'  => Functions::getSiteTypes(),
					'empty'    => esc_html__( 'Select One', 'review-schema-pro' ),
					'desc'     => esc_html__( 'Use the most appropriate schema category for local business', 'review-schema-pro' ) . ' <a href="' . esc_url( 'https://www.radiustheme.com/ticket-support/' ) . '" target="_blank">' . esc_html__( "Can't find your category? Contact support", 'review-schema-pro' ) . '</a>',
				],
				[
					'name'     => 'name',
					'type'     => 'text',
					'label'    => esc_html__( 'Name', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'  => 'description',
					'type'  => 'textarea',
					'label' => esc_html__( 'Description', 'review-schema-pro' ),
				],
				[
					'name'  => 'image',
					'type'  => 'gallery',
					'label' => esc_html__( 'Images', 'review-schema-pro' ),
				],
				[
					'name'  => 'logo',
					'type'  => 'image',
					'label' => esc_html__( 'Business Logo', 'review-schema-pro' ),
					'desc'  => esc_html__( 'This is only for Organization category and The image must be 112x112px, at minimum.', 'review-schema-pro' ),
				],
				[
					'name'        => 'priceRange',
					'type'        => 'text',
					'label'       => esc_html__( 'Price Range', 'review-schema-pro' ),
					'recommended' => true,
					'desc'        => esc_html__( 'The price range of the business, for example $$$.', 'review-schema-pro' ),
				],
				[
					'type'      => 'group',
					'duplicate' => false,
					'name'      => 'address',
					'label'     => esc_html__( 'Address', 'review-schema-pro' ),
					'fields'    => [
						[
							'name'  => 'streetAddress',
							'type'  => 'text',
							'label' => esc_html__( 'Street address', 'review-schema-pro' ),
						],
						[
							'name'  => 'addressLocality',
							'type'  => 'text',
							'label' => esc_html__( 'Address locality', 'review-schema-pro' ),
							'desc'  => esc_html__( 'City (i.e Melbourne)', 'review-schema-pro' ),
						],
						[
							'name'  => 'addressRegion',
							'type'  => 'text',
							'label' => esc_html__( 'Address region', 'review-schema-pro' ),
							'desc'  => esc_html__( 'State (i.e. Victoria)', 'review-schema-pro' ),
						],
						[
							'name'  => 'postalCode',
							'type'  => 'text',
							'label' => esc_html__( 'Postal code', 'review-schema-pro' ),
						],
						[
							'name'    => 'addressCountry',
							'label'   => esc_html__( 'Country', 'review-schema-pro' ),
							'type'    => 'select2',
							'options' => Functions::getCountryList(),
							'empty'   => esc_html__( 'Select One', 'review-schema-pro' ),
						],
					],
				],
				[
					'type'      => 'group',
					'duplicate' => false,
					'name'      => 'geo',
					'label'     => esc_html__( 'GEO', 'review-schema-pro' ),
					'fields'    => [
						[
							'name'  => 'latitude',
							'type'  => 'text',
							'label' => esc_html__( 'Latitude', 'review-schema-pro' ),
						],
						[
							'name'  => 'longitude',
							'type'  => 'text',
							'label' => esc_html__( 'Longitude', 'review-schema-pro' ),
						],
					],
				],
				[
					'type'   => 'group',
					'name'   => 'opening_hours',
					'label'  => esc_html__( 'Opening Hours By Day', 'review-schema-pro' ),
					'fields' => [
						[
							'name'    => 'day',
							'type'    => 'select',
							'label'   => esc_html__( 'Day', 'review-schema-pro' ),
							'empty'   => esc_html__( 'Select one', 'review-schema-pro' ),
							'options' => [
								'Monday'    => esc_html__( 'Monday', 'review-schema-pro' ),
								'Tuesday'   => esc_html__( 'Tuesday', 'review-schema-pro' ),
								'Wednesday' => esc_html__( 'Wednesday', 'review-schema-pro' ),
								'Thursday'  => esc_html__( 'Thursday', 'review-schema-pro' ),
								'Friday'    => esc_html__( 'Friday', 'review-schema-pro' ),
								'Saturday'  => esc_html__( 'Saturday', 'review-schema-pro' ),
								'Sunday'    => esc_html__( 'Sunday', 'review-schema-pro' ),
							],
							'desc'    => esc_html__( "Don't add same day multiple time", 'review-schema-pro' ),
						],
						[
							'name'  => 'opens',
							'type'  => 'text',
							'label' => esc_html__( 'Opens Time', 'review-schema-pro' ),
							'desc'  => esc_html__( 'Times are specified using 24:00 time. For example, 3PM is specified as 15:00.', 'review-schema-pro' ),
						],
						[
							'name'  => 'closes',
							'type'  => 'text',
							'label' => esc_html__( 'Closes Time', 'review-schema-pro' ),
						],
					],
				],
				[
					'name'        => 'telephone',
					'type'        => 'text',
					'label'       => esc_html__( 'Telephone', 'review-schema-pro' ),
					'recommended' => true,
				],
				[
					'name'        => 'url',
					'type'        => 'url',
					'label'       => esc_html__( 'Web URL', 'review-schema-pro' ),
					'recommended' => true,
				],
				[
					'name'        => 'servesCuisine',
					'type'        => 'textarea',
					'label'       => esc_html__( 'Serves Cuisine', 'review-schema-pro' ),
					'holderClass' => 'rtrs-lb-cond rtrs-lb-food',
					'desc'        => esc_html__( 'Food establishment categories only (Restaurant, Bakery, Cafe, Bar, Brewery etc).', 'review-schema-pro' ),
				],
				[
					'name'        => 'menu',
					'type'        => 'url',
					'label'       => esc_html__( 'Menu URL', 'review-schema-pro' ),
					'holderClass' => 'rtrs-lb-cond rtrs-lb-food',
					'desc'        => esc_html__( 'Link to the menu page. Use this instead of the menu sections below when the menu lives on its own page.', 'review-schema-pro' ),
				],
				[
					'name'        => 'acceptsReservations',
					'type'        => 'tab',
					'label'       => esc_html__( 'Accepts Reservations', 'review-schema-pro' ),
					'default'     => 'no',
					'holderClass' => 'rtrs-lb-cond rtrs-lb-food',
					'options'     => [
						'yes' => esc_html__( 'Yes', 'review-schema-pro' ),
						'no'  => esc_html__( 'No', 'review-schema-pro' ),
					],
				],
				[
					'name'        => 'checkinTime',
					'type'        => 'text',
					'label'       => esc_html__( 'Check-in Time', 'review-schema-pro' ),
					'holderClass' => 'rtrs-lb-cond rtrs-lb-lodging',
					'desc'        => esc_html__( 'Lodging categories only. Use 24:00 time, for example 3PM is 15:00:00.', 'review-schema-pro' ),
				],
				[
					'name'        => 'checkoutTime',
					'type'        => 'text',
					'label'       => esc_html__( 'Check-out Time', 'review-schema-pro' ),
					'holderClass' => 'rtrs-lb-cond rtrs-lb-lodging',
					'desc'        => esc_html__( 'Lodging categories only. Use 24:00 time, for example 11AM is 11:00:00.', 'review-schema-pro' ),
				],
				[
					'name'        => 'medicalSpecialty',
					'type'        => 'select2',
					'multiple'    => true,
					'label'       => esc_html__( 'Medical Specialty', 'review-schema-pro' ),
					'options'     => Functions::getMedicalSpecialties(),
					'holderClass' => 'rtrs-lb-cond rtrs-lb-medical',
					'desc'        => esc_html__( 'Medical categories only. The medical specialties offered, for example Emergency, Cardiovascular, Neurologic.', 'review-schema-pro' ),
				],
				[
					'type'        => 'group',
					'name'        => 'menu_sections',
					'label'       => esc_html__( 'Menu Sections', 'review-schema-pro' ),
					'holderClass' => 'rtrs-lb-cond rtrs-lb-food',
					'desc'        => esc_html__( 'Food establishment categories only. Build the menu here, or link to it with the Menu URL field above.', 'review-schema-pro' ),
					'fields'      => [
						[
							'name'  => 'name',
							'type'  => 'text',
							'label' => esc_html__( 'Name', 'review-schema-pro' ),
						],
						[
							'name'  => 'desc',
							'type'  => 'textarea',
							'label' => esc_html__( 'Description', 'review-schema-pro' ),
						],
						[
							'name'  => 'images',
							'type'  => 'gallery',
							'label' => esc_html__( 'Images', 'review-schema-pro' ),
						],
						[
							'name'  => 'availabilityStarts',
							'type'  => 'text',
							'label' => esc_html__( 'Availability Starts', 'review-schema-pro' ),
							'desc'  => sprintf(
								/* translators: %s: example date in Y-m-d\TH:i:s format */
								esc_html__( 'Like: %s', 'review-schema-pro' ),
								wp_date( 'Y-m-d\TH:i:s' )
							),
						],
						[
							'name'  => 'availabilityEnds',
							'type'  => 'text',
							'label' => esc_html__( 'Availability Ends', 'review-schema-pro' ),
							'desc'  => sprintf(
								/* translators: %s: example date in Y-m-d\TH:i:s format */
								esc_html__( 'Like: %s', 'review-schema-pro' ),
								wp_date( 'Y-m-d\TH:i:s' )
							),
						],
						[
							'type'   => 'group',
							'name'   => 'menu_items',
							'label'  => esc_html__( 'Menu Items', 'review-schema-pro' ),
							'fields' => [
								[
									'name'  => 'name',
									'type'  => 'text',
									'label' => esc_html__( 'Name', 'review-schema-pro' ),
								],
								[
									'name'  => 'image',
									'type'  => 'image',
									'label' => esc_html__( 'Image', 'review-schema-pro' ),
								],
								[
									'name'  => 'desc',
									'type'  => 'textarea',
									'label' => esc_html__( 'Description', 'review-schema-pro' ),
								],
								[
									'name'  => 'price',
									'type'  => 'text',
									'label' => esc_html__( 'Price', 'review-schema-pro' ),
								],
								[
									'name'  => 'priceCurrency',
									'type'  => 'text',
									'label' => esc_html__( 'Price Currency', 'review-schema-pro' ),
									'desc'  => esc_html__( 'The 3-letter currency code. (USD)', 'review-schema-pro' ),
								],
								[
									'name'  => 'calories',
									'type'  => 'text',
									'label' => esc_html__( 'Calories', 'review-schema-pro' ),
									'desc'  => esc_html__( 'Like: 170 calories', 'review-schema-pro' ),
								],
								[
									'name'  => 'fatContent',
									'type'  => 'text',
									'label' => esc_html__( 'Fat Content', 'review-schema-pro' ),
									'desc'  => esc_html__( 'Like: 3 grams', 'review-schema-pro' ),
								],
								[
									'name'  => 'fiberContent',
									'type'  => 'text',
									'label' => esc_html__( 'Fiber Content', 'review-schema-pro' ),
								],
								[
									'name'  => 'proteinContent',
									'type'  => 'text',
									'label' => esc_html__( 'Protein Content', 'review-schema-pro' ),
								],
								[
									'name'  => 'suitableForDiet',
									'type'  => 'text',
									'label' => esc_html__( 'Suitable For Diet', 'review-schema-pro' ),
									'desc'  => esc_html__( 'Example: https://schema.org/GlutenFreeDiet', 'review-schema-pro' ),
								],
							],
						],
					],
				],
				[
					'name'  => 'review_section',
					'type'  => 'heading',
					'label' => esc_html__( 'Review', 'review-schema-pro' ),
					'desc'  => esc_html__( 'To add review schema for this type, complete fields below and enable, others live blank.', 'review-schema-pro' ),
				],
				[
					'name'    => 'review_active',
					'type'    => 'tab',
					'label'   => esc_html__( 'Review Status', 'review-schema-pro' ),
					'default' => 'show',
					'options' => [
						'show' => esc_html__( 'Show', 'review-schema-pro' ),
						'hide' => esc_html__( 'Hide', 'review-schema-pro' ),
					],
				],
				[
					'name'     => 'review_author',
					'type'     => 'text',
					'label'    => esc_html__( 'Author', 'review-schema-pro' ),
					'required' => true,
				],
				[
					'name'        => 'review_author_sameAs',
					'type'        => 'textarea',
					'label'       => esc_html__( 'Author Same As profile link', 'review-schema-pro' ),
					'placeholder' => 'https://facebook.com/example&#10;https://twitter.com/example',
					'required'    => true,
					'desc'        => wp_kses( __( "A reference page that unambiguously indicates the item's identity; for example, the URL of the item's Wikipedia page, Freebase page, or official website.<br> Enter new line for every entry", 'review-schema-pro' ), [ 'br' => [] ] ),
				],
				[
					'name'     => 'review_body',
					'type'     => 'textarea',
					'label'    => esc_html__( 'Review body', 'review-schema-pro' ),
					'required' => true,
					'desc'     => esc_html__( 'The actual body of the review.', 'review-schema-pro' ),
				],
				[
					'name'  => 'review_datePublished',
					'type'  => 'text',
					'label' => esc_html__( 'Review published date', 'review-schema-pro' ),
					'class' => 'rtrs-date',
					'desc'  => sprintf(
						/* translators: %s: example date in ISO 8601 (Y-m-d\TH:i:sP) format */
						esc_html__( 'The date (in ISO 8601 date format), Like this: %s', 'review-schema-pro' ),
						wp_date( 'Y-m-d\TH:i:sP' )
					),
				],
				[
					'name'  => 'review_ratingValue',
					'type'  => 'float',
					'label' => esc_html__( 'Average Rating', 'review-schema-pro' ),
					'min'   => 1,
					'desc'  => esc_html__( 'Rating value. (1, 2.5, 3, 5 etc)', 'review-schema-pro' ),
				],
				[
					'name'  => 'review_bestRating',
					'type'  => 'float',
					'label' => esc_html__( 'Best rating', 'review-schema-pro' ),
					'min'   => 1,
					'desc'  => esc_html__( 'The highest value allowed in this rating.', 'review-schema-pro' ),
				],
				[
					'name'  => 'review_worstRating',
					'type'  => 'float',
					'label' => esc_html__( 'Worst rating', 'review-schema-pro' ),
					'min'   => 1,
					'desc'  => esc_html__( 'The lowest value allowed in this rating. * Required if the rating is not on a 5-point scale. If worstRating is omitted, 1 is assumed.', 'review-schema-pro' ),
				],
			],
		];
	}

	/**
	 * Build the per-page LocalBusiness node and its optional Review node.
	 *
	 * @param array     $metaData      Saved meta for this entry.
	 * @param Functions $helper        Free plugin helper (output sanitizing).
	 * @param int       $schema_key_id Row key of this entry.
	 * @param Schema    $schema        Free plugin schema model (ids and shared cleaners).
	 * @return array
	 */
	public function build( $metaData, $helper, $schema_key_id, $schema ) {
		$output         = [];
		$schema_id      = $schema->get_id_with_hash( 'local_business' . $schema_key_id );
		$category       = ! empty( $metaData['category'] ) ? $helper->sanitizeOutPut( $metaData['category'] ) : 'LocalBusiness';
		$local_business = [
			'@id'   => $schema_id,
			'@type' => Functions::getSchemaType( $category ),
		];

		if ( ! empty( $metaData['name'] ) ) {
			$local_business['name'] = $helper->sanitizeOutPut( $metaData['name'] );
		}

		if ( ! empty( $metaData['description'] ) ) {
			$local_business['description'] = $schema->clean_schema_text( $metaData['description'] );
		}

		if ( ! empty( $metaData['image'] ) ) {
			$imges = [];
			foreach ( $metaData['image'] as $img_single ) {
				if ( ! $img_single ) {
					continue;
				}
				$img     = $helper->imageInfo( absint( $img_single ) );
				$imges[] = $helper->sanitizeOutPut( $img['url'], 'url' );
			}
			$local_business['image'] = $imges;
		}

		if ( $category == 'Organization' && ! empty( $metaData['logo'] ) ) {
			$img                    = $helper->imageInfo( absint( $metaData['logo'] ) );
			$local_business['logo'] = $helper->sanitizeOutPut( $img['url'], 'url' );
		}

		if ( ( Functions::isLocalBusinessType( $category ) || Functions::isMedicalOrgType( $category ) ) && ! empty( $metaData['priceRange'] ) ) {
			$local_business['priceRange'] = $schema->clean_price_range( $helper->sanitizeOutPut( $metaData['priceRange'] ) );
		}
		if ( Functions::isFoodEstablishmentType( $category ) ) {
			if ( ! empty( $metaData['servesCuisine'] ) ) {
				$local_business['servesCuisine'] = $helper->sanitizeOutPut( $metaData['servesCuisine'] );
			}
			if ( ! empty( $metaData['menu'] ) ) {
				$local_business['menu'] = $helper->sanitizeOutPut( $metaData['menu'], 'url' );
			}
			if ( isset( $metaData['acceptsReservations'] ) && 'yes' === $metaData['acceptsReservations'] ) {
				$local_business['acceptsReservations'] = 'True';
			}
			if ( isset( $metaData['menu_sections'] ) && is_array( $metaData['menu_sections'] ) ) {
				$local_business_menu_sections = [];
				foreach ( $metaData['menu_sections'] as $menu_sections_single ) {
					$menu_sections_single_schema = [
						'@type' => 'MenuSection',
					];

					if ( ! empty( $menu_sections_single['name'] ) ) {
						$menu_sections_single_schema['name'] = $helper->sanitizeOutPut( $menu_sections_single['name'] );
					}

					if ( ! empty( $menu_sections_single['desc'] ) ) {
						$menu_sections_single_schema['description'] = $schema->clean_schema_text( $menu_sections_single['desc'] );
					}

					if ( ! empty( $menu_sections_single['url'] ) ) {
						$menu_sections_single_schema['url'] = $helper->sanitizeOutPut( $menu_sections_single['url'], 'url' );
					}

					if ( ! empty( $menu_sections_single['images'] ) ) {
						$menu_section_images = [];
						foreach ( $menu_sections_single['images'] as $image ) {
							$img                   = $helper->imageInfo( absint( $image ) );
							$menu_section_images[] = $helper->sanitizeOutPut( $img['url'], 'url' );
						}

						if ( $menu_section_images ) {
							$menu_sections_single_schema['image'] = $menu_section_images;
						}
					}

					if ( ! empty( $menu_sections_single['availabilityStarts'] ) || ! empty( $menu_sections_single['availabilityEnds'] ) ) {
						$menu_sections_single_schema['offers'] = [
							'@type'              => 'Offer',
							'availabilityStarts' => $helper->sanitizeOutPut( $menu_sections_single['availabilityStarts'] ),
							'availabilityEnds'   => $helper->sanitizeOutPut( $menu_sections_single['availabilityEnds'] ),
						];
					}

					if ( isset( $menu_sections_single['menu_items'] ) && is_array( $menu_sections_single['menu_items'] ) ) {
						$local_business_menu_sections_menu_items = [];
						foreach ( $menu_sections_single['menu_items'] as $menu_items_single ) {
							// A nameless item is an untouched repeater row.
							if ( empty( $menu_items_single['name'] ) ) {
								continue;
							}

							$menu_items_single_schema = [
								'@type'       => 'MenuItem',
								'name'        => $helper->sanitizeOutPut( $menu_items_single['name'] ),
								'description' => ! empty( $menu_items_single['desc'] ) ? $helper->sanitizeOutPut( $menu_items_single['desc'] ) : null,
							];

							if ( ! empty( $menu_items_single['image'] ) ) {
								$item_img = $helper->imageInfo( absint( $menu_items_single['image'] ) );
								if ( ! empty( $item_img['url'] ) ) {
									$menu_items_single_schema['image'] = $helper->sanitizeOutPut( $item_img['url'], 'url' );
								}
							}

							if ( ! empty( $menu_items_single['price'] ) ) {
								$menu_items_single_schema['offers'] = [
									'@type' => 'Offer',
									'price' => $helper->sanitizeOutPut( $menu_items_single['price'] ),
								];
								if ( ! empty( $menu_items_single['priceCurrency'] ) ) {
									$menu_items_single_schema['offers']['priceCurrency'] = $helper->sanitizeOutPut( $menu_items_single['priceCurrency'] );
								}
							}

							$menu_items_single_schema['nutrition'] = [
								'@type' => 'NutritionInformation',
							];

							if ( $menu_items_single['calories'] ) {
								$menu_items_single_schema['nutrition']['calories'] = $helper->sanitizeOutPut( $menu_items_single['calories'] );
							}
							if ( $menu_items_single['fatContent'] ) {
								$menu_items_single_schema['nutrition']['fatContent'] = $helper->sanitizeOutPut( $menu_items_single['fatContent'] );
							}
							if ( $menu_items_single['fiberContent'] ) {
								$menu_items_single_schema['nutrition']['fiberContent'] = $helper->sanitizeOutPut( $menu_items_single['fiberContent'] );
							}
							if ( $menu_items_single['proteinContent'] ) {
								$menu_items_single_schema['nutrition']['proteinContent'] = $helper->sanitizeOutPut( $menu_items_single['proteinContent'] );
							}

							if ( count( $menu_items_single_schema['nutrition'] ) < 2 ) {
								unset( $menu_items_single_schema['nutrition'] );
							}

							if ( $menu_items_single['suitableForDiet'] ) {
								$menu_items_single_schema['suitableForDiet'] = $helper->sanitizeOutPut( $menu_items_single['suitableForDiet'] );
							}

							array_push( $local_business_menu_sections_menu_items, $menu_items_single_schema );
						}
						if ( ! empty( $local_business_menu_sections_menu_items ) ) {
							$menu_sections_single_schema['hasMenuItem'] = $local_business_menu_sections_menu_items;
						}
					}

					// An untouched repeater row would otherwise emit a bare
					// MenuSection with nothing but @type.
					if ( count( $menu_sections_single_schema ) < 2 ) {
						continue;
					}

					array_push( $local_business_menu_sections, $menu_sections_single_schema );
				}
				if ( ! empty( $local_business_menu_sections ) ) {
					$local_business['hasMenu']['@type']          = 'Menu';
					$local_business['hasMenu']['hasMenuSection'] = $local_business_menu_sections;
				}
			}
		}

		if ( ! empty( $metaData['address'][0]['addressLocality'] ) || ! empty( $metaData['address'][0]['addressRegion'] )
			 || ! empty( $metaData['address'][0]['postalCode'] )
			 || ! empty( $metaData['address'][0]['streetAddress'] )
		) {
			$local_business['address'] = [
				'@type'           => 'PostalAddress',
				'addressLocality' => $helper->sanitizeOutPut( $metaData['address'][0]['addressLocality'] ),
				'addressRegion'   => $helper->sanitizeOutPut( $metaData['address'][0]['addressRegion'] ),
				'postalCode'      => $helper->sanitizeOutPut( $metaData['address'][0]['postalCode'] ),
				'streetAddress'   => $helper->sanitizeOutPut( $metaData['address'][0]['streetAddress'] ),
				'addressCountry'  => $helper->sanitizeOutPut( $metaData['address'][0]['addressCountry'] ),
			];
		}

		if ( ! empty( $metaData['geo'][0]['latitude'] ) || ! empty( $metaData['geo'][0]['longitude'] ) ) {
			$local_business['geo'] = [
				'@type'     => 'GeoCoordinates',
				'latitude'  => $helper->sanitizeOutPut( $metaData['geo'][0]['latitude'], 'number' ),
				'longitude' => $helper->sanitizeOutPut( $metaData['geo'][0]['longitude'], 'number' ),
			];
		}

		if ( ! empty( $metaData['telephone'] ) ) {
			$local_business['telephone'] = $helper->sanitizeOutPut( $metaData['telephone'] );
		}

		if ( ! empty( $metaData['url'] ) ) {
			$local_business['url'] = $helper->sanitizeOutPut( $metaData['url'], 'url' );
		}

		if ( Functions::isLodgingBusinessType( $category ) ) {
			if ( ! empty( $metaData['checkinTime'] ) ) {
				$local_business['checkinTime'] = $helper->sanitizeOutPut( $metaData['checkinTime'] );
			}
			if ( ! empty( $metaData['checkoutTime'] ) ) {
				$local_business['checkoutTime'] = $helper->sanitizeOutPut( $metaData['checkoutTime'] );
			}
		}

		if ( Functions::isMedicalType( $category ) && ! empty( $metaData['medicalSpecialty'] ) && is_array( $metaData['medicalSpecialty'] ) ) {
			$specialties = array_values(
				array_filter(
					array_map(
						function ( $specialty ) use ( $helper ) {
							$specialty = $helper->sanitizeOutPut( $specialty );

							// medicalSpecialty is a schema.org enumeration; output the full IRI.
							return $specialty ? 'https://schema.org/' . $specialty : '';
						},
						$metaData['medicalSpecialty']
					)
				)
			);
			if ( ! empty( $specialties ) ) {
				$local_business['medicalSpecialty'] = $specialties;
			}
		}

		if ( Functions::isLocalBusinessType( $category ) && isset( $metaData['opening_hours'] ) && is_array( $metaData['opening_hours'] ) ) {
			$local_business_opening_hours = [];
			foreach ( $metaData['opening_hours'] as $opening_hours_single ) {
				$opening_hours_single_schema = [
					'@type'     => 'OpeningHoursSpecification',
					'dayOfWeek' => $opening_hours_single['day'] ? $helper->sanitizeOutPut( $opening_hours_single['day'] ) : '',
					'opens'     => $opening_hours_single['opens'] ? $schema->normalize_opening_time( $helper->sanitizeOutPut( $opening_hours_single['opens'] ) ) : '',
					'closes'    => $opening_hours_single['closes'] ? $schema->normalize_opening_time( $helper->sanitizeOutPut( $opening_hours_single['closes'] ), true ) : '',
				];
				array_push( $local_business_opening_hours, $opening_hours_single_schema );
			}
			$local_business['openingHoursSpecification'] = $local_business_opening_hours;
		}
		$local_business_review = [];

		if ( isset( $metaData['review_active'] ) && $metaData['review_active'] == 'show' ) {
			$local_business_review = [
				'@type' => 'Review',
			];

			if ( ! empty( $local_business['url'] ) ) {
				$type_for_id                  = is_array( $local_business['@type'] ) ? $local_business['@type'][0] : $local_business['@type'];
				$local_business_review['@id'] = $local_business['url'] . '#review-' . strtolower( $type_for_id ) . $schema_key_id;
				$local_business['review']     = [
					'@id' => $local_business_review['@id'],
				];
			}

			if ( isset( $metaData['review_datePublished'] ) && ! empty( $metaData['review_datePublished'] ) ) {
				$local_business_review['datePublished'] = $helper->sanitizeOutPut( $metaData['review_datePublished'] );
			}
			if ( isset( $metaData['review_body'] ) && ! empty( $metaData['review_body'] ) ) {
				$local_business_review['reviewBody'] = $schema->clean_schema_text( $metaData['review_body'] );
			}

			unset( $local_business['@context'] );
			if ( isset( $local_business['description'] ) ) {
				$local_business_review['description'] = Functions::filter_content( $local_business['description'], 200 );
				unset( $local_business['description'] );
			}
			if ( isset( $metaData['review_sameAs'] ) && ! empty( $metaData['review_sameAs'] ) ) {
				$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['review_sameAs'] ) );
				if ( ! empty( $sameAs ) ) {
					$local_business['sameAs'] = $sameAs;
				}
			}

			if ( ! empty( $metaData['review_author'] ) ) {
				$local_business_review['author'] = [
					'@type' => 'Person',
					'name'  => $helper->sanitizeOutPut( $metaData['review_author'] ),
					'@id'   => $schema->get_id_with_hash( 'person-' . sanitize_title( $metaData['review_author'] ) ),
				];

				if ( isset( $metaData['review_author_sameAs'] ) && ! empty( $metaData['review_author_sameAs'] ) ) {
					$sameAs = Functions::get_same_as( $helper->sanitizeOutPut( $metaData['review_author_sameAs'] ) );
					if ( ! empty( $sameAs ) ) {
						$local_business_review['author']['sameAs'] = $sameAs;
					}
				}
			}
			if ( ! empty( $metaData['review_ratingValue'] ) ) {
				$local_business_review['reviewRating'] = [
					'@type'       => 'Rating',
					'ratingValue' => esc_attr( $metaData['review_ratingValue'] ),
				];
				if ( ! empty( $metaData['review_bestRating'] ) ) {
					$local_business_review['reviewRating']['bestRating'] = $helper->sanitizeOutPut( $metaData['review_bestRating'], 'number' );
				}
				if ( ! empty( $metaData['review_worstRating'] ) ) {
					$local_business_review['reviewRating']['worstRating'] = $helper->sanitizeOutPut( $metaData['review_worstRating'], 'number' );
				}
			}
		}

		$output[] = apply_filters( 'rtseo_snippet_local_business', $local_business, $metaData );
		if ( ! empty( $local_business_review ) ) {
			$output[] = apply_filters( 'rtseo_snippet_local_business_review', $local_business_review, $metaData );
		}

		return $output;
	}
}
