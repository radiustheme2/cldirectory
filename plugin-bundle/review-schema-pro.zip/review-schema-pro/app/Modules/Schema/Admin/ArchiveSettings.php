<?php
/**
 * Archive Page schema settings fields (Pro).
 *
 * Moved from the free plugin (3.1.4). Free keeps the Schema → Archive Page
 * sub-tab and the `rtrs_schema_archive_settings` option; it shows only the
 * "Pro Feature" notice until Pro supplies the fields here through
 * `rtrs_schema_archive_settings_options`. Field keys are unchanged, so saved
 * values are used as they are.
 *
 * @package Rtrsp\Modules\Schema\Admin
 */

namespace Rtrsp\Modules\Schema\Admin;

use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ArchiveSettings
 */
class ArchiveSettings {

	use SingletonTrait;

	/**
	 * Register hooks.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'rtrs_schema_archive_settings_options', [ $this, 'add_fields' ] );
	}

	/**
	 * Add the Archive Page fields to the free settings sub-tab.
	 *
	 * Keys merge over an older free plugin's own copy, so nothing is listed twice.
	 *
	 * @param array $options Fields supplied so far.
	 * @return array
	 */
	public function add_fields( $options ) {
		$options = is_array( $options ) ? $options : [];
		unset( $options['pro_update_notice'] );

		return array_merge( $options, self::fields() );
	}

	/**
	 * Archive Page field definitions (blog, product and Classified Listing archives).
	 *
	 * @return array
	 */
	private static function fields() {
		$rtrs_new  = [
			'text_section' => [
				'title' => esc_html__( 'Blog Post Archive', 'review-schema-pro' ),
				'type'  => 'title',
			],
			'archive'      => [
				'title'       => esc_html__( 'Archive?', 'review-schema-pro' ),
				'description' => esc_html__( 'This archive page is for blog post', 'review-schema-pro' ),
				'type'        => 'checkbox',
				'label'       => esc_html__( 'Enable', 'review-schema-pro' ),
			],
			'schema_type'  => [
				'title'       => esc_html__( 'Schema Type', 'review-schema-pro' ),
				'description' => esc_html__( 'Choose the default schema type that will be applied to your blog archive and post listing pages.', 'review-schema-pro' ),
				'type'        => 'select',
				'class'       => 'regular-text',
				'options'     => [
					'article'      => esc_html__( 'Article', 'review-schema-pro' ),
					'news_article' => esc_html__( 'News Article', 'review-schema-pro' ),
					'blog_posting' => esc_html__( 'Blog Posting', 'review-schema-pro' ),
				],
				'empty'       => esc_html__( 'Select One', 'review-schema-pro' ),
				'depends'     => [
					'on' => [
						[
							'field'     => 'rtrs_schema_archive_settings.archive',
							'value'     => 'yes',
							'condition' => '=',
						],
					],
				],
			],
		];
		$rtrs_ecom = [];
		if ( function_exists( 'WC' ) || function_exists( 'EDD' ) ) {
			$rtrs_ecom['product_archive'] = [
				'title'       => esc_html__( 'Product Archive?', 'review-schema-pro' ),
				'description' => esc_html__( 'This archive page is for WooCommerce and EDD product', 'review-schema-pro' ),
				'type'        => 'checkbox',
				'label'       => esc_html__( 'Enable', 'review-schema-pro' ),
			];
		}

		if ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'classified-listing/classified-listing.php' ) ) {
			$rtrs_ecom['cl_archive'] = [
				'title'       => esc_html__( 'Classified Listing Archive?', 'review-schema-pro' ),
				'description' => esc_html__( 'This archive page is for Classified Listing', 'review-schema-pro' ),
				'type'        => 'checkbox',
				'label'       => esc_html__( 'Enable', 'review-schema-pro' ),
			];
		}
		if ( ! empty( $rtrs_ecom ) ) {
			$rtrs_ecom = [
				'ecommerce_archive_section' => [
					'title' => esc_html__( 'E-Commerce Archive', 'review-schema-pro' ),
					'type'  => 'title',
				],
			] + $rtrs_ecom;
		}

		return $rtrs_new + $rtrs_ecom;
	}
}
