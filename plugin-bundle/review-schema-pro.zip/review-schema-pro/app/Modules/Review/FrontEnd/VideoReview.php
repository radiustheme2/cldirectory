<?php
/**
 * Video reviews (Pro).
 *
 * Moved from the free plugin. Free renders image attachments, keeps the
 * shared attachment security layer (upload validation, ownership, binding) and
 * keeps the "Allow video review?" setting (`video_review` review-config meta),
 * which Pro reads; Pro owns the working feature:
 * - `wp_ajax(_nopriv)_rtrs_video_upload`   — hosted video upload.
 * - `wp_ajax(_nopriv)_rtrs_self_video_popup` — hosted video lightbox.
 * - `rtrs_review_attachment_media`         — video items in the review list.
 * - review-video.js / review-video.css     — form, upload and lightbox UI.
 *
 * The form fields and the `rt_attachment` video save stay in
 * FrontEndReviewActionHook. Stored data (`video_review` post meta,
 * `rt_attachment.videos` / `video_source` comment meta) is unchanged.
 *
 * @package Rtrsp\Modules\Review\FrontEnd
 */

namespace Rtrsp\Modules\Review\FrontEnd;

use Rtrs\Helpers\Functions;
use Rtrs\Modules\Review\Helpers\ReviewFns;
use Rtrsp\Traits\SingletonTrait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class VideoReview
 */
class VideoReview {

	use SingletonTrait;

	/**
	 * Free version that no longer ships video reviews itself.
	 */
	const MIN_FREE_VERSION = '3.1.4';

	/**
	 * Front-end script / style handle.
	 */
	const HANDLE = 'rtrsp-review-video';

	/**
	 * Admin (Edit Review screen) script / style handle.
	 */
	const ADMIN_HANDLE = 'rtrsp-review-video-admin';

	/**
	 * Register hooks.
	 *
	 * An older free plugin still ships its own video handlers, rendering and
	 * script; registering ours as well would run both, so stay out of the way.
	 *
	 * @return void
	 */
	public function init() {
		if ( ! self::free_supported() ) {
			return;
		}
		add_action( 'wp_ajax_rtrs_video_upload', [ $this, 'upload' ] );
		add_action( 'wp_ajax_nopriv_rtrs_video_upload', [ $this, 'upload' ] );
		add_action( 'wp_ajax_rtrs_self_video_popup', [ $this, 'popup' ] );
		add_action( 'wp_ajax_nopriv_rtrs_self_video_popup', [ $this, 'popup' ] );
		add_action( 'rtrs_review_attachment_media', [ $this, 'render' ], 10, 3 );
		add_action( 'wp_footer', [ $this, 'maybe_enqueue' ], 5 );
	}

	/**
	 * Whether the active free plugin leaves video reviews to Pro.
	 *
	 * @return bool
	 */
	public static function free_supported() {
		return defined( 'RTRS_VERSION' ) && version_compare( RTRS_VERSION, self::MIN_FREE_VERSION, '>=' );
	}

	/**
	 * Enqueue the front-end video script and style wherever the review script runs.
	 *
	 * Runs on `wp_footer` so review lists printed by shortcodes are covered too;
	 * the edit form arrives over AJAX and needs the script already on the page.
	 *
	 * @return void
	 */
	public function maybe_enqueue() {
		if ( ! wp_script_is( 'rtrs-app', 'enqueued' ) ) {
			return;
		}
		wp_enqueue_style( self::HANDLE, rtrsp()->get_assets_uri( 'css/review-video.css' ), [ 'rtrs-app' ], RTRSP_VERSION );
		wp_enqueue_script( self::HANDLE, rtrsp()->get_assets_uri( 'js/review-video.js' ), [ 'jquery', 'rtrs-app' ], RTRSP_VERSION, true );
		wp_localize_script(
			self::HANDLE,
			'rtrspVideo',
			[
				'uploadVideo' => esc_html__( 'Upload Video', 'review-schema-pro' ),
				'invalidUrl'  => esc_html__( 'Please enter a valid video URL.', 'review-schema-pro' ),
			]
		);
	}

	/**
	 * Enqueue the Edit Review screen script and style (late; printed in the admin footer).
	 *
	 * Not version-gated: it only styles and wires Pro's own admin markup.
	 *
	 * @return void
	 */
	public static function enqueue_admin() {
		wp_enqueue_style( self::ADMIN_HANDLE, rtrsp()->get_assets_uri( 'css/review-video-admin.css' ), [], RTRSP_VERSION );
		wp_enqueue_script( self::ADMIN_HANDLE, rtrsp()->get_assets_uri( 'js/review-video-admin.js' ), [ 'jquery' ], RTRSP_VERSION, true );
		wp_localize_script( self::ADMIN_HANDLE, 'rtrspVideoAdmin', [ 'sure' => esc_html__( 'Are you sure to delete?', 'review-schema-pro' ) ] );
	}

	/**
	 * AJAX: upload a hosted review video.
	 *
	 * Public (nopriv) like the free image upload: the nonce is CSRF protection
	 * only. Authorization is the free upload policy (logged in, or guests when
	 * "Allow Guest Uploads" is on) plus video reviews being enabled for the
	 * review's post, which must be one the visitor can reach. The file is checked
	 * by the free validator against the allowed video types and size.
	 *
	 * @return void
	 */
	public function upload() {
		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => 'Not allowed' ], 403 );
		}

		if ( ! ReviewFns::canUploadMedia() ) {
			wp_send_json_error( [ 'msg' => __( 'You must be logged in to upload files.', 'review-schema-pro' ) ], 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above.
		$post_id = isset( $_POST['post_id'] ) && is_scalar( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		if ( ! $this->can_upload_to( $post_id ) ) {
			wp_send_json_error( [ 'msg' => __( 'Video reviews are not enabled here.', 'review-schema-pro' ) ], 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Checked by ReviewFns::validateReviewUpload() and wp_handle_upload() with an explicit mimes map.
		$file  = isset( $_FILES['rtrs-video'] ) && is_array( $_FILES['rtrs-video'] ) ? $_FILES['rtrs-video'] : [];
		$mimes = ReviewFns::getReviewUploadMimes( 'video' );

		if ( empty( $file['name'] ) || ! $mimes ) {
			wp_send_json_error( [ 'msg' => __( 'Please choose a supported video file.', 'review-schema-pro' ) ] );
		}

		// The browser-sent type is never trusted: extension and content are
		// checked against the allowed video types only.
		$valid = ReviewFns::validateReviewUpload( $file, 'video', $mimes, (int) ReviewFns::getMediaOption( 'video_max_size', 2048 ) * 1024 );
		if ( is_wp_error( $valid ) ) {
			wp_send_json_error( [ 'msg' => $valid->get_error_message() ] );
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$uploaded = wp_handle_upload(
			$file,
			[
				'test_form' => false,
				'test_type' => true,
				'mimes'     => $mimes,
			]
		);

		if ( ! $uploaded || isset( $uploaded['error'] ) ) {
			wp_send_json_error( [ 'msg' => sanitize_text_field( (string) ( $uploaded['error'] ?? '' ) ) ] );
		}

		$filename  = $uploaded['file'];
		$filetype  = wp_check_filetype( basename( $filename ), null );
		$attach_id = wp_insert_attachment(
			[
				'guid'           => $uploaded['url'],
				'post_title'     => sanitize_text_field( preg_replace( '/\.[^.]+$/', '', basename( $filename ) ) ),
				'post_excerpt'   => '',
				'post_content'   => '',
				'post_mime_type' => sanitize_text_field( $filetype['type'] ),
				'post_status'    => 'inherit',
			],
			$filename,
			0
		);

		$file_info = [];
		if ( $attach_id && ! is_wp_error( $attach_id ) ) {
			update_post_meta( $attach_id, 'attach_type', 'review' );

			// Stamp guest uploads with the uploader's token so only they can remove it.
			if ( ! is_user_logged_in() ) {
				update_post_meta( $attach_id, ReviewFns::GUEST_OWNER_META, ReviewFns::getGuestUploadToken( true ) );
			}

			$file_info = [
				'id'   => (int) $attach_id,
				'name' => sanitize_text_field( preg_replace( '/\.[^.]+$/', '', basename( $filename ) ) ),
			];
		}

		wp_send_json_success( [ 'file_info' => $file_info ] );
	}

	/**
	 * Whether a video may be uploaded for a review on this post.
	 *
	 * @param int $post_id Post the review belongs to.
	 * @return bool
	 */
	private function can_upload_to( $post_id ) {
		if ( ! $post_id || ! get_post( $post_id ) ) {
			return false;
		}
		if ( ! ReviewFns::isPublicReviewTarget( $post_id ) && ! current_user_can( 'read_post', $post_id ) ) {
			return false;
		}
		if ( ! Functions::isEnableReviewByPostType( get_post_type( $post_id ), $post_id ) ) {
			return false;
		}

		return ReviewFns::canAttachReviewMedia( $post_id, 'video' );
	}

	/**
	 * AJAX: lightbox markup for a hosted review video.
	 *
	 * The URL is resolved from the attachment ID, never echoed from the request.
	 * Only review video uploads qualify, and one bound to a review is shown only
	 * where that review is visible (approved on a reachable post, or editable).
	 *
	 * @return void
	 */
	public function popup() {
		if ( ! wp_verify_nonce( Functions::get_nonce(), rtrs()->getNonceId() ) ) {
			wp_send_json_error( [ 'message' => 'Not allowed' ], 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verified above.
		$attachment_id = isset( $_REQUEST['attachment_id'] ) && is_scalar( $_REQUEST['attachment_id'] ) ? absint( wp_unslash( $_REQUEST['attachment_id'] ) ) : 0;
		$video_url     = $this->can_view( $attachment_id ) ? (string) wp_get_attachment_url( $attachment_id ) : '';

		if ( '' === $video_url ) {
			wp_send_json_error( [ 'message' => __( 'Video not found.', 'review-schema-pro' ) ], 404 );
		}

		ob_start();

		do_action( 'rtrs_before_self_hosted_popup' );

		// Media lightbox, not the review-form card: `rtrs-modal--media` opts this
		// shell into the dark, media-sized styling and into backdrop-click close.
		// `muted` is required for `autoplay` to be honoured.
		echo '<div class="rtrs-modal rtrs-modal--media" role="dialog" aria-modal="true" aria-label="' . esc_attr__( 'Review video', 'review-schema-pro' ) . '">';
		echo '<div class="rtrs-media-lightbox">';
		echo '<button type="button" class="rtrs-modal-close" aria-label="' . esc_attr__( 'Close', 'review-schema-pro' ) . '">&times;</button>';
		echo '<div class="rtrs-self-video"><video src="' . esc_url( $video_url ) . '" autoplay muted playsinline controls></video></div>';
		echo '</div>';
		echo '</div>';

		do_action( 'rtrs_after_self_hosted_popup' );

		wp_send_json_success( ob_get_clean() );
	}

	/**
	 * Whether the current visitor may open this review video.
	 *
	 * A bound upload follows its review. An unbound one (an upload still in a
	 * form, or a legacy video from before binding) plays for its uploader, or
	 * when a visible review references it, so existing reviews keep playing.
	 *
	 * @param int $attachment_id Attachment ID.
	 * @return bool
	 */
	private function can_view( $attachment_id ) {
		if ( ! $attachment_id || ! ReviewFns::isReviewUpload( $attachment_id ) ) {
			return false;
		}
		if ( 0 !== strpos( (string) get_post_mime_type( $attachment_id ), 'video/' ) ) {
			return false;
		}

		$comment_id = ReviewFns::getReviewAttachmentBinding( $attachment_id );
		if ( $comment_id ) {
			return $this->review_visible( $comment_id );
		}
		if ( ReviewFns::ownsReviewUpload( $attachment_id ) ) {
			return true;
		}

		// Legacy reference: rt_attachment is serialized; the ID may be an int or a numeric string.
		$candidates = get_comments(
			[
				'fields'     => 'ids',
				'number'     => 20,
				'status'     => 'approve',
				// Legacy references are the oldest reviews: newer ones cannot crowd them out.
				'orderby'    => 'comment_ID',
				'order'      => 'ASC',
				'meta_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery
					'relation' => 'OR',
					[ 'key' => 'rt_attachment', 'value' => 'i:' . $attachment_id . ';', 'compare' => 'LIKE' ],
					[ 'key' => 'rt_attachment', 'value' => '"' . $attachment_id . '"', 'compare' => 'LIKE' ],
				],
			]
		);
		foreach ( (array) $candidates as $candidate ) {
			$stored = get_comment_meta( (int) $candidate, 'rt_attachment', true );
			$ids    = array_map( 'absint', (array) ReviewFns::getStoredAttachmentValues( $stored, 'videos' ) );
			if ( in_array( (int) $attachment_id, $ids, true ) && $this->review_visible( (int) $candidate ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether a review is visible to the current visitor.
	 *
	 * @param int $comment_id Review ID.
	 * @return bool
	 */
	private function review_visible( $comment_id ) {
		$comment = get_comment( $comment_id );
		if ( ! $comment instanceof \WP_Comment ) {
			return false;
		}
		if ( current_user_can( 'edit_comment', $comment_id ) ) {
			return true;
		}

		return '1' === (string) $comment->comment_approved && ReviewFns::isPublicReviewTarget( (int) $comment->comment_post_ID );
	}

	/**
	 * Print the video items of one review (free attachment partial hook).
	 *
	 * @param array $attachment Stored `rt_attachment` meta.
	 * @param array $p_meta     Review config of the post type.
	 * @param int   $comment_id Review ID.
	 * @return void
	 */
	public function render( $attachment, $p_meta, $comment_id = 0 ) {
		$enabled = isset( $p_meta['video_review'][0] ) && '1' === (string) $p_meta['video_review'][0];
		if ( ! $enabled || ! is_array( $attachment ) || empty( $attachment['videos'] ) || ! is_array( $attachment['videos'] ) ) {
			return;
		}

		rtrs()->get_partial_path(
			'video-attachment',
			[
				'rtrs_videos'     => $attachment['videos'],
				'rtrs_self_video' => isset( $attachment['video_source'] ) && 'self' === $attachment['video_source'],
				'rtrs_comment_id' => absint( $comment_id ),
			]
		);
	}
}
