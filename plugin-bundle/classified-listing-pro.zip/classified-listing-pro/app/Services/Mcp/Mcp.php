<?php

namespace RtclPro\Services\Mcp;

use RtclPro\Services\Mcp\Abilities\AbilitySchema;
use RtclPro\Services\Mcp\Abilities\MapIconAbilities;
use RtclPro\Services\Mcp\Services\MapIconService;
use RtclPro\Services\Mcp\Services\PageBuilderCatalog;
use RtclPro\Services\Mcp\Services\SoldService;

defined( 'ABSPATH' ) || exit;

/**
 * Pro part of the Classified Listing MCP integration.
 *
 * The base plugin owns the MCP integration: the Tools switch, the MCP Adapter
 * check, the ability categories and the shared services. This class only plugs
 * the Pro-owned features into it (mark as sold, category map icons and the Pro
 * page builder blocks/widgets) and never boots on its own: it waits for the base
 * `rtcl_mcp_loaded` action, which only fires once every requirement is met.
 */
class Mcp {

	private static $booted = false;

	/**
	 * Called from RtclPro::hooks(). Base and Pro both start on plugins_loaded:20,
	 * so the base action may already have fired.
	 */
	public static function init() {
		if ( did_action( 'rtcl_mcp_loaded' ) ) {
			self::boot();
		} else {
			add_action( 'rtcl_mcp_loaded', [ __CLASS__, 'boot' ] );
		}
	}

	/**
	 * Register the Pro MCP hooks (once).
	 */
	public static function boot() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		// Pro-only abilities, registered right after the base abilities.
		add_action( 'rtcl_mcp_abilities_registered', [ MapIconAbilities::class, 'register' ] );

		// Pro parameters on base abilities (search/flags sold, category map icon).
		add_filter( 'wp_register_ability_args', [ AbilitySchema::class, 'extend' ], 10, 2 );

		SoldService::init();
		MapIconService::init();
		PageBuilderCatalog::init();

		add_filter( 'rtcl_mcp_import_features', [ __CLASS__, 'flag_pro_active' ] );
		add_filter( 'rtcl_mcp_listing_schema_features', [ __CLASS__, 'flag_pro_active' ] );

		/**
		 * Fires after the Pro MCP features are hooked into the base integration.
		 */
		do_action( 'rtcl_pro_mcp_loaded' );
	}

	/**
	 * @param array $info Feature availability info.
	 *
	 * @return array
	 */
	public static function flag_pro_active( $info ) {
		$info['pro_active'] = true;

		return $info;
	}

	/**
	 * Insert items into an associative array before the given key (append when the key is missing).
	 *
	 * @param array  $array      Target array.
	 * @param string $before_key Key to insert before.
	 * @param array  $items      Items to insert.
	 *
	 * @return array
	 */
	public static function insert_before( array $array, $before_key, array $items ) {
		$pos = array_search( $before_key, array_keys( $array ), true );
		if ( false === $pos ) {
			return $array + $items;
		}

		return array_slice( $array, 0, $pos, true ) + $items + array_slice( $array, $pos, null, true );
	}

	/**
	 * Insert items into an associative array after the given key (append when the key is missing).
	 *
	 * @param array  $array     Target array.
	 * @param string $after_key Key to insert after.
	 * @param array  $items     Items to insert.
	 *
	 * @return array
	 */
	public static function insert_after( array $array, $after_key, array $items ) {
		$pos = array_search( $after_key, array_keys( $array ), true );
		if ( false === $pos ) {
			return $array + $items;
		}

		return array_slice( $array, 0, $pos + 1, true ) + $items + array_slice( $array, $pos + 1, null, true );
	}
}
