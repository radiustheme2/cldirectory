<?php

namespace RtclPro\Services\Mcp\Abilities;

use RtclPro\Services\Mcp\Mcp;

defined( 'ABSPATH' ) || exit;

/**
 * Adds the Pro parameters back onto base abilities through the WordPress
 * `wp_register_ability_args` filter, at their original position:
 * - rtcl/search-listings, rtcl/update-listing-flags: `sold`
 * - rtcl/create-category: `map_icon_id`
 * - rtcl/update-category: `map_icon`, `map_icon_id`
 */
class AbilitySchema {

	/**
	 * @param array  $args Ability args.
	 * @param string $name Ability name.
	 *
	 * @return array
	 */
	public static function extend( $args, $name ) {
		if ( empty( $args['input_schema']['properties'] ) || ! is_array( $args['input_schema']['properties'] ) ) {
			return $args;
		}

		$props = $args['input_schema']['properties'];

		switch ( $name ) {
			case 'rtcl/search-listings':
				$args['description'] = __( 'Search and filter classified listings using keyword, category, location, price range, status, featured, sold, tags, author, dates, listing type, form/directory, custom fields, and rating. Supports pagination and sorting. Use when the user asks to find, search, filter, list, or compare listings.', 'classified-listing-pro' );
				$props               = Mcp::insert_after( $props, 'featured', [
					'sold' => [ 'type' => 'boolean', 'description' => __( 'Filter by sold status. Requires CL Pro.', 'classified-listing-pro' ) ],
				] );
				break;

			case 'rtcl/update-listing-flags':
				$args['description'] = __( 'Update listing flags: featured and sold status. Sold flag requires Classified Listing Pro. Use when the user asks to mark a listing as featured, unfeatured, sold, or unsold.', 'classified-listing-pro' );
				$props               = Mcp::insert_after( $props, 'featured', [
					'sold' => [ 'type' => 'boolean', 'description' => __( 'Set sold status (requires CL Pro).', 'classified-listing-pro' ) ],
				] );
				break;

			case 'rtcl/create-category':
				$props = Mcp::insert_after( $props, 'image_id', [
					'map_icon_id' => [ 'type' => 'integer', 'description' => __( 'Map marker icon attachment ID (Pro feature).', 'classified-listing-pro' ) ],
				] );
				break;

			case 'rtcl/update-category':
				$props = Mcp::insert_after( $props, 'image', [
					'map_icon'    => [
						'oneOf' => [
							[ 'type' => 'string', 'description' => __( 'Icon URL, local path, or base64 data.', 'classified-listing-pro' ) ],
							[ 'type' => 'integer', 'description' => __( 'Attachment ID.', 'classified-listing-pro' ) ],
						],
						'description' => __( 'Map marker icon (URL, path, base64, or attachment ID). Pro feature.', 'classified-listing-pro' ),
					],
					'map_icon_id' => [ 'type' => 'integer', 'description' => __( 'Map marker icon attachment ID directly. Pro feature.', 'classified-listing-pro' ) ],
				] );
				break;

			default:
				return $args;
		}

		$args['input_schema']['properties'] = $props;

		return $args;
	}
}
