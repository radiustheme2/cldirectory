<?php

namespace RtclPro\Services\Mcp\Services;

use Rtcl\Services\Mcp\Helpers\ImageHelper;

defined( 'ABSPATH' ) || exit;

/**
 * Category map marker icons (`_rtcl_map_icon` term meta) for MCP.
 *
 * Map icons are a Pro feature (Pro owns the category meta box and save
 * handler). Used by rtcl/set-category-map-icon and hooked into the base
 * rtcl/create-category and rtcl/update-category abilities.
 */
class MapIconService {

	public static function init() {
		add_filter( 'rtcl_mcp_create_term_data', [ __CLASS__, 'create_term_data' ], 10, 3 );
		add_filter( 'rtcl_mcp_update_term_meta', [ __CLASS__, 'update_term_meta' ], 10, 4 );
	}

	/**
	 * Store `map_icon_id` when a category is created.
	 *
	 * @param array  $term_data Term data incl. `meta`.
	 * @param string $taxonomy  Taxonomy slug.
	 * @param array  $data      Raw input.
	 *
	 * @return array
	 */
	public static function create_term_data( $term_data, $taxonomy, $data ) {
		if ( rtcl()->category === $taxonomy && ! empty( $data['map_icon_id'] ) && wp_attachment_is_image( absint( $data['map_icon_id'] ) ) ) {
			$term_data['meta']['_rtcl_map_icon'] = absint( $data['map_icon_id'] );
		}

		return $term_data;
	}

	/**
	 * Handle `map_icon` (URL/path/base64/attachment ID) or `map_icon_id` when a category is updated.
	 *
	 * @param array  $updates  Applied updates.
	 * @param string $taxonomy Taxonomy slug.
	 * @param int    $term_id  Term ID.
	 * @param array  $data     Raw input.
	 *
	 * @return array
	 */
	public static function update_term_meta( $updates, $taxonomy, $term_id, $data ) {
		if ( rtcl()->category !== $taxonomy ) {
			return $updates;
		}

		if ( isset( $data['map_icon'] ) && ! empty( $data['map_icon'] ) ) {
			$map_icon_result = ( new self() )->setMapIcon( $taxonomy, $term_id, $data['map_icon'] );
			if ( ! is_wp_error( $map_icon_result ) ) {
				$updates['map_icon_id'] = $map_icon_result['attachment_id'];
				$updates['map_icon_url'] = $map_icon_result['url'];
			}
		} elseif ( isset( $data['map_icon_id'] ) && wp_attachment_is_image( absint( $data['map_icon_id'] ) ) ) {
			// Direct attachment ID update
			update_term_meta( $term_id, '_rtcl_map_icon', absint( $data['map_icon_id'] ) );
			$updates['map_icon_id'] = absint( $data['map_icon_id'] );
		}

		return $updates;
	}

	/**
	 * Set or update the map icon for a category term.
	 *
	 * Supports: URL, local file path, attachment ID, or base64 data.
	 * Only works for the category taxonomy.
	 *
	 * Requires manage_options (admin) capability.
	 *
	 * @param string     $taxonomy Taxonomy slug.
	 * @param int        $term_id  Term ID.
	 * @param mixed      $icon     Icon URL, local path, attachment ID, or base64 data.
	 * @return array|\WP_Error Result array or error.
	 */
	public function setMapIcon( $taxonomy, $term_id, $icon ) {
		// Check admin capability
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error( 'permission_denied', __( 'Administrator access required to set map icons.', 'classified-listing-pro' ) );
		}

		$term = get_term( $term_id, $taxonomy );
		if ( ! $term || is_wp_error( $term ) ) {
			return new \WP_Error( 'term_not_found', __( 'Term not found.', 'classified-listing-pro' ) );
		}

		// Only categories support map icons
		if ( rtcl()->category !== $taxonomy ) {
			return new \WP_Error( 'map_icon_not_supported', __( 'Map icons are only supported for categories.', 'classified-listing-pro' ) );
		}

		// Get old icon info
		$old_icon_id = get_term_meta( $term_id, '_rtcl_map_icon', true );
		$old_icon_url = $old_icon_id ? wp_get_attachment_url( $old_icon_id ) : null;

		// Handle if input is already an attachment ID
		if ( is_numeric( $icon ) ) {
			$attachment_id = absint( $icon );
			if ( ! wp_attachment_is_image( $attachment_id ) ) {
				return new \WP_Error( 'invalid_attachment', __( 'The specified attachment ID is not a valid image.', 'classified-listing-pro' ) );
			}
		} else {
			// Process the icon input (small size for map icons - 64px max)
			$attachment_id = ImageHelper::processTaxonomyImage( $icon, 0, $term->name . ' Map Icon' );
			if ( is_wp_error( $attachment_id ) ) {
				return $attachment_id;
			}
		}

		// Update the term meta
		update_term_meta( $term_id, '_rtcl_map_icon', $attachment_id );

		// Get new icon info
		$new_icon_url = wp_get_attachment_url( $attachment_id );
		$image_metadata = wp_get_attachment_metadata( $attachment_id );
		$dimensions = [
			'width'  => $image_metadata['width'] ?? 0,
			'height' => $image_metadata['height'] ?? 0,
		];

		$result = [
			'term_id'       => $term_id,
			'taxonomy'      => $taxonomy,
			'name'          => $term->name,
			'slug'          => $term->slug,
			'attachment_id' => $attachment_id,
			'url'           => $new_icon_url,
			'dimensions'    => $dimensions,
			'message'       => __( 'Map icon set successfully.', 'classified-listing-pro' ),
		];

		if ( $old_icon_id ) {
			$result['old_attachment_id'] = absint( $old_icon_id );
			$result['old_url'] = $old_icon_url;
		}

		return $result;
	}
}
