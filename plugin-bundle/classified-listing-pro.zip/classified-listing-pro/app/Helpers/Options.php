<?php

namespace RtclPro\Helpers;

use Rtcl\Helpers\Link;
use Rtcl\Resources\Options as RtclOptions;

class Options {

	static function get_custom_page_list() {
		$pages = [
			'compare_page' => [
				'title'   => esc_html__( 'Compare', 'classified-listing-pro' ),
				'content' => '',
			],
		];

		return apply_filters( 'rtcl_pro_custom_pages_list', $pages );
	}


	public static function get_registered_only_options() {
		$options = [
			'listing_seller_information' => esc_html__( 'Listing seller information', 'classified-listing-pro' ),
		];

		return apply_filters( 'rtcl_registered_only_options', $options );
	}


	/**
	 * @return mixed|void
	 */
	static function get_app_redirect_list() {
		$list = [
			'home'      => esc_html__( "Home", "classified-listing-pro" ),
			'my_ads'    => esc_html__( "My ads", "classified-listing-pro" ),
			'promotion' => esc_html__( "Promotion", "classified-listing-pro" ),
		];

		return apply_filters( 'rtcl_pro_get_app_redirect_list', $list );
	}

	/**
	 * @return array|object
	 * @deprecated
	 * @use Rtcl\Resources\Options::is_enable_map()
	 */
	static function get_radius_search_options() {
		_deprecated_function( __METHOD__, '2.0.9', 'Rtcl\Resources\Options::is_enable_map()' );

		return RtclOptions::radius_search_options();
	}

	static function widget_search_style_options() {
		$options = [
			'popup'      => esc_html__( 'Popup', 'classified-listing-pro' ),
			'suggestion' => esc_html__( 'Auto Suggestion', 'classified-listing-pro' ),
			'dependency' => esc_html__( 'Dependency Selection', 'classified-listing-pro' ),
			'standard'   => esc_html__( 'Standard', 'classified-listing-pro' ),
		];

		return apply_filters( 'rtcl_pro_widget_search_style_options', $options );
	}

	static function get_listings_view_options() {
		$options = [
			'list' => esc_html__( "List", 'classified-listing-pro' ),
			'grid' => esc_html__( "Grid", 'classified-listing-pro' ),
		];

		return apply_filters( 'rtcl_pro_listings_view_options', $options );
	}

	public static function chat_admin_settings() {
		$options = [
			'ls_section'                            => [
				'title'       => esc_html__( 'Chat Settings', 'classified-listing-pro' ),
				'type'        => 'section',
				'description' => wp_kses( sprintf( __( 'Regenerate Chat Table <a href="%s" onClick="return confirm(\'Do you really want to Confirm this booking\')">Click Here.</a> <span style="color:red">This will remove all chat history.</span>',
					'classified-listing-pro' ),
					add_query_arg( [
						rtcl()->nonceId              => wp_create_nonce( rtcl()->nonceText ),
						'rtcl_regenerate_chat_table' => '',
					], admin_url( 'admin.php?page=rtcl-settings&parentId=rtcl_chat_settings' ) ) ),
					[
						'a'    => [
							'href'    => [],
							'onClick' => [],
						],
						'span' => [
							'style' => [ 'color' ],
						],
					] ),
			],
			'enable'                                => [
				'title'       => esc_html__( 'Enable Chat', 'classified-listing-pro' ),
				'label'       => esc_html__( 'Enable', 'classified-listing-pro' ),
				'type'        => 'switch',
				'description' => esc_html__( 'Enable chat option', 'classified-listing-pro' ),
			],
			'unread_message_email'                  => [
				'title'       => esc_html__( 'Unread Message Email', 'classified-listing-pro' ),
				'label'       => esc_html__( 'Enable', 'classified-listing-pro' ),
				'type'        => 'switch',
				'description' => esc_html__( 'Enable email for unread message trace to receiver, if receiver at offline.', 'classified-listing-pro' ),
			],
			'remove_inactive_conversation_duration' => [
				'title'       => esc_html__( 'Delete Inactive Conversation (in days)', 'classified-listing-pro' ),
				'type'        => 'number',
				'default'     => 30,
				'description' => wp_kses(
					__( 'Auto remove inactive conversation which are last active in given days ago <span style="color: red">(Leave it blank to alive conversation forever)</span>.',
						'classified-listing-pro' ),
					[
						'span' => [
							'style' => true,
						],
					],
				),
			],
			'bad_words'                             => [
				'title'       => esc_html__( 'Bad Words', 'classified-listing-pro' ),
				'type'        => 'textarea',
				'description' => __( 'Add bad word by comma separated. Example:', 'classified-listing-pro' )
				                 . '<span style="font-size:80%"> porn,murder</span>',
			],
		];

		$options = array_merge( $options, self::chat_quick_question_settings(), [
			'pusher_section'                        => [
				'title'       => esc_html__( 'Pusher Integration', 'classified-listing-pro' ),
				'type'        => 'section',
				'description' => __( 'Go to Pusher and create account <a href="https://pusher.com/" target="_blank">https://pusher.com/</a>',
					'classified-listing-pro' ),
			],
			'pusher_enable'                         => [
				'title' => esc_html__( 'Enable Pusher', 'classified-listing-pro' ),
				'label' => esc_html__( 'Enable', 'classified-listing-pro' ),
				'type'  => 'switch',
			],
			'pusher_app_id'                         => [
				'title' => esc_html__( 'App ID', 'classified-listing-pro' ),
				'type'  => 'text',
			],
			'pusher_app_key'                        => [
				'title' => esc_html__( 'Key', 'classified-listing-pro' ),
				'type'  => 'text',
			],
			'pusher_app_secret'                     => [
				'title' => esc_html__( 'Secret', 'classified-listing-pro' ),
				'type'  => 'text',
			],
			'pusher_app_cluster'                    => [
				'title' => esc_html__( 'Cluster', 'classified-listing-pro' ),
				'type'  => 'text',
			],
		] );

		return apply_filters( 'rtcl_chat_settings_options', $options );
	}

	/**
	 * Quick question fields: a default list plus one optional list per directory form.
	 *
	 * @return array
	 */
	public static function chat_quick_question_settings() {
		$placeholder = implode( "\n", Fns::get_default_chat_quick_questions() );
		// The question fields only matter while quick questions are switched on.
		$depends     = [
			'on' => [
				[
					'field'     => 'rtcl_chat_settings.quick_questions_enable',
					'value'     => 'yes',
					'condition' => '=',
				],
			],
		];
		$fields      = [
			'quick_questions_section' => [
				'title'       => esc_html__( 'Quick Questions', 'classified-listing-pro' ),
				'type'        => 'section',
				'description' => esc_html__( 'Ready-made questions a buyer can tap to start a chat with the seller. Write one question per line; up to 6 are shown.', 'classified-listing-pro' ),
			],
			'quick_questions_enable'  => [
				'title'   => esc_html__( 'Show Quick Questions', 'classified-listing-pro' ),
				'type'    => 'switch',
				'default' => 'yes',
			],
			'quick_questions'         => [
				'title'       => esc_html__( 'Default Questions', 'classified-listing-pro' ),
				'type'        => 'textarea',
				'placeholder' => $placeholder,
				'description' => esc_html__( 'Shown on listings whose form has no questions of its own, and on the My Account chat page. Leave empty to use the questions shown.', 'classified-listing-pro' ),
				'depends'     => $depends,
			],
		];

		$form_fields = [];
		foreach ( Fns::get_chat_question_forms() as $form_id => $form_title ) {
			// New forms are saved as "Name (#ID)"; drop that so the ID isn't shown twice.
			$form_name = trim( preg_replace( '/\s*\(#' . absint( $form_id ) . '\)\s*$/', '', wp_strip_all_tags( $form_title ) ) );
			$form_fields[ 'quick_questions_form_' . absint( $form_id ) ] = [
				/* translators: 1: form name, 2: form ID */
				'title'       => sprintf( __( '%1$s (ID: %2$d)', 'classified-listing-pro' ), $form_name, absint( $form_id ) ),
				'type'        => 'textarea',
				'description' => esc_html__( 'Shown on listings posted with this form. Leave empty to use the default questions.', 'classified-listing-pro' ),
				'depends'     => $depends,
			];
		}

		if ( $form_fields ) {
			$fields['quick_questions_form_section'] = [
				'title'       => esc_html__( 'Form-wise Quick Questions', 'classified-listing-pro' ),
				'type'        => 'section',
				'description' => esc_html__( 'Give listings from a specific form their own questions. They replace the default questions on those listings.', 'classified-listing-pro' ),
				'depends'     => $depends,
			];
			$fields += $form_fields;
		}

		return $fields;
	}

	public static function app_admin_settings() {
		$schedulerData = get_option( 'rtcl_pro_cron_send_newsletter_pn_data', [] );
		$apiKey        = get_option( 'rtcl_rest_api_key', null );

		$news_letter_processing_text = esc_html__( 'Processing existing newsletter queue …', 'classified-listing-pro' );
		if ( ! empty( $schedulerData ) && is_array( $schedulerData ) ) {
			global $wpdb;
			$pn_table  = $wpdb->prefix . 'rtcl_push_notifications';
			$total     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pn_table}" );
			$sent      = min( absint( $schedulerData['offset'] ?? 0 ), $total );
			$remaining = max( 0, $total - $sent );
			$news_letter_processing_text = sprintf(
			/* translators: 1: sent count, 2: total count, 3: remaining count */
				esc_html__( 'Sending push notifications — %1$d of %2$d sent, %3$d remaining …', 'classified-listing-pro' ),
				$sent, $total, $remaining
			);
		}

		if ( $apiKey ) {
			$rest_api_key_html = sprintf( '<div><span class="rtcl-rest-api-key">%s</span>%s</div> %s',
				$apiKey,
				! wp_is_uuid( $apiKey ) ? '<span class="rtcl-rest-api-key-invalid" style="color: red">%s Key is not validate.</span>' : '',
				sprintf(
					'<a href="%s" onclick="return confirm(%s)">%s</a>',
					add_query_arg(
						[
							'_wpnonce'                   => wp_create_nonce( 'rtcl_generate_rest_api_key' ),
							'rtcl_generate_rest_api_key' => 1,
						],
						admin_url( 'admin.php?page=rtcl-settings&parentId=rtcl_app_settings' ),
					),
					esc_html__( "'Are you sure want to regenerate REST API key?'", 'classified-listing-pro' ),
					esc_html__( 'Regenerate Rest API key', 'classified-listing-pro' ),
				),
			);
		} else {
			$rest_api_key_html = sprintf(
				'<a href="%s">%s</a>',
				add_query_arg(
					[
						'_wpnonce'                   => wp_create_nonce( 'rtcl_generate_rest_api_key' ),
						'rtcl_generate_rest_api_key' => 1,
					],
					admin_url( 'admin.php?page=rtcl-settings&parentId=rtcl_app_settings' ),
				),
				esc_html__( 'Create Rest API key', 'classified-listing-pro' ),
			);
		}

		$fields = [
			'general'                       => [
				'title' => esc_html__( 'General Settings', 'classified-listing-pro' ),
				'type'  => 'section',
			],
			'allow_rest_api'                => [
				'title'       => esc_html__( 'Allow REST API', 'classified-listing-pro' ),
				'type'        => 'checkbox',
				'description' => esc_html__( 'Allow to handle data to app.', 'classified-listing-pro' ),
			],
			'rest_api_key'                  => [
				'title'       => esc_html__( 'REST API Key', 'classified-listing-pro' ),
				'type'        => 'html',
				'html'        => $rest_api_key_html,
				'description' => '<span style="color: red">'
				                 . esc_html__( 'This is one time generated key. Do not recreate this key. if you regenerate then you need to change the key from your application where you are currently using.',
						'classified-listing-pro' ) . '</span>',
			],
			'redirect_new_listing'          => [
				'title'       => esc_html__( 'Redirect after New Listing', 'classified-listing-pro' ),
				'type'        => 'select',
				'default'     => 'home',
				'options'     => Options::get_app_redirect_list(),
				'description' => esc_html__( 'Redirect after successfully post a new listing', 'classified-listing-pro' ),
			],
			'pn'                            => [
				'title' => esc_html__( 'App Push Notification settings', 'classified-listing-pro' ),
				'type'  => 'section',
			],
			'app_schema'                    => [
				'title'       => esc_html__( 'App Schema', 'classified-listing-pro' ),
				'type'        => 'text',
				'placeholder' => esc_html__( 'myapp', 'classified-listing-pro' ),
				'description' => wp_kses(
					__( 'At your react native app folder -> app.json "expo": {"scheme": <b>"myapp"</b>}', 'classified-listing-pro' ),
					[
						'b' => [],
					],
				),
			],
			'pn_events'                     => [
				'title'       => esc_html__( 'Allow Events', 'classified-listing-pro' ),
				'type'        => 'multi_checkbox',
				'orientation' => 'vertical',
				'options'     => PNHelper::getEventList(),
				'description' => esc_html__( 'Allow to handle data to app.', 'classified-listing-pro' ),
			],
			'field_title_send_notification' => [
				'title'       => esc_html__( 'Send business letter using push notification', 'classified-listing-pro' ),
				'type'        => 'section',
				'description' => __( 'Send push notification to app for all users ', 'classified-listing' ),
			],
			'news_letter_pn'                => [
				'title'           => esc_html__( 'Send business letter using push notification', 'classified-listing-pro' ),
				'type'            => 'app_notification',
				'isProcessing'    => ! empty( $schedulerData ),
				'processing_text' => $news_letter_processing_text,
				'ajax_call'       => [
					'url_var'   => 'RtclPro.ajaxurl',
					'action'    => 'rtcl_pro_send_news_letter_push_notification',
					'nonce_id'  => '__rtcl_pro_wpnonce',
					'nonce_var' => 'RtclPro.__rtcl_pro_wpnonce',
				],
				'reset_ajax_call' => [
					'url_var'   => 'RtclPro.ajaxurl',
					'action'    => 'rtcl_pro_reset_news_letter_push_notification',
					'nonce_id'  => '__rtcl_pro_wpnonce',
					'nonce_var' => 'RtclPro.__rtcl_pro_wpnonce',
				],
			],
			'app_debugger'                  => [
				'title'       => esc_html__( 'App Debugger', 'classified-listing-pro' ),
				'type'        => 'section',
				'description' => '',
			],
			'iap_disabled'                  => [
				'title'       => esc_html__( 'Disable In App Purchase', 'classified-listing-pro' ),
				'type'        => 'checkbox',
				'description' => esc_html__( 'Disable in app purchase, This will turn off membership and promotion feature from app.',
					'classified-listing-pro' ),
			],
			'iap_disabled_version'          => [
				'title'       => esc_html__( 'App Version', 'classified-listing-pro' ),
				'type'        => 'text',
				'description' => '<span style="color: red">' . esc_html__( 'This field is required. Without this version number, the in app purchase option will not work. i.e. 1.x.x', 'classified-listing-pro' ) . '</span>',
				'depends'     => [
					'relation' => 'or',
					'on'       => [
						[
							'field'     => 'rtcl_app_settings.iap_disabled',
							'value'     => 'yes',
							'condition' => '=',
						],
					],
				],
			],
		];

		return apply_filters( 'rtcl_app_settings_options', $fields );
	}

}