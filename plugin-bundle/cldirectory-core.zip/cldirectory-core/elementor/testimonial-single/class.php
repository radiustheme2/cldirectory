<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\CLDirectory_Core;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Testimonial_Single extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ) {
		$this->rt_name = esc_html__( 'Testimonial Single', 'cldirectory-core' );
		$this->rt_base = 'rt-testimonial-single';
		parent::__construct( $data, $args );
	}

	public function get_script_depends() {
		return [
			'swiper',
		];
	}

	protected function register_controls() {
		$this->__general_settings();
		$this->__box_style();
		$this->__name_style();
		$this->__designation_style();
		$this->__image_style();
		$this->__content_style();
		$this->__rating_style();
		$this->__quote_style();
	}

	protected function __general_settings() {
		$this->start_controls_section(
			'single_testimonial_section',
			[
				'label' => esc_html__( 'Testimonial Content', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout',
			[
				'label'   => esc_html__( 'Style', 'cldirectory-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => __( 'Style 1', 'cldirectory-core' ),
					'2' => __( 'Style 2', 'cldirectory-core' ),
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => __( 'Client Image', 'cldirectory-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'name',
			[
				'label'   => __( 'Name', 'cldirectory-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Mike Chen', 'cldirectory-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'designation',
			[
				'label'   => __( 'Designation', 'cldirectory-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Business Owner', 'cldirectory-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'content',
			[
				'label'   => __( 'Testimonial Content', 'cldirectory-core' ),
				'type'    => Controls_Manager::TEXTAREA,
				'default' => __( '"Listing my business here increased foot traffic by 40%. Highly recommend for any business!"', 'cldirectory-core' ),
				'rows'    => 5,
			]
		);

		$this->add_control(
			'rating',
			[
				'label'   => __( 'Rating (1-5)', 'cldirectory-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '5',
				'options' => [
					'1' => '1 Star',
					'2' => '2 Stars',
					'3' => '3 Stars',
					'4' => '4 Stars',
					'5' => '5 Stars',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function __box_style() {
		// Style: Box
		$this->start_controls_section(
			'box_style',
			[
				'label' => __( 'Box Style', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'box_background',
				'label'    => __( 'Background', 'cldirectory-core' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .rt-single-testimonial',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_border',
				'selector' => '{{WRAPPER}} .rt-single-testimonial',
			]
		);

		$this->add_control(
			'box_border_radius',
			[
				'label'      => __( 'Border Radius', 'cldirectory-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .rt-single-testimonial' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'selector' => '{{WRAPPER}} .rt-single-testimonial',
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label'      => __( 'Padding', 'cldirectory-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .rt-single-testimonial' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function __name_style() {
		// Style: Name
		$this->start_controls_section(
			'name_style',
			[
				'label' => __( 'Name', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typo',
				'label'    => __( 'Name Typography', 'cldirectory-core' ),
				'selector' => '{{WRAPPER}} .rt-testimonial-name',
			]
		);

		$this->add_control(
			'name_color',
			[
				'label'     => __( 'Name Color', 'cldirectory-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function __designation_style() {
		// Style: Designation
		$this->start_controls_section(
			'designation_style',
			[
				'label' => __( 'Designation', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'designation_typo',
				'label'    => __( 'Designation Typography', 'cldirectory-core' ),
				'selector' => '{{WRAPPER}} .rt-testimonial-designation',
			]
		);

		$this->add_control(
			'designation_color',
			[
				'label'     => __( 'Designation Color', 'cldirectory-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-designation' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function __image_style() {
		// Style: Image
		$this->start_controls_section(
			'image_style',
			[
				'label' => __( 'Image', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'image_width',
			[
				'label'     => __( 'Width', 'cldirectory-core' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [ 'px' => [ 'min' => 50, 'max' => 300 ] ],
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-image img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'image_border_radius',
			[
				'label'      => __( 'Border Radius', 'cldirectory-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .rt-testimonial-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected  function __content_style() {
		// Style: Content
		$this->start_controls_section(
			'content_style',
			[
				'label' => __( 'Content', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typo',
				'label'    => __( 'Typography', 'cldirectory-core' ),
				'selector' => '{{WRAPPER}} .rt-testimonial-content',
			]
		);

		$this->add_control(
			'content_color',
			[
				'label'     => __( 'Color', 'cldirectory-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function __rating_style() {
		// Style: Rating
		$this->start_controls_section(
			'rating_style',
			[
				'label' => __( 'Rating Stars', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'star_color',
			[
				'label'     => __( 'Star Color', 'cldirectory-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-rating .star-active' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'star_inactive_color',
			[
				'label'     => __( 'Inactive Star Color', 'cldirectory-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ccc',
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-rating .star-inactive' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'star_size',
			[
				'label'     => __( 'Star Size', 'cldirectory-core' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [ 'px' => [ 'min' => 10, 'max' => 50 ] ],
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-rating i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function __quote_style() {
		// Style: Quote Icon
		$this->start_controls_section(
			'quote_style',
			[
				'label' => __( 'Quote Icon', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'quote_color',
			[
				'label'     => __( 'Quote Color', 'cldirectory-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-quote svg path' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'quote_size',
			[
				'label'     => __( 'Quote Size', 'cldirectory-core' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [ 'px' => [ 'min' => 50, 'max' => 200 ] ],
				'selectors' => [
					'{{WRAPPER}} .rt-testimonial-quote svg' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function render() {
		$data = $this->get_settings();

		$template = 'view-'.$data['layout'];

		$this->rt_template( $template, $data );
	}

}