<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\ClProperty_Core;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Group_Control_Image_Size;

$term = get_term_by('id', $data['category'], 'rtcl_category',ARRAY_A);
$getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'rt_image' );
$alignment = !empty( $data['alignment'] ) ? $data['alignment'] : 'left';

?>
<div class="rt-listing-category-wrapper layout-style-1 content-alignment-<?php echo esc_attr( $alignment ); ?>">
    <?php if ( ! empty( $term ) ) :

        $term_id = $term['term_id'];
        $name = $term['name'];
        $count = $term['count'];
        ?>
        <div class="categories-block">
            <?php if($data['show_image'] && $getimg){ ?>
                <div class="category-full-image">
                    <a href="<?php echo esc_url(get_term_link($term_id,'rtcl_category')); ?>">
                        <?php echo wp_kses_post($getimg); ?>
                    </a>
                </div>
            <?php } ?>
            <div class="category-content-wrapper">
                <?php if ( $data['show_icon']){ ?>
                <div class="categories-block-icon">
                    <?php
                    if($data['cat_icon_style']=='default'){
                        $icon = get_term_meta( $term_id, '_rtcl_icon', true );
                        ?>
                        <i class="rtcl-icon rtcl-icon-<?php echo esc_attr( $icon ) ?>"></i>
                    <?php }
                    else if($data['cat_icon_style']=='default_image'){
                        $image_id = get_term_meta( $term_id, '_rtcl_image', true );
                        if($image_id){
                            echo wp_kses_post(wp_get_attachment_image($image_id,'thumbnail'));
                        }
                    }
                    ?>
                </div>
                <?php } ?>
                <div class="categories-block-content">
                    <h3 class="categories-block__cname"><a href="<?php echo get_term_link( $term_id ) ?>"><?php echo esc_html( $name ) ?></a></h3>
                    <?php
                    if ( $data['show_count']){
                        $cats_count = $count . ' ' . $data['cat_count_suffix'];
                        ?>
                    <a href="<?php echo get_term_link( $term_id ) ?>" class="categories-listing-count"><?php echo esc_html__( $cats_count, 'cldirectory-core' ); ?></a>
                    <?php } ?>
                </div>
            </div>
        </div>
        <?php
    ?>
    <?php endif; ?>
</div>

