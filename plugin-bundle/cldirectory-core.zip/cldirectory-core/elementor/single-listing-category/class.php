<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\ClDirectory_Core;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Single_Listing_Category extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ) {
		$this->rt_name = esc_html__( 'RT Single Listing Category', 'cldirectory-core' );
		$this->rt_base = 'rt-single-listing-category';
		parent::__construct( $data, $args );
	}

	protected function register_controls() {

		$this->__general_settings();
		$this->__box_settings();
		$this->__icon_settings();
		$this->__title_settings();
		$this->__category_count_settings();
	}


	protected function __general_settings() {
		$category_dropdown = [ '' => esc_html__( '— Select Category —', 'cldirectory-core' ) ];
		if ( function_exists( 'rtcl' ) && rtcl() && taxonomy_exists( rtcl()->category ) ) {
			$terms = get_terms( [
				'taxonomy'   => rtcl()->category,
				'hide_empty' => true,
			] );

			if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				foreach ( $terms as $term ) {
					$category_dropdown[ $term->term_id ] = $term->name . ' (' . $term->count . ' listings)';
				}
			}
		}
		if ( count( $category_dropdown ) === 1 ) {
			$category_dropdown[0] = esc_html__( 'No categories found', 'cldirectory-core' );
		}

		$this->start_controls_section(
			'sec_general',
			[
				'label' => esc_html__( 'General', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Style', 'cldirectory-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => __( 'Style 1', 'cldirectory-core' ),
					'2' => __( 'Style 2', 'cldirectory-core' ),
					'3' => __( 'Style 3', 'cldirectory-core' ),
				],
			]
		);

		$this->add_control(
			'category',
			[
				'type'        => Controls_Manager::SELECT2,
				'label'       => esc_html__( 'Choose Category', 'cldirectory-core' ),
				'options'     => $category_dropdown,
				'multiple'    => false,
				'label_block' => true,
				'default'     => '',
			]
		);

		$this->add_control(
			'rt_image',
			[
				'label'     => __( 'Choose Image', 'cldirectory-core' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [ 'style' => '1' ],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'rt_image_size',
				'default'   => 'full',
				'condition' => [ 'style' => '1' ],
			]
		);

		$this->add_control(
			'more_options',
			[
				'label'     => esc_html__( 'Visibility Options', 'cldirectory-core' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'show_image',
			[
				'label'        => esc_html__( 'Show Image', 'cldirectory-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'cldirectory-core' ),
				'label_off'    => esc_html__( 'Hide', 'cldirectory-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [ 'style' => '1' ],
			]
		);

		$this->add_control(
			'show_icon',
			[
				'label'        => esc_html__( 'Show Icon', 'cldirectory-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'cldirectory-core' ),
				'label_off'    => esc_html__( 'Hide', 'cldirectory-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_count',
			[
				'label'        => esc_html__( 'Show Count', 'cldirectory-core' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'cldirectory-core' ),
				'label_off'    => esc_html__( 'Hide', 'cldirectory-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();
	}


	protected function __box_settings() {
		$this->start_controls_section(
			'box_settings',
			[
				'label' => esc_html__( 'Box Settings', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'content_alignment',
			[
				'label'     => __( 'Alignment', 'cldirectory-core' ),
				'type'      => Controls_Manager::CHOOSE,
				'options'   => [
					'flex-start'   => [
						'title' => __( 'Left', 'cldirectory-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'cldirectory-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'flex-end'  => [
						'title' => __( 'Right', 'cldirectory-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block .category-content-wrapper' => 'align-items: {{VALUE}}; text-align: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_control(
			'box_margin',
			[
				'label'      => __( 'Margin Bottom', 'cldirectory-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors'  => [
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_height',
			[
				'type'            => Controls_Manager::SLIDER,
				'label'           => __( 'Image Height', 'cldirectory-core' ),
				'size_units'      => [ 'px' ],
				'range'           => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices'         => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 290,
					'unit' => 'px',
				],
				'tablet_default'  => [
					'size' => 240,
					'unit' => 'px',
				],
				'mobile_default'  => [
					'size' => 220,
					'unit' => 'px',
				],
				'selectors'       => [
					'{{WRAPPER}} .rt-listing-category-wrapper .category-full-image > a img' => 'height: {{SIZE}}{{UNIT}};object-fit:cover;',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'type'    => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'label'   => esc_html__( 'Box Padding', 'cldirectory-core' ),
				'selectors' => array(
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
			]
		);

		$this->start_controls_tabs( 'cat_box_tab_style' );
		// Normal tab.
		$this->start_controls_tab(
			'box_style_normal',
			[
				'label' => __( 'Normal', 'cldirectory-core' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'box_style_normal_bg_color',
				'label'    => esc_html__( 'Background', 'cldirectory-core' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'fields_options' => [
					'background' => [
						'label' => esc_html__('Background', 'cldirectory-core'),
						'default' => 'classic',
					]
				],
				'selector' => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_style_normal_border',
				'label'     => __( 'Border', 'cldirectory-core' ),
				'selector'  => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block',
			]
		);
		$this->add_responsive_control(
			'box_style_normal_border_radius',
			[
				'type'    => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'label'   => esc_html__( 'Radius', 'cldirectory-core' ),
				'selectors' => array(
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
			]
		);
		$this->end_controls_tab();

		// Hover tab.
		$this->start_controls_tab(
			'box_style_hover',
			[
				'label' => __( 'Hover', 'cldirectory-core' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'box_style_hover_bg_color',
				'label'    => esc_html__( 'Background', 'cldirectory-core' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'fields_options' => [
					'background' => [
						'label' => esc_html__('Background', 'cldirectory-core'),
						'default' => 'classic',
					]
				],
				'selector' => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_style_hover_border',
				'label'     => __( 'Border', 'cldirectory-core' ),
				'selector'  => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block:hover',
			]
		);
		$this->add_responsive_control(
			'box_style_hover_border_radius',
			[
				'type'    => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'label'   => esc_html__( 'Radius', 'cldirectory-core' ),
				'selectors' => array(
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
	}


	protected function __icon_settings() {
		$this->start_controls_section(
			'icon_settings',
			[
				'label' => esc_html__( 'Icon Settings', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'cat_icon_style',
			[
				'label'   => __( 'Icon Source', 'cldirectory-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default'       => __( 'Icon From Category', 'cldirectory-core' ),
					'default_image' => __( 'Image From Category', 'cldirectory-core' ),
				],
			]
		);

		$this->add_control(
			'thumb_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'icon_box_size',
			[
				'label'      => __( 'Icon Box Size', 'cldirectory-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 30,
						'max'  => 200,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block .categories-block-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'icon_font_size',
			[
				'label'      => __( 'Icon Font Size', 'cldirectory-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 10,
						'max'  => 200,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block .categories-block-icon .rtcl-icon'   => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition'  => [
					'cat_icon_style' => 'default',
				],
			]
		);

		$this->add_control(
			'icon_img_size',
			[
				'label'      => __( 'Image Size', 'cldirectory-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 30,
						'max'  => 200,
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block  .categories-block-icon > img' => 'width: {{SIZE}}{{UNIT}};height:auto',
				],
				'condition'  => [
					'cat_icon_style' => 'default_image',
				],
			]
		);

		$this->start_controls_tabs( 'icon_box_tab_style' );
		// Normal tab.
		$this->start_controls_tab(
			'icon_box_style_normal',
			[
				'label' => __( 'Normal', 'cldirectory-core' ),
			]
		);

		// Icon Color.
		$this->add_control(
			'cat_icon_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Icon Color', 'cldirectory-core' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block  .categories-block-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_style_normal_bg_color',
				'label'    => esc_html__( 'Background', 'cldirectory-core' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'fields_options' => [
					'background' => [
						'label' => esc_html__('Background', 'cldirectory-core'),
						'default' => 'classic',
					]
				],
				'selector' => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block  .categories-block-icon',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_style_normal_border',
				'label'     => __( 'Border', 'cldirectory-core' ),
				'selector'  => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block  .categories-block-icon',
			]
		);
		$this->add_responsive_control(
			'icon_box_style_normal_border_radius',
			[
				'type'    => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'label'   => esc_html__( 'Radius', 'cldirectory-core' ),
				'selectors' => array(
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block .categories-block-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
			]
		);
		$this->end_controls_tab();

		// Hover tab.
		$this->start_controls_tab(
			'icon_box_style_hover',
			[
				'label' => __( 'Hover', 'cldirectory-core' ),
			]
		);
		// Icon Color.
		$this->add_control(
			'cat_icon_hover_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Icon Color', 'cldirectory-core' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block:hover  .categories-block-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_style_hover_bg_color',
				'label'    => esc_html__( 'Background', 'cldirectory-core' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'fields_options' => [
					'background' => [
						'label' => esc_html__('Background', 'cldirectory-core'),
						'default' => 'classic',
					]
				],
				'selector' => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block:hover .categories-block-icon',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_style_hover_border',
				'label'     => __( 'Border', 'cldirectory-core' ),
				'selector'  => '{{WRAPPER}} .rt-listing-category-wrapper .categories-block:hover .categories-block-icon',
			]
		);
		$this->add_responsive_control(
			'icon_box_style_hover_border_radius',
			[
				'type'    => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'label'   => esc_html__( 'Radius', 'cldirectory-core' ),
				'selectors' => array(
					'{{WRAPPER}} .rt-listing-category-wrapper .categories-block:hover .categories-block-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
	}


	protected function __title_settings() {
		$this->start_controls_section(
			'cat_title_setting',
			[
				'label' => esc_html__( 'Title Settings', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// Title color.
		$this->add_control(
			'cat_title_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Text Color', 'cldirectory-core' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .categories-block .categories-block__cname a' => 'color: {{VALUE}};',
				],
			]
		);
		// Title Hover color.
		$this->add_control(
			'cat_title_hover_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Text Hover Color', 'cldirectory-core' ),
				'separator' => '',
				'selectors' => [
					'{{WRAPPER}} .categories-block:hover .categories-block__cname a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cat_title_typography',
				'label'    => __( 'Typography', 'cldirectory' ),
				'selector' => '{{WRAPPER}} .categories-block .categories-block__cname',
			]
		);

		$this->add_control(
			'title_margin',
			[
				'label'              => __( 'Title Margin', 'cldirectory' ),
				'type'               => Controls_Manager::DIMENSIONS,
				'size_units'         => [ 'px', '%', 'em' ],
				'selectors'          => [
					'{{WRAPPER}} .categories-block .categories-block__cname' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function __category_count_settings() {
		$this->start_controls_section(
			'cat_count_setting',
			[
				'label' => esc_html__( 'Category Count Settings', 'cldirectory-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'cat_count_suffix',
			[
				'label'   => __( 'Count Suffix Text', 'cldirectory-core' ),
				'type'    => Controls_Manager::TEXT,
				'default' => __( 'Listings', 'cldirectory-core' ),
			]
		);

		// Title color.
		$this->add_control(
			'cat_count_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Count Color', 'cldirectory-core' ),
				'selectors' => [
					'{{WRAPPER}} .categories-block a.categories-listing-count' => 'color: {{VALUE}};',
				],
			]
		);
		// Title Hover color.
		$this->add_control(
			'cat_count_hover_color',
			[
				'type'      => Controls_Manager::COLOR,
				'label'     => __( 'Count Hover Color', 'cldirectory-core' ),
				'selectors' => [
					'{{WRAPPER}} .categories-block .categories-listing-count:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'cat_count_typography',
				'label'    => __( 'Typography', 'cldirectory-core' ),
				'selector' => '{{WRAPPER}} .categories-block a.categories-listing-count',
			]
		);

		$this->end_controls_section();
	}


	protected function render() {
		$data = $this->get_settings();

		$template = 'view-'.$data['style'];

		$this->rt_template( $template, $data );
	}

}